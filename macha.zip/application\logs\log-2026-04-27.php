<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-04-27 08:29:53 --> Config Class Initialized
INFO - 2026-04-27 08:29:53 --> Hooks Class Initialized
DEBUG - 2026-04-27 08:29:53 --> UTF-8 Support Enabled
INFO - 2026-04-27 08:29:53 --> Utf8 Class Initialized
INFO - 2026-04-27 08:29:53 --> URI Class Initialized
DEBUG - 2026-04-27 08:29:53 --> No URI present. Default controller set.
INFO - 2026-04-27 08:29:53 --> Router Class Initialized
INFO - 2026-04-27 08:29:53 --> Output Class Initialized
INFO - 2026-04-27 08:29:53 --> Security Class Initialized
DEBUG - 2026-04-27 08:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 08:29:53 --> Input Class Initialized
INFO - 2026-04-27 08:29:53 --> Language Class Initialized
INFO - 2026-04-27 08:29:53 --> Loader Class Initialized
INFO - 2026-04-27 08:29:53 --> Helper loaded: url_helper
INFO - 2026-04-27 08:29:53 --> Helper loaded: file_helper
INFO - 2026-04-27 08:29:53 --> Helper loaded: form_helper
INFO - 2026-04-27 08:29:53 --> Helper loaded: security_helper
INFO - 2026-04-27 08:29:53 --> Database Driver Class Initialized
INFO - 2026-04-27 08:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 08:29:53 --> Upload Class Initialized
INFO - 2026-04-27 08:29:53 --> Form Validation Class Initialized
INFO - 2026-04-27 08:29:53 --> Model "M_product" initialized
INFO - 2026-04-27 08:29:53 --> Model "M_settings" initialized
INFO - 2026-04-27 08:29:53 --> Controller Class Initialized
INFO - 2026-04-27 08:29:53 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-27 08:29:53 --> Final output sent to browser
DEBUG - 2026-04-27 08:29:53 --> Total execution time: 0.1431
INFO - 2026-04-27 08:30:00 --> Config Class Initialized
INFO - 2026-04-27 08:30:00 --> Hooks Class Initialized
DEBUG - 2026-04-27 08:30:00 --> UTF-8 Support Enabled
INFO - 2026-04-27 08:30:00 --> Utf8 Class Initialized
INFO - 2026-04-27 08:30:00 --> URI Class Initialized
INFO - 2026-04-27 08:30:00 --> Router Class Initialized
INFO - 2026-04-27 08:30:00 --> Output Class Initialized
INFO - 2026-04-27 08:30:00 --> Security Class Initialized
DEBUG - 2026-04-27 08:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 08:30:00 --> Input Class Initialized
INFO - 2026-04-27 08:30:00 --> Language Class Initialized
INFO - 2026-04-27 08:30:00 --> Loader Class Initialized
INFO - 2026-04-27 08:30:00 --> Helper loaded: url_helper
INFO - 2026-04-27 08:30:00 --> Helper loaded: file_helper
INFO - 2026-04-27 08:30:00 --> Helper loaded: form_helper
INFO - 2026-04-27 08:30:00 --> Helper loaded: security_helper
INFO - 2026-04-27 08:30:00 --> Database Driver Class Initialized
INFO - 2026-04-27 08:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 08:30:00 --> Upload Class Initialized
INFO - 2026-04-27 08:30:00 --> Form Validation Class Initialized
INFO - 2026-04-27 08:30:00 --> Model "M_product" initialized
INFO - 2026-04-27 08:30:00 --> Model "M_settings" initialized
INFO - 2026-04-27 08:30:00 --> Controller Class Initialized
ERROR - 2026-04-27 08:30:01 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 732
ERROR - 2026-04-27 08:30:01 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 749
ERROR - 2026-04-27 08:30:01 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 802
ERROR - 2026-04-27 08:30:01 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 811
INFO - 2026-04-27 08:30:01 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 08:30:01 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 08:30:01 --> Final output sent to browser
DEBUG - 2026-04-27 08:30:01 --> Total execution time: 0.1222
INFO - 2026-04-27 08:30:52 --> Config Class Initialized
INFO - 2026-04-27 08:30:52 --> Hooks Class Initialized
DEBUG - 2026-04-27 08:30:52 --> UTF-8 Support Enabled
INFO - 2026-04-27 08:30:52 --> Utf8 Class Initialized
INFO - 2026-04-27 08:30:52 --> URI Class Initialized
INFO - 2026-04-27 08:30:52 --> Router Class Initialized
INFO - 2026-04-27 08:30:52 --> Output Class Initialized
INFO - 2026-04-27 08:30:52 --> Security Class Initialized
DEBUG - 2026-04-27 08:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 08:30:52 --> Input Class Initialized
INFO - 2026-04-27 08:30:52 --> Language Class Initialized
INFO - 2026-04-27 08:30:52 --> Loader Class Initialized
INFO - 2026-04-27 08:30:52 --> Helper loaded: url_helper
INFO - 2026-04-27 08:30:52 --> Helper loaded: file_helper
INFO - 2026-04-27 08:30:52 --> Helper loaded: form_helper
INFO - 2026-04-27 08:30:52 --> Helper loaded: security_helper
INFO - 2026-04-27 08:30:52 --> Database Driver Class Initialized
INFO - 2026-04-27 08:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 08:30:52 --> Upload Class Initialized
INFO - 2026-04-27 08:30:52 --> Form Validation Class Initialized
INFO - 2026-04-27 08:30:52 --> Model "M_product" initialized
INFO - 2026-04-27 08:30:52 --> Model "M_settings" initialized
INFO - 2026-04-27 08:30:52 --> Controller Class Initialized
ERROR - 2026-04-27 08:30:52 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 732
ERROR - 2026-04-27 08:30:52 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 749
ERROR - 2026-04-27 08:30:52 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 802
ERROR - 2026-04-27 08:30:52 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 811
INFO - 2026-04-27 08:30:52 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 08:30:52 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 08:30:52 --> Final output sent to browser
DEBUG - 2026-04-27 08:30:52 --> Total execution time: 0.1193
INFO - 2026-04-27 08:30:55 --> Config Class Initialized
INFO - 2026-04-27 08:30:55 --> Hooks Class Initialized
DEBUG - 2026-04-27 08:30:55 --> UTF-8 Support Enabled
INFO - 2026-04-27 08:30:55 --> Utf8 Class Initialized
INFO - 2026-04-27 08:30:55 --> URI Class Initialized
INFO - 2026-04-27 08:30:55 --> Router Class Initialized
INFO - 2026-04-27 08:30:55 --> Output Class Initialized
INFO - 2026-04-27 08:30:55 --> Security Class Initialized
DEBUG - 2026-04-27 08:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 08:30:55 --> Input Class Initialized
INFO - 2026-04-27 08:30:55 --> Language Class Initialized
INFO - 2026-04-27 08:30:55 --> Loader Class Initialized
INFO - 2026-04-27 08:30:55 --> Helper loaded: url_helper
INFO - 2026-04-27 08:30:55 --> Helper loaded: file_helper
INFO - 2026-04-27 08:30:55 --> Helper loaded: form_helper
INFO - 2026-04-27 08:30:55 --> Helper loaded: security_helper
INFO - 2026-04-27 08:30:55 --> Database Driver Class Initialized
INFO - 2026-04-27 08:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 08:30:55 --> Upload Class Initialized
INFO - 2026-04-27 08:30:55 --> Form Validation Class Initialized
INFO - 2026-04-27 08:30:55 --> Model "M_product" initialized
INFO - 2026-04-27 08:30:55 --> Model "M_settings" initialized
INFO - 2026-04-27 08:30:55 --> Controller Class Initialized
ERROR - 2026-04-27 08:30:55 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 732
ERROR - 2026-04-27 08:30:55 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 749
ERROR - 2026-04-27 08:30:55 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 802
ERROR - 2026-04-27 08:30:55 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 811
INFO - 2026-04-27 08:30:55 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 08:30:55 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 08:30:55 --> Final output sent to browser
DEBUG - 2026-04-27 08:30:55 --> Total execution time: 0.0960
INFO - 2026-04-27 08:30:55 --> Config Class Initialized
INFO - 2026-04-27 08:30:55 --> Hooks Class Initialized
DEBUG - 2026-04-27 08:30:55 --> UTF-8 Support Enabled
INFO - 2026-04-27 08:30:55 --> Utf8 Class Initialized
INFO - 2026-04-27 08:30:55 --> URI Class Initialized
INFO - 2026-04-27 08:30:55 --> Router Class Initialized
INFO - 2026-04-27 08:30:55 --> Output Class Initialized
INFO - 2026-04-27 08:30:55 --> Security Class Initialized
DEBUG - 2026-04-27 08:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 08:30:55 --> Input Class Initialized
INFO - 2026-04-27 08:30:55 --> Language Class Initialized
INFO - 2026-04-27 08:30:55 --> Loader Class Initialized
INFO - 2026-04-27 08:30:55 --> Helper loaded: url_helper
INFO - 2026-04-27 08:30:55 --> Helper loaded: file_helper
INFO - 2026-04-27 08:30:55 --> Helper loaded: form_helper
INFO - 2026-04-27 08:30:55 --> Helper loaded: security_helper
INFO - 2026-04-27 08:30:55 --> Database Driver Class Initialized
INFO - 2026-04-27 08:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 08:30:55 --> Upload Class Initialized
INFO - 2026-04-27 08:30:55 --> Form Validation Class Initialized
INFO - 2026-04-27 08:30:55 --> Model "M_product" initialized
INFO - 2026-04-27 08:30:55 --> Model "M_settings" initialized
INFO - 2026-04-27 08:30:55 --> Controller Class Initialized
ERROR - 2026-04-27 08:30:55 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 732
ERROR - 2026-04-27 08:30:55 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 749
ERROR - 2026-04-27 08:30:55 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 802
ERROR - 2026-04-27 08:30:55 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 811
INFO - 2026-04-27 08:30:55 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 08:30:55 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 08:30:55 --> Final output sent to browser
DEBUG - 2026-04-27 08:30:55 --> Total execution time: 0.1121
INFO - 2026-04-27 08:30:56 --> Config Class Initialized
INFO - 2026-04-27 08:30:56 --> Hooks Class Initialized
DEBUG - 2026-04-27 08:30:56 --> UTF-8 Support Enabled
INFO - 2026-04-27 08:30:56 --> Utf8 Class Initialized
INFO - 2026-04-27 08:30:56 --> URI Class Initialized
INFO - 2026-04-27 08:30:56 --> Router Class Initialized
INFO - 2026-04-27 08:30:56 --> Output Class Initialized
INFO - 2026-04-27 08:30:56 --> Security Class Initialized
DEBUG - 2026-04-27 08:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 08:30:56 --> Input Class Initialized
INFO - 2026-04-27 08:30:56 --> Language Class Initialized
INFO - 2026-04-27 08:30:56 --> Loader Class Initialized
INFO - 2026-04-27 08:30:56 --> Helper loaded: url_helper
INFO - 2026-04-27 08:30:56 --> Helper loaded: file_helper
INFO - 2026-04-27 08:30:56 --> Helper loaded: form_helper
INFO - 2026-04-27 08:30:56 --> Helper loaded: security_helper
INFO - 2026-04-27 08:30:56 --> Database Driver Class Initialized
INFO - 2026-04-27 08:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 08:30:56 --> Upload Class Initialized
INFO - 2026-04-27 08:30:56 --> Form Validation Class Initialized
INFO - 2026-04-27 08:30:56 --> Model "M_product" initialized
INFO - 2026-04-27 08:30:56 --> Model "M_settings" initialized
INFO - 2026-04-27 08:30:56 --> Controller Class Initialized
ERROR - 2026-04-27 08:30:56 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 732
ERROR - 2026-04-27 08:30:56 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 749
ERROR - 2026-04-27 08:30:56 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 802
ERROR - 2026-04-27 08:30:56 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 811
INFO - 2026-04-27 08:30:56 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 08:30:56 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 08:30:56 --> Final output sent to browser
DEBUG - 2026-04-27 08:30:56 --> Total execution time: 0.1103
INFO - 2026-04-27 08:32:25 --> Config Class Initialized
INFO - 2026-04-27 08:32:25 --> Hooks Class Initialized
DEBUG - 2026-04-27 08:32:25 --> UTF-8 Support Enabled
INFO - 2026-04-27 08:32:25 --> Utf8 Class Initialized
INFO - 2026-04-27 08:32:25 --> URI Class Initialized
INFO - 2026-04-27 08:32:25 --> Router Class Initialized
INFO - 2026-04-27 08:32:25 --> Output Class Initialized
INFO - 2026-04-27 08:32:25 --> Security Class Initialized
DEBUG - 2026-04-27 08:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 08:32:25 --> Input Class Initialized
INFO - 2026-04-27 08:32:25 --> Language Class Initialized
INFO - 2026-04-27 08:32:25 --> Loader Class Initialized
INFO - 2026-04-27 08:32:25 --> Helper loaded: url_helper
INFO - 2026-04-27 08:32:25 --> Helper loaded: file_helper
INFO - 2026-04-27 08:32:25 --> Helper loaded: form_helper
INFO - 2026-04-27 08:32:25 --> Helper loaded: security_helper
INFO - 2026-04-27 08:32:25 --> Database Driver Class Initialized
INFO - 2026-04-27 08:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 08:32:25 --> Upload Class Initialized
INFO - 2026-04-27 08:32:25 --> Form Validation Class Initialized
INFO - 2026-04-27 08:32:25 --> Model "M_product" initialized
INFO - 2026-04-27 08:32:25 --> Model "M_settings" initialized
INFO - 2026-04-27 08:32:25 --> Controller Class Initialized
INFO - 2026-04-27 08:32:25 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 08:32:25 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 08:32:25 --> Final output sent to browser
DEBUG - 2026-04-27 08:32:25 --> Total execution time: 0.0848
INFO - 2026-04-27 09:11:28 --> Config Class Initialized
INFO - 2026-04-27 09:11:28 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:11:28 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:11:28 --> Utf8 Class Initialized
INFO - 2026-04-27 09:11:28 --> URI Class Initialized
INFO - 2026-04-27 09:11:28 --> Router Class Initialized
INFO - 2026-04-27 09:11:28 --> Output Class Initialized
INFO - 2026-04-27 09:11:28 --> Security Class Initialized
DEBUG - 2026-04-27 09:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:11:28 --> Input Class Initialized
INFO - 2026-04-27 09:11:28 --> Language Class Initialized
INFO - 2026-04-27 09:11:28 --> Loader Class Initialized
INFO - 2026-04-27 09:11:28 --> Helper loaded: url_helper
INFO - 2026-04-27 09:11:28 --> Helper loaded: file_helper
INFO - 2026-04-27 09:11:28 --> Helper loaded: form_helper
INFO - 2026-04-27 09:11:28 --> Helper loaded: security_helper
INFO - 2026-04-27 09:11:28 --> Database Driver Class Initialized
INFO - 2026-04-27 09:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:11:29 --> Upload Class Initialized
INFO - 2026-04-27 09:11:29 --> Form Validation Class Initialized
INFO - 2026-04-27 09:11:29 --> Model "M_product" initialized
INFO - 2026-04-27 09:11:29 --> Model "M_settings" initialized
INFO - 2026-04-27 09:11:29 --> Controller Class Initialized
INFO - 2026-04-27 09:11:29 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:11:29 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:11:29 --> Final output sent to browser
DEBUG - 2026-04-27 09:11:29 --> Total execution time: 0.1028
INFO - 2026-04-27 09:15:44 --> Config Class Initialized
INFO - 2026-04-27 09:15:44 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:15:44 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:15:44 --> Utf8 Class Initialized
INFO - 2026-04-27 09:15:44 --> URI Class Initialized
INFO - 2026-04-27 09:15:44 --> Router Class Initialized
INFO - 2026-04-27 09:15:44 --> Output Class Initialized
INFO - 2026-04-27 09:15:44 --> Security Class Initialized
DEBUG - 2026-04-27 09:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:15:44 --> Input Class Initialized
INFO - 2026-04-27 09:15:44 --> Language Class Initialized
INFO - 2026-04-27 09:15:44 --> Loader Class Initialized
INFO - 2026-04-27 09:15:44 --> Helper loaded: url_helper
INFO - 2026-04-27 09:15:44 --> Helper loaded: file_helper
INFO - 2026-04-27 09:15:44 --> Helper loaded: form_helper
INFO - 2026-04-27 09:15:44 --> Helper loaded: security_helper
INFO - 2026-04-27 09:15:44 --> Database Driver Class Initialized
INFO - 2026-04-27 09:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:15:44 --> Upload Class Initialized
INFO - 2026-04-27 09:15:44 --> Form Validation Class Initialized
INFO - 2026-04-27 09:15:44 --> Model "M_product" initialized
INFO - 2026-04-27 09:15:44 --> Model "M_settings" initialized
INFO - 2026-04-27 09:15:44 --> Controller Class Initialized
INFO - 2026-04-27 09:15:44 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:15:44 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:15:44 --> Final output sent to browser
DEBUG - 2026-04-27 09:15:44 --> Total execution time: 0.0947
INFO - 2026-04-27 09:15:53 --> Config Class Initialized
INFO - 2026-04-27 09:15:53 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:15:53 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:15:53 --> Utf8 Class Initialized
INFO - 2026-04-27 09:15:53 --> URI Class Initialized
INFO - 2026-04-27 09:15:53 --> Router Class Initialized
INFO - 2026-04-27 09:15:53 --> Output Class Initialized
INFO - 2026-04-27 09:15:53 --> Security Class Initialized
DEBUG - 2026-04-27 09:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:15:53 --> Input Class Initialized
INFO - 2026-04-27 09:15:53 --> Language Class Initialized
INFO - 2026-04-27 09:15:53 --> Loader Class Initialized
INFO - 2026-04-27 09:15:53 --> Helper loaded: url_helper
INFO - 2026-04-27 09:15:53 --> Helper loaded: file_helper
INFO - 2026-04-27 09:15:53 --> Helper loaded: form_helper
INFO - 2026-04-27 09:15:53 --> Helper loaded: security_helper
INFO - 2026-04-27 09:15:53 --> Database Driver Class Initialized
INFO - 2026-04-27 09:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:15:53 --> Upload Class Initialized
INFO - 2026-04-27 09:15:53 --> Form Validation Class Initialized
INFO - 2026-04-27 09:15:53 --> Model "M_product" initialized
INFO - 2026-04-27 09:15:53 --> Model "M_settings" initialized
INFO - 2026-04-27 09:15:53 --> Controller Class Initialized
INFO - 2026-04-27 09:15:53 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:15:53 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:15:53 --> Final output sent to browser
DEBUG - 2026-04-27 09:15:53 --> Total execution time: 0.0895
INFO - 2026-04-27 09:15:53 --> Config Class Initialized
INFO - 2026-04-27 09:15:53 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:15:53 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:15:53 --> Utf8 Class Initialized
INFO - 2026-04-27 09:15:53 --> URI Class Initialized
INFO - 2026-04-27 09:15:53 --> Router Class Initialized
INFO - 2026-04-27 09:15:53 --> Output Class Initialized
INFO - 2026-04-27 09:15:53 --> Security Class Initialized
DEBUG - 2026-04-27 09:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:15:53 --> Input Class Initialized
INFO - 2026-04-27 09:15:53 --> Language Class Initialized
INFO - 2026-04-27 09:15:53 --> Loader Class Initialized
INFO - 2026-04-27 09:15:53 --> Helper loaded: url_helper
INFO - 2026-04-27 09:15:53 --> Helper loaded: file_helper
INFO - 2026-04-27 09:15:53 --> Helper loaded: form_helper
INFO - 2026-04-27 09:15:53 --> Helper loaded: security_helper
INFO - 2026-04-27 09:15:53 --> Database Driver Class Initialized
INFO - 2026-04-27 09:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:15:54 --> Upload Class Initialized
INFO - 2026-04-27 09:15:54 --> Form Validation Class Initialized
INFO - 2026-04-27 09:15:54 --> Model "M_product" initialized
INFO - 2026-04-27 09:15:54 --> Model "M_settings" initialized
INFO - 2026-04-27 09:15:54 --> Controller Class Initialized
INFO - 2026-04-27 09:15:54 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:15:54 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:15:54 --> Final output sent to browser
DEBUG - 2026-04-27 09:15:54 --> Total execution time: 0.0903
INFO - 2026-04-27 09:15:54 --> Config Class Initialized
INFO - 2026-04-27 09:15:54 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:15:54 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:15:54 --> Utf8 Class Initialized
INFO - 2026-04-27 09:15:54 --> URI Class Initialized
INFO - 2026-04-27 09:15:54 --> Router Class Initialized
INFO - 2026-04-27 09:15:54 --> Output Class Initialized
INFO - 2026-04-27 09:15:54 --> Security Class Initialized
DEBUG - 2026-04-27 09:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:15:54 --> Input Class Initialized
INFO - 2026-04-27 09:15:54 --> Language Class Initialized
INFO - 2026-04-27 09:15:54 --> Loader Class Initialized
INFO - 2026-04-27 09:15:54 --> Helper loaded: url_helper
INFO - 2026-04-27 09:15:54 --> Helper loaded: file_helper
INFO - 2026-04-27 09:15:54 --> Helper loaded: form_helper
INFO - 2026-04-27 09:15:54 --> Helper loaded: security_helper
INFO - 2026-04-27 09:15:54 --> Database Driver Class Initialized
INFO - 2026-04-27 09:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:15:54 --> Upload Class Initialized
INFO - 2026-04-27 09:15:54 --> Form Validation Class Initialized
INFO - 2026-04-27 09:15:54 --> Model "M_product" initialized
INFO - 2026-04-27 09:15:54 --> Model "M_settings" initialized
INFO - 2026-04-27 09:15:54 --> Controller Class Initialized
INFO - 2026-04-27 09:15:54 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:15:54 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:15:54 --> Final output sent to browser
DEBUG - 2026-04-27 09:15:54 --> Total execution time: 0.1030
INFO - 2026-04-27 09:15:54 --> Config Class Initialized
INFO - 2026-04-27 09:15:54 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:15:54 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:15:54 --> Utf8 Class Initialized
INFO - 2026-04-27 09:15:54 --> URI Class Initialized
INFO - 2026-04-27 09:15:54 --> Router Class Initialized
INFO - 2026-04-27 09:15:54 --> Output Class Initialized
INFO - 2026-04-27 09:15:54 --> Security Class Initialized
DEBUG - 2026-04-27 09:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:15:54 --> Input Class Initialized
INFO - 2026-04-27 09:15:54 --> Language Class Initialized
INFO - 2026-04-27 09:15:54 --> Loader Class Initialized
INFO - 2026-04-27 09:15:54 --> Helper loaded: url_helper
INFO - 2026-04-27 09:15:54 --> Helper loaded: file_helper
INFO - 2026-04-27 09:15:54 --> Helper loaded: form_helper
INFO - 2026-04-27 09:15:54 --> Helper loaded: security_helper
INFO - 2026-04-27 09:15:54 --> Database Driver Class Initialized
INFO - 2026-04-27 09:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:15:54 --> Upload Class Initialized
INFO - 2026-04-27 09:15:54 --> Form Validation Class Initialized
INFO - 2026-04-27 09:15:54 --> Model "M_product" initialized
INFO - 2026-04-27 09:15:54 --> Model "M_settings" initialized
INFO - 2026-04-27 09:15:54 --> Controller Class Initialized
INFO - 2026-04-27 09:15:54 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:15:54 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:15:54 --> Final output sent to browser
DEBUG - 2026-04-27 09:15:54 --> Total execution time: 0.1070
INFO - 2026-04-27 09:15:54 --> Config Class Initialized
INFO - 2026-04-27 09:15:54 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:15:54 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:15:54 --> Utf8 Class Initialized
INFO - 2026-04-27 09:15:54 --> URI Class Initialized
INFO - 2026-04-27 09:15:54 --> Router Class Initialized
INFO - 2026-04-27 09:15:54 --> Output Class Initialized
INFO - 2026-04-27 09:15:54 --> Security Class Initialized
DEBUG - 2026-04-27 09:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:15:54 --> Input Class Initialized
INFO - 2026-04-27 09:15:54 --> Language Class Initialized
INFO - 2026-04-27 09:15:54 --> Loader Class Initialized
INFO - 2026-04-27 09:15:54 --> Helper loaded: url_helper
INFO - 2026-04-27 09:15:54 --> Helper loaded: file_helper
INFO - 2026-04-27 09:15:54 --> Helper loaded: form_helper
INFO - 2026-04-27 09:15:54 --> Helper loaded: security_helper
INFO - 2026-04-27 09:15:54 --> Database Driver Class Initialized
INFO - 2026-04-27 09:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:15:54 --> Upload Class Initialized
INFO - 2026-04-27 09:15:54 --> Form Validation Class Initialized
INFO - 2026-04-27 09:15:54 --> Model "M_product" initialized
INFO - 2026-04-27 09:15:54 --> Model "M_settings" initialized
INFO - 2026-04-27 09:15:54 --> Controller Class Initialized
INFO - 2026-04-27 09:15:54 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:15:54 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:15:54 --> Final output sent to browser
DEBUG - 2026-04-27 09:15:54 --> Total execution time: 0.1097
INFO - 2026-04-27 09:16:04 --> Config Class Initialized
INFO - 2026-04-27 09:16:04 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:16:04 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:16:04 --> Utf8 Class Initialized
INFO - 2026-04-27 09:16:04 --> URI Class Initialized
INFO - 2026-04-27 09:16:04 --> Router Class Initialized
INFO - 2026-04-27 09:16:04 --> Output Class Initialized
INFO - 2026-04-27 09:16:04 --> Security Class Initialized
DEBUG - 2026-04-27 09:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:16:04 --> Input Class Initialized
INFO - 2026-04-27 09:16:04 --> Language Class Initialized
INFO - 2026-04-27 09:16:04 --> Loader Class Initialized
INFO - 2026-04-27 09:16:04 --> Helper loaded: url_helper
INFO - 2026-04-27 09:16:04 --> Helper loaded: file_helper
INFO - 2026-04-27 09:16:04 --> Helper loaded: form_helper
INFO - 2026-04-27 09:16:04 --> Helper loaded: security_helper
INFO - 2026-04-27 09:16:04 --> Database Driver Class Initialized
INFO - 2026-04-27 09:16:04 --> Config Class Initialized
INFO - 2026-04-27 09:16:04 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:16:04 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:16:04 --> Utf8 Class Initialized
INFO - 2026-04-27 09:16:04 --> URI Class Initialized
INFO - 2026-04-27 09:16:04 --> Router Class Initialized
INFO - 2026-04-27 09:16:04 --> Output Class Initialized
INFO - 2026-04-27 09:16:04 --> Security Class Initialized
DEBUG - 2026-04-27 09:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:16:04 --> Input Class Initialized
INFO - 2026-04-27 09:16:04 --> Language Class Initialized
INFO - 2026-04-27 09:16:04 --> Loader Class Initialized
INFO - 2026-04-27 09:16:04 --> Helper loaded: url_helper
INFO - 2026-04-27 09:16:04 --> Helper loaded: file_helper
INFO - 2026-04-27 09:16:04 --> Helper loaded: form_helper
INFO - 2026-04-27 09:16:04 --> Helper loaded: security_helper
INFO - 2026-04-27 09:16:04 --> Database Driver Class Initialized
INFO - 2026-04-27 09:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:16:04 --> Upload Class Initialized
INFO - 2026-04-27 09:16:04 --> Form Validation Class Initialized
INFO - 2026-04-27 09:16:04 --> Model "M_product" initialized
INFO - 2026-04-27 09:16:04 --> Model "M_settings" initialized
INFO - 2026-04-27 09:16:04 --> Controller Class Initialized
INFO - 2026-04-27 09:16:04 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:16:04 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:16:04 --> Final output sent to browser
DEBUG - 2026-04-27 09:16:04 --> Total execution time: 0.0847
INFO - 2026-04-27 09:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:16:04 --> Upload Class Initialized
INFO - 2026-04-27 09:16:04 --> Form Validation Class Initialized
INFO - 2026-04-27 09:16:04 --> Model "M_product" initialized
INFO - 2026-04-27 09:16:04 --> Model "M_settings" initialized
INFO - 2026-04-27 09:16:04 --> Controller Class Initialized
INFO - 2026-04-27 09:16:04 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:16:04 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:16:04 --> Final output sent to browser
DEBUG - 2026-04-27 09:16:04 --> Total execution time: 0.5698
INFO - 2026-04-27 09:23:39 --> Config Class Initialized
INFO - 2026-04-27 09:23:39 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:23:39 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:23:39 --> Utf8 Class Initialized
INFO - 2026-04-27 09:23:39 --> URI Class Initialized
INFO - 2026-04-27 09:23:39 --> Router Class Initialized
INFO - 2026-04-27 09:23:39 --> Output Class Initialized
INFO - 2026-04-27 09:23:39 --> Security Class Initialized
DEBUG - 2026-04-27 09:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:23:39 --> Input Class Initialized
INFO - 2026-04-27 09:23:39 --> Language Class Initialized
INFO - 2026-04-27 09:23:39 --> Loader Class Initialized
INFO - 2026-04-27 09:23:39 --> Helper loaded: url_helper
INFO - 2026-04-27 09:23:39 --> Helper loaded: file_helper
INFO - 2026-04-27 09:23:39 --> Helper loaded: form_helper
INFO - 2026-04-27 09:23:39 --> Helper loaded: security_helper
INFO - 2026-04-27 09:23:39 --> Database Driver Class Initialized
INFO - 2026-04-27 09:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:23:39 --> Upload Class Initialized
INFO - 2026-04-27 09:23:39 --> Form Validation Class Initialized
INFO - 2026-04-27 09:23:39 --> Model "M_product" initialized
INFO - 2026-04-27 09:23:39 --> Model "M_settings" initialized
INFO - 2026-04-27 09:23:39 --> Controller Class Initialized
ERROR - 2026-04-27 09:23:39 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:23:39 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:23:39 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:23:39 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:23:39 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:39 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:39 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:23:39 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:23:39 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:23:39 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:23:39 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:23:39 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:23:47 --> Config Class Initialized
INFO - 2026-04-27 09:23:47 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:23:47 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:23:47 --> Utf8 Class Initialized
INFO - 2026-04-27 09:23:47 --> URI Class Initialized
INFO - 2026-04-27 09:23:47 --> Router Class Initialized
INFO - 2026-04-27 09:23:47 --> Output Class Initialized
INFO - 2026-04-27 09:23:47 --> Security Class Initialized
DEBUG - 2026-04-27 09:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:23:47 --> Input Class Initialized
INFO - 2026-04-27 09:23:47 --> Language Class Initialized
INFO - 2026-04-27 09:23:47 --> Loader Class Initialized
INFO - 2026-04-27 09:23:47 --> Helper loaded: url_helper
INFO - 2026-04-27 09:23:47 --> Helper loaded: file_helper
INFO - 2026-04-27 09:23:47 --> Helper loaded: form_helper
INFO - 2026-04-27 09:23:47 --> Helper loaded: security_helper
INFO - 2026-04-27 09:23:47 --> Database Driver Class Initialized
INFO - 2026-04-27 09:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:23:47 --> Upload Class Initialized
INFO - 2026-04-27 09:23:47 --> Form Validation Class Initialized
INFO - 2026-04-27 09:23:47 --> Model "M_product" initialized
INFO - 2026-04-27 09:23:47 --> Model "M_settings" initialized
INFO - 2026-04-27 09:23:47 --> Controller Class Initialized
ERROR - 2026-04-27 09:23:47 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:23:47 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:23:47 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:23:47 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:23:47 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:47 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:47 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:23:47 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:23:47 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:23:47 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:23:47 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:23:47 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:23:48 --> Config Class Initialized
INFO - 2026-04-27 09:23:48 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:23:48 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:23:48 --> Utf8 Class Initialized
INFO - 2026-04-27 09:23:48 --> URI Class Initialized
INFO - 2026-04-27 09:23:48 --> Router Class Initialized
INFO - 2026-04-27 09:23:48 --> Output Class Initialized
INFO - 2026-04-27 09:23:48 --> Security Class Initialized
DEBUG - 2026-04-27 09:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:23:48 --> Input Class Initialized
INFO - 2026-04-27 09:23:48 --> Language Class Initialized
INFO - 2026-04-27 09:23:48 --> Loader Class Initialized
INFO - 2026-04-27 09:23:48 --> Helper loaded: url_helper
INFO - 2026-04-27 09:23:48 --> Helper loaded: file_helper
INFO - 2026-04-27 09:23:48 --> Helper loaded: form_helper
INFO - 2026-04-27 09:23:48 --> Helper loaded: security_helper
INFO - 2026-04-27 09:23:48 --> Database Driver Class Initialized
INFO - 2026-04-27 09:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:23:48 --> Upload Class Initialized
INFO - 2026-04-27 09:23:48 --> Form Validation Class Initialized
INFO - 2026-04-27 09:23:48 --> Model "M_product" initialized
INFO - 2026-04-27 09:23:48 --> Model "M_settings" initialized
INFO - 2026-04-27 09:23:48 --> Controller Class Initialized
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:48 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:23:48 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:23:48 --> Config Class Initialized
INFO - 2026-04-27 09:23:48 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:23:48 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:23:48 --> Utf8 Class Initialized
INFO - 2026-04-27 09:23:48 --> URI Class Initialized
INFO - 2026-04-27 09:23:48 --> Router Class Initialized
INFO - 2026-04-27 09:23:48 --> Output Class Initialized
INFO - 2026-04-27 09:23:48 --> Security Class Initialized
DEBUG - 2026-04-27 09:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:23:48 --> Input Class Initialized
INFO - 2026-04-27 09:23:48 --> Language Class Initialized
INFO - 2026-04-27 09:23:48 --> Loader Class Initialized
INFO - 2026-04-27 09:23:48 --> Helper loaded: url_helper
INFO - 2026-04-27 09:23:48 --> Helper loaded: file_helper
INFO - 2026-04-27 09:23:48 --> Helper loaded: form_helper
INFO - 2026-04-27 09:23:48 --> Helper loaded: security_helper
INFO - 2026-04-27 09:23:48 --> Database Driver Class Initialized
INFO - 2026-04-27 09:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:23:48 --> Upload Class Initialized
INFO - 2026-04-27 09:23:48 --> Form Validation Class Initialized
INFO - 2026-04-27 09:23:48 --> Model "M_product" initialized
INFO - 2026-04-27 09:23:48 --> Model "M_settings" initialized
INFO - 2026-04-27 09:23:48 --> Controller Class Initialized
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:48 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:23:48 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:23:48 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:23:49 --> Config Class Initialized
INFO - 2026-04-27 09:23:49 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:23:49 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:23:49 --> Utf8 Class Initialized
INFO - 2026-04-27 09:23:49 --> URI Class Initialized
INFO - 2026-04-27 09:23:49 --> Router Class Initialized
INFO - 2026-04-27 09:23:49 --> Output Class Initialized
INFO - 2026-04-27 09:23:49 --> Security Class Initialized
DEBUG - 2026-04-27 09:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:23:49 --> Input Class Initialized
INFO - 2026-04-27 09:23:49 --> Language Class Initialized
INFO - 2026-04-27 09:23:49 --> Loader Class Initialized
INFO - 2026-04-27 09:23:49 --> Helper loaded: url_helper
INFO - 2026-04-27 09:23:49 --> Helper loaded: file_helper
INFO - 2026-04-27 09:23:49 --> Helper loaded: form_helper
INFO - 2026-04-27 09:23:49 --> Helper loaded: security_helper
INFO - 2026-04-27 09:23:49 --> Database Driver Class Initialized
INFO - 2026-04-27 09:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:23:49 --> Upload Class Initialized
INFO - 2026-04-27 09:23:49 --> Form Validation Class Initialized
INFO - 2026-04-27 09:23:49 --> Model "M_product" initialized
INFO - 2026-04-27 09:23:49 --> Model "M_settings" initialized
INFO - 2026-04-27 09:23:49 --> Controller Class Initialized
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:49 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:23:49 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:23:49 --> Config Class Initialized
INFO - 2026-04-27 09:23:49 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:23:49 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:23:49 --> Utf8 Class Initialized
INFO - 2026-04-27 09:23:49 --> URI Class Initialized
INFO - 2026-04-27 09:23:49 --> Router Class Initialized
INFO - 2026-04-27 09:23:49 --> Output Class Initialized
INFO - 2026-04-27 09:23:49 --> Security Class Initialized
DEBUG - 2026-04-27 09:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:23:49 --> Input Class Initialized
INFO - 2026-04-27 09:23:49 --> Language Class Initialized
INFO - 2026-04-27 09:23:49 --> Loader Class Initialized
INFO - 2026-04-27 09:23:49 --> Helper loaded: url_helper
INFO - 2026-04-27 09:23:49 --> Helper loaded: file_helper
INFO - 2026-04-27 09:23:49 --> Helper loaded: form_helper
INFO - 2026-04-27 09:23:49 --> Helper loaded: security_helper
INFO - 2026-04-27 09:23:49 --> Database Driver Class Initialized
INFO - 2026-04-27 09:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:23:49 --> Upload Class Initialized
INFO - 2026-04-27 09:23:49 --> Form Validation Class Initialized
INFO - 2026-04-27 09:23:49 --> Model "M_product" initialized
INFO - 2026-04-27 09:23:49 --> Model "M_settings" initialized
INFO - 2026-04-27 09:23:49 --> Controller Class Initialized
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:49 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:23:49 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:23:49 --> Config Class Initialized
INFO - 2026-04-27 09:23:49 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:23:49 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:23:49 --> Utf8 Class Initialized
INFO - 2026-04-27 09:23:49 --> URI Class Initialized
INFO - 2026-04-27 09:23:49 --> Router Class Initialized
INFO - 2026-04-27 09:23:49 --> Output Class Initialized
INFO - 2026-04-27 09:23:49 --> Security Class Initialized
DEBUG - 2026-04-27 09:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:23:49 --> Input Class Initialized
INFO - 2026-04-27 09:23:49 --> Language Class Initialized
INFO - 2026-04-27 09:23:49 --> Loader Class Initialized
INFO - 2026-04-27 09:23:49 --> Helper loaded: url_helper
INFO - 2026-04-27 09:23:49 --> Helper loaded: file_helper
INFO - 2026-04-27 09:23:49 --> Helper loaded: form_helper
INFO - 2026-04-27 09:23:49 --> Helper loaded: security_helper
INFO - 2026-04-27 09:23:49 --> Database Driver Class Initialized
INFO - 2026-04-27 09:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:23:49 --> Upload Class Initialized
INFO - 2026-04-27 09:23:49 --> Form Validation Class Initialized
INFO - 2026-04-27 09:23:49 --> Model "M_product" initialized
INFO - 2026-04-27 09:23:49 --> Model "M_settings" initialized
INFO - 2026-04-27 09:23:49 --> Controller Class Initialized
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:49 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:23:49 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:23:49 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:23:49 --> Config Class Initialized
INFO - 2026-04-27 09:23:49 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:23:49 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:23:49 --> Utf8 Class Initialized
INFO - 2026-04-27 09:23:49 --> URI Class Initialized
INFO - 2026-04-27 09:23:49 --> Router Class Initialized
INFO - 2026-04-27 09:23:49 --> Output Class Initialized
INFO - 2026-04-27 09:23:49 --> Security Class Initialized
DEBUG - 2026-04-27 09:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:23:49 --> Input Class Initialized
INFO - 2026-04-27 09:23:49 --> Language Class Initialized
INFO - 2026-04-27 09:23:49 --> Loader Class Initialized
INFO - 2026-04-27 09:23:49 --> Helper loaded: url_helper
INFO - 2026-04-27 09:23:49 --> Helper loaded: file_helper
INFO - 2026-04-27 09:23:50 --> Helper loaded: form_helper
INFO - 2026-04-27 09:23:50 --> Helper loaded: security_helper
INFO - 2026-04-27 09:23:50 --> Database Driver Class Initialized
INFO - 2026-04-27 09:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:23:50 --> Upload Class Initialized
INFO - 2026-04-27 09:23:50 --> Form Validation Class Initialized
INFO - 2026-04-27 09:23:50 --> Model "M_product" initialized
INFO - 2026-04-27 09:23:50 --> Model "M_settings" initialized
INFO - 2026-04-27 09:23:50 --> Controller Class Initialized
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:50 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:23:50 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:23:50 --> Config Class Initialized
INFO - 2026-04-27 09:23:50 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:23:50 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:23:50 --> Utf8 Class Initialized
INFO - 2026-04-27 09:23:50 --> URI Class Initialized
INFO - 2026-04-27 09:23:50 --> Router Class Initialized
INFO - 2026-04-27 09:23:50 --> Output Class Initialized
INFO - 2026-04-27 09:23:50 --> Security Class Initialized
DEBUG - 2026-04-27 09:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:23:50 --> Input Class Initialized
INFO - 2026-04-27 09:23:50 --> Language Class Initialized
INFO - 2026-04-27 09:23:50 --> Loader Class Initialized
INFO - 2026-04-27 09:23:50 --> Helper loaded: url_helper
INFO - 2026-04-27 09:23:50 --> Helper loaded: file_helper
INFO - 2026-04-27 09:23:50 --> Helper loaded: form_helper
INFO - 2026-04-27 09:23:50 --> Helper loaded: security_helper
INFO - 2026-04-27 09:23:50 --> Database Driver Class Initialized
INFO - 2026-04-27 09:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:23:50 --> Upload Class Initialized
INFO - 2026-04-27 09:23:50 --> Form Validation Class Initialized
INFO - 2026-04-27 09:23:50 --> Model "M_product" initialized
INFO - 2026-04-27 09:23:50 --> Model "M_settings" initialized
INFO - 2026-04-27 09:23:50 --> Controller Class Initialized
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:50 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:23:50 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:23:50 --> Config Class Initialized
INFO - 2026-04-27 09:23:50 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:23:50 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:23:50 --> Utf8 Class Initialized
INFO - 2026-04-27 09:23:50 --> URI Class Initialized
INFO - 2026-04-27 09:23:50 --> Router Class Initialized
INFO - 2026-04-27 09:23:50 --> Output Class Initialized
INFO - 2026-04-27 09:23:50 --> Security Class Initialized
DEBUG - 2026-04-27 09:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:23:50 --> Input Class Initialized
INFO - 2026-04-27 09:23:50 --> Language Class Initialized
INFO - 2026-04-27 09:23:50 --> Loader Class Initialized
INFO - 2026-04-27 09:23:50 --> Helper loaded: url_helper
INFO - 2026-04-27 09:23:50 --> Helper loaded: file_helper
INFO - 2026-04-27 09:23:50 --> Helper loaded: form_helper
INFO - 2026-04-27 09:23:50 --> Helper loaded: security_helper
INFO - 2026-04-27 09:23:50 --> Database Driver Class Initialized
INFO - 2026-04-27 09:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:23:50 --> Upload Class Initialized
INFO - 2026-04-27 09:23:50 --> Form Validation Class Initialized
INFO - 2026-04-27 09:23:50 --> Model "M_product" initialized
INFO - 2026-04-27 09:23:50 --> Model "M_settings" initialized
INFO - 2026-04-27 09:23:50 --> Controller Class Initialized
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:50 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:23:50 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:23:50 --> Config Class Initialized
INFO - 2026-04-27 09:23:50 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:23:50 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:23:50 --> Utf8 Class Initialized
INFO - 2026-04-27 09:23:50 --> URI Class Initialized
INFO - 2026-04-27 09:23:50 --> Router Class Initialized
INFO - 2026-04-27 09:23:50 --> Output Class Initialized
INFO - 2026-04-27 09:23:50 --> Security Class Initialized
DEBUG - 2026-04-27 09:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:23:50 --> Input Class Initialized
INFO - 2026-04-27 09:23:50 --> Language Class Initialized
INFO - 2026-04-27 09:23:50 --> Loader Class Initialized
INFO - 2026-04-27 09:23:50 --> Helper loaded: url_helper
INFO - 2026-04-27 09:23:50 --> Helper loaded: file_helper
INFO - 2026-04-27 09:23:50 --> Helper loaded: form_helper
INFO - 2026-04-27 09:23:50 --> Helper loaded: security_helper
INFO - 2026-04-27 09:23:50 --> Database Driver Class Initialized
INFO - 2026-04-27 09:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:23:50 --> Upload Class Initialized
INFO - 2026-04-27 09:23:50 --> Form Validation Class Initialized
INFO - 2026-04-27 09:23:50 --> Model "M_product" initialized
INFO - 2026-04-27 09:23:50 --> Model "M_settings" initialized
INFO - 2026-04-27 09:23:50 --> Controller Class Initialized
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:50 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:23:50 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:23:50 --> Config Class Initialized
INFO - 2026-04-27 09:23:50 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:23:50 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:23:50 --> Utf8 Class Initialized
INFO - 2026-04-27 09:23:50 --> URI Class Initialized
INFO - 2026-04-27 09:23:50 --> Router Class Initialized
INFO - 2026-04-27 09:23:50 --> Output Class Initialized
INFO - 2026-04-27 09:23:50 --> Security Class Initialized
DEBUG - 2026-04-27 09:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:23:50 --> Input Class Initialized
INFO - 2026-04-27 09:23:50 --> Language Class Initialized
INFO - 2026-04-27 09:23:50 --> Loader Class Initialized
INFO - 2026-04-27 09:23:50 --> Helper loaded: url_helper
INFO - 2026-04-27 09:23:50 --> Helper loaded: file_helper
INFO - 2026-04-27 09:23:50 --> Helper loaded: form_helper
INFO - 2026-04-27 09:23:50 --> Helper loaded: security_helper
INFO - 2026-04-27 09:23:50 --> Database Driver Class Initialized
INFO - 2026-04-27 09:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:23:50 --> Upload Class Initialized
INFO - 2026-04-27 09:23:50 --> Form Validation Class Initialized
INFO - 2026-04-27 09:23:50 --> Model "M_product" initialized
INFO - 2026-04-27 09:23:50 --> Model "M_settings" initialized
INFO - 2026-04-27 09:23:50 --> Controller Class Initialized
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:50 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:23:50 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:23:50 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:24:00 --> Config Class Initialized
INFO - 2026-04-27 09:24:00 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:24:00 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:24:00 --> Utf8 Class Initialized
INFO - 2026-04-27 09:24:00 --> URI Class Initialized
INFO - 2026-04-27 09:24:00 --> Router Class Initialized
INFO - 2026-04-27 09:24:00 --> Output Class Initialized
INFO - 2026-04-27 09:24:00 --> Security Class Initialized
DEBUG - 2026-04-27 09:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:24:00 --> Input Class Initialized
INFO - 2026-04-27 09:24:00 --> Language Class Initialized
INFO - 2026-04-27 09:24:00 --> Loader Class Initialized
INFO - 2026-04-27 09:24:00 --> Helper loaded: url_helper
INFO - 2026-04-27 09:24:00 --> Helper loaded: file_helper
INFO - 2026-04-27 09:24:00 --> Helper loaded: form_helper
INFO - 2026-04-27 09:24:00 --> Helper loaded: security_helper
INFO - 2026-04-27 09:24:00 --> Database Driver Class Initialized
INFO - 2026-04-27 09:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:24:00 --> Upload Class Initialized
INFO - 2026-04-27 09:24:00 --> Form Validation Class Initialized
INFO - 2026-04-27 09:24:00 --> Model "M_product" initialized
INFO - 2026-04-27 09:24:00 --> Model "M_settings" initialized
INFO - 2026-04-27 09:24:00 --> Controller Class Initialized
ERROR - 2026-04-27 09:24:00 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:24:00 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:24:00 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:24:00 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:24:00 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:24:00 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:24:00 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:24:00 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:24:00 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:24:00 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:24:00 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:24:01 --> Config Class Initialized
INFO - 2026-04-27 09:24:01 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:24:01 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:24:01 --> Utf8 Class Initialized
INFO - 2026-04-27 09:24:01 --> URI Class Initialized
INFO - 2026-04-27 09:24:01 --> Router Class Initialized
INFO - 2026-04-27 09:24:01 --> Output Class Initialized
INFO - 2026-04-27 09:24:01 --> Security Class Initialized
DEBUG - 2026-04-27 09:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:24:01 --> Input Class Initialized
INFO - 2026-04-27 09:24:01 --> Language Class Initialized
INFO - 2026-04-27 09:24:01 --> Loader Class Initialized
INFO - 2026-04-27 09:24:01 --> Helper loaded: url_helper
INFO - 2026-04-27 09:24:01 --> Helper loaded: file_helper
INFO - 2026-04-27 09:24:01 --> Helper loaded: form_helper
INFO - 2026-04-27 09:24:01 --> Helper loaded: security_helper
INFO - 2026-04-27 09:24:01 --> Database Driver Class Initialized
INFO - 2026-04-27 09:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:24:01 --> Upload Class Initialized
INFO - 2026-04-27 09:24:01 --> Form Validation Class Initialized
INFO - 2026-04-27 09:24:01 --> Model "M_product" initialized
INFO - 2026-04-27 09:24:01 --> Model "M_settings" initialized
INFO - 2026-04-27 09:24:01 --> Controller Class Initialized
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:24:01 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:24:01 --> Config Class Initialized
INFO - 2026-04-27 09:24:01 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:24:01 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:24:01 --> Utf8 Class Initialized
INFO - 2026-04-27 09:24:01 --> URI Class Initialized
INFO - 2026-04-27 09:24:01 --> Router Class Initialized
INFO - 2026-04-27 09:24:01 --> Output Class Initialized
INFO - 2026-04-27 09:24:01 --> Security Class Initialized
DEBUG - 2026-04-27 09:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:24:01 --> Input Class Initialized
INFO - 2026-04-27 09:24:01 --> Language Class Initialized
INFO - 2026-04-27 09:24:01 --> Loader Class Initialized
INFO - 2026-04-27 09:24:01 --> Helper loaded: url_helper
INFO - 2026-04-27 09:24:01 --> Helper loaded: file_helper
INFO - 2026-04-27 09:24:01 --> Helper loaded: form_helper
INFO - 2026-04-27 09:24:01 --> Helper loaded: security_helper
INFO - 2026-04-27 09:24:01 --> Database Driver Class Initialized
INFO - 2026-04-27 09:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:24:01 --> Upload Class Initialized
INFO - 2026-04-27 09:24:01 --> Form Validation Class Initialized
INFO - 2026-04-27 09:24:01 --> Model "M_product" initialized
INFO - 2026-04-27 09:24:01 --> Model "M_settings" initialized
INFO - 2026-04-27 09:24:01 --> Controller Class Initialized
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:24:01 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:24:02 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:24:02 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:24:02 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:24:02 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:24:03 --> Config Class Initialized
INFO - 2026-04-27 09:24:03 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:24:03 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:24:03 --> Utf8 Class Initialized
INFO - 2026-04-27 09:24:03 --> URI Class Initialized
INFO - 2026-04-27 09:24:03 --> Router Class Initialized
INFO - 2026-04-27 09:24:03 --> Output Class Initialized
INFO - 2026-04-27 09:24:03 --> Security Class Initialized
DEBUG - 2026-04-27 09:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:24:03 --> Input Class Initialized
INFO - 2026-04-27 09:24:03 --> Language Class Initialized
INFO - 2026-04-27 09:24:03 --> Loader Class Initialized
INFO - 2026-04-27 09:24:03 --> Helper loaded: url_helper
INFO - 2026-04-27 09:24:03 --> Helper loaded: file_helper
INFO - 2026-04-27 09:24:03 --> Helper loaded: form_helper
INFO - 2026-04-27 09:24:03 --> Helper loaded: security_helper
INFO - 2026-04-27 09:24:03 --> Database Driver Class Initialized
INFO - 2026-04-27 09:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:24:03 --> Upload Class Initialized
INFO - 2026-04-27 09:24:03 --> Form Validation Class Initialized
INFO - 2026-04-27 09:24:03 --> Model "M_product" initialized
INFO - 2026-04-27 09:24:03 --> Model "M_settings" initialized
INFO - 2026-04-27 09:24:03 --> Controller Class Initialized
ERROR - 2026-04-27 09:24:03 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 733
ERROR - 2026-04-27 09:24:03 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 750
ERROR - 2026-04-27 09:24:03 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 803
ERROR - 2026-04-27 09:24:03 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 812
ERROR - 2026-04-27 09:24:03 --> Severity: Warning --> Undefined variable $revenue_today C:\laragon\www\macha\application\views\dashboard.php 15
ERROR - 2026-04-27 09:24:03 --> Severity: Warning --> Undefined variable $revenue_month C:\laragon\www\macha\application\views\dashboard.php 16
ERROR - 2026-04-27 09:24:03 --> Severity: Warning --> Undefined variable $orders_pending C:\laragon\www\macha\application\views\dashboard.php 23
ERROR - 2026-04-27 09:24:03 --> Severity: Warning --> Undefined variable $total_products C:\laragon\www\macha\application\views\dashboard.php 31
ERROR - 2026-04-27 09:24:03 --> Severity: Warning --> Undefined variable $orders_today C:\laragon\www\macha\application\views\dashboard.php 39
ERROR - 2026-04-27 09:24:03 --> Severity: Warning --> Undefined variable $recent_7_days C:\laragon\www\macha\application\views\dashboard.php 56
ERROR - 2026-04-27 09:24:03 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, null given C:\laragon\www\macha\application\views\dashboard.php 56
INFO - 2026-04-27 09:25:18 --> Config Class Initialized
INFO - 2026-04-27 09:25:18 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:25:18 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:25:18 --> Utf8 Class Initialized
INFO - 2026-04-27 09:25:18 --> URI Class Initialized
INFO - 2026-04-27 09:25:18 --> Router Class Initialized
INFO - 2026-04-27 09:25:18 --> Output Class Initialized
INFO - 2026-04-27 09:25:18 --> Security Class Initialized
DEBUG - 2026-04-27 09:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:25:18 --> Input Class Initialized
INFO - 2026-04-27 09:25:18 --> Language Class Initialized
INFO - 2026-04-27 09:25:18 --> Loader Class Initialized
INFO - 2026-04-27 09:25:18 --> Helper loaded: url_helper
INFO - 2026-04-27 09:25:18 --> Helper loaded: file_helper
INFO - 2026-04-27 09:25:18 --> Helper loaded: form_helper
INFO - 2026-04-27 09:25:18 --> Helper loaded: security_helper
INFO - 2026-04-27 09:25:18 --> Database Driver Class Initialized
INFO - 2026-04-27 09:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:25:18 --> Upload Class Initialized
INFO - 2026-04-27 09:25:18 --> Form Validation Class Initialized
INFO - 2026-04-27 09:25:18 --> Model "M_product" initialized
INFO - 2026-04-27 09:25:18 --> Model "M_settings" initialized
INFO - 2026-04-27 09:25:18 --> Controller Class Initialized
ERROR - 2026-04-27 09:25:19 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 732
ERROR - 2026-04-27 09:25:19 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 749
ERROR - 2026-04-27 09:25:19 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 802
ERROR - 2026-04-27 09:25:19 --> Severity: Warning --> Undefined variable $pending_count C:\laragon\www\macha\application\views\layout\wrapper.php 811
INFO - 2026-04-27 09:25:19 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:25:19 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:25:19 --> Final output sent to browser
DEBUG - 2026-04-27 09:25:19 --> Total execution time: 0.0867
INFO - 2026-04-27 09:26:28 --> Config Class Initialized
INFO - 2026-04-27 09:26:28 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:26:28 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:26:28 --> Utf8 Class Initialized
INFO - 2026-04-27 09:26:28 --> URI Class Initialized
INFO - 2026-04-27 09:26:28 --> Router Class Initialized
INFO - 2026-04-27 09:26:28 --> Output Class Initialized
INFO - 2026-04-27 09:26:28 --> Security Class Initialized
DEBUG - 2026-04-27 09:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:26:28 --> Input Class Initialized
INFO - 2026-04-27 09:26:28 --> Language Class Initialized
INFO - 2026-04-27 09:26:28 --> Loader Class Initialized
INFO - 2026-04-27 09:26:28 --> Helper loaded: url_helper
INFO - 2026-04-27 09:26:28 --> Helper loaded: file_helper
INFO - 2026-04-27 09:26:28 --> Helper loaded: form_helper
INFO - 2026-04-27 09:26:28 --> Helper loaded: security_helper
INFO - 2026-04-27 09:26:29 --> Database Driver Class Initialized
INFO - 2026-04-27 09:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:26:29 --> Upload Class Initialized
INFO - 2026-04-27 09:26:29 --> Form Validation Class Initialized
INFO - 2026-04-27 09:26:29 --> Model "M_product" initialized
INFO - 2026-04-27 09:26:29 --> Model "M_settings" initialized
INFO - 2026-04-27 09:26:29 --> Controller Class Initialized
ERROR - 2026-04-27 09:26:29 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:26:29 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:26:29 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:26:29 --> Final output sent to browser
DEBUG - 2026-04-27 09:26:29 --> Total execution time: 0.0878
INFO - 2026-04-27 09:26:29 --> Config Class Initialized
INFO - 2026-04-27 09:26:29 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:26:29 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:26:29 --> Utf8 Class Initialized
INFO - 2026-04-27 09:26:29 --> URI Class Initialized
INFO - 2026-04-27 09:26:29 --> Router Class Initialized
INFO - 2026-04-27 09:26:29 --> Output Class Initialized
INFO - 2026-04-27 09:26:29 --> Security Class Initialized
DEBUG - 2026-04-27 09:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:26:29 --> Input Class Initialized
INFO - 2026-04-27 09:26:29 --> Language Class Initialized
INFO - 2026-04-27 09:26:29 --> Loader Class Initialized
INFO - 2026-04-27 09:26:29 --> Helper loaded: url_helper
INFO - 2026-04-27 09:26:29 --> Helper loaded: file_helper
INFO - 2026-04-27 09:26:29 --> Helper loaded: form_helper
INFO - 2026-04-27 09:26:29 --> Helper loaded: security_helper
INFO - 2026-04-27 09:26:29 --> Database Driver Class Initialized
INFO - 2026-04-27 09:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:26:29 --> Upload Class Initialized
INFO - 2026-04-27 09:26:29 --> Form Validation Class Initialized
INFO - 2026-04-27 09:26:29 --> Model "M_product" initialized
INFO - 2026-04-27 09:26:29 --> Model "M_settings" initialized
INFO - 2026-04-27 09:26:29 --> Controller Class Initialized
ERROR - 2026-04-27 09:26:29 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:26:29 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:26:29 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:26:29 --> Final output sent to browser
DEBUG - 2026-04-27 09:26:29 --> Total execution time: 0.0872
INFO - 2026-04-27 09:26:30 --> Config Class Initialized
INFO - 2026-04-27 09:26:30 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:26:30 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:26:30 --> Utf8 Class Initialized
INFO - 2026-04-27 09:26:30 --> URI Class Initialized
INFO - 2026-04-27 09:26:30 --> Router Class Initialized
INFO - 2026-04-27 09:26:30 --> Output Class Initialized
INFO - 2026-04-27 09:26:30 --> Security Class Initialized
DEBUG - 2026-04-27 09:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:26:30 --> Input Class Initialized
INFO - 2026-04-27 09:26:30 --> Language Class Initialized
INFO - 2026-04-27 09:26:30 --> Loader Class Initialized
INFO - 2026-04-27 09:26:30 --> Helper loaded: url_helper
INFO - 2026-04-27 09:26:30 --> Helper loaded: file_helper
INFO - 2026-04-27 09:26:30 --> Helper loaded: form_helper
INFO - 2026-04-27 09:26:30 --> Helper loaded: security_helper
INFO - 2026-04-27 09:26:30 --> Database Driver Class Initialized
INFO - 2026-04-27 09:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:26:30 --> Upload Class Initialized
INFO - 2026-04-27 09:26:30 --> Form Validation Class Initialized
INFO - 2026-04-27 09:26:30 --> Model "M_product" initialized
INFO - 2026-04-27 09:26:30 --> Model "M_settings" initialized
INFO - 2026-04-27 09:26:30 --> Controller Class Initialized
ERROR - 2026-04-27 09:26:30 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:26:30 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:26:30 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:26:30 --> Final output sent to browser
DEBUG - 2026-04-27 09:26:30 --> Total execution time: 0.1003
INFO - 2026-04-27 09:26:30 --> Config Class Initialized
INFO - 2026-04-27 09:26:30 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:26:30 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:26:30 --> Utf8 Class Initialized
INFO - 2026-04-27 09:26:30 --> URI Class Initialized
INFO - 2026-04-27 09:26:30 --> Router Class Initialized
INFO - 2026-04-27 09:26:30 --> Output Class Initialized
INFO - 2026-04-27 09:26:30 --> Security Class Initialized
DEBUG - 2026-04-27 09:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:26:30 --> Input Class Initialized
INFO - 2026-04-27 09:26:30 --> Language Class Initialized
INFO - 2026-04-27 09:26:30 --> Loader Class Initialized
INFO - 2026-04-27 09:26:30 --> Helper loaded: url_helper
INFO - 2026-04-27 09:26:30 --> Helper loaded: file_helper
INFO - 2026-04-27 09:26:30 --> Helper loaded: form_helper
INFO - 2026-04-27 09:26:30 --> Helper loaded: security_helper
INFO - 2026-04-27 09:26:30 --> Database Driver Class Initialized
INFO - 2026-04-27 09:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:26:30 --> Upload Class Initialized
INFO - 2026-04-27 09:26:30 --> Form Validation Class Initialized
INFO - 2026-04-27 09:26:30 --> Model "M_product" initialized
INFO - 2026-04-27 09:26:30 --> Model "M_settings" initialized
INFO - 2026-04-27 09:26:30 --> Controller Class Initialized
ERROR - 2026-04-27 09:26:30 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:26:30 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:26:30 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:26:30 --> Final output sent to browser
DEBUG - 2026-04-27 09:26:30 --> Total execution time: 0.0963
INFO - 2026-04-27 09:26:30 --> Config Class Initialized
INFO - 2026-04-27 09:26:30 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:26:30 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:26:30 --> Utf8 Class Initialized
INFO - 2026-04-27 09:26:30 --> URI Class Initialized
INFO - 2026-04-27 09:26:30 --> Router Class Initialized
INFO - 2026-04-27 09:26:30 --> Output Class Initialized
INFO - 2026-04-27 09:26:30 --> Security Class Initialized
DEBUG - 2026-04-27 09:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:26:30 --> Input Class Initialized
INFO - 2026-04-27 09:26:30 --> Language Class Initialized
INFO - 2026-04-27 09:26:30 --> Loader Class Initialized
INFO - 2026-04-27 09:26:30 --> Helper loaded: url_helper
INFO - 2026-04-27 09:26:30 --> Helper loaded: file_helper
INFO - 2026-04-27 09:26:30 --> Helper loaded: form_helper
INFO - 2026-04-27 09:26:30 --> Helper loaded: security_helper
INFO - 2026-04-27 09:26:30 --> Database Driver Class Initialized
INFO - 2026-04-27 09:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:26:30 --> Upload Class Initialized
INFO - 2026-04-27 09:26:30 --> Form Validation Class Initialized
INFO - 2026-04-27 09:26:30 --> Model "M_product" initialized
INFO - 2026-04-27 09:26:30 --> Model "M_settings" initialized
INFO - 2026-04-27 09:26:30 --> Controller Class Initialized
ERROR - 2026-04-27 09:26:30 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:26:30 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:26:30 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:26:30 --> Final output sent to browser
DEBUG - 2026-04-27 09:26:30 --> Total execution time: 0.1031
INFO - 2026-04-27 09:26:40 --> Config Class Initialized
INFO - 2026-04-27 09:26:40 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:26:40 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:26:40 --> Utf8 Class Initialized
INFO - 2026-04-27 09:26:40 --> URI Class Initialized
INFO - 2026-04-27 09:26:40 --> Router Class Initialized
INFO - 2026-04-27 09:26:40 --> Output Class Initialized
INFO - 2026-04-27 09:26:40 --> Security Class Initialized
DEBUG - 2026-04-27 09:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:26:40 --> Input Class Initialized
INFO - 2026-04-27 09:26:40 --> Language Class Initialized
INFO - 2026-04-27 09:26:40 --> Loader Class Initialized
INFO - 2026-04-27 09:26:40 --> Helper loaded: url_helper
INFO - 2026-04-27 09:26:40 --> Helper loaded: file_helper
INFO - 2026-04-27 09:26:40 --> Helper loaded: form_helper
INFO - 2026-04-27 09:26:40 --> Helper loaded: security_helper
INFO - 2026-04-27 09:26:40 --> Database Driver Class Initialized
INFO - 2026-04-27 09:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:26:40 --> Upload Class Initialized
INFO - 2026-04-27 09:26:40 --> Form Validation Class Initialized
INFO - 2026-04-27 09:26:40 --> Model "M_product" initialized
INFO - 2026-04-27 09:26:40 --> Model "M_settings" initialized
INFO - 2026-04-27 09:26:40 --> Controller Class Initialized
ERROR - 2026-04-27 09:26:40 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:26:40 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:26:40 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:26:40 --> Final output sent to browser
DEBUG - 2026-04-27 09:26:40 --> Total execution time: 0.0840
INFO - 2026-04-27 09:28:12 --> Config Class Initialized
INFO - 2026-04-27 09:28:12 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:28:12 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:28:12 --> Utf8 Class Initialized
INFO - 2026-04-27 09:28:12 --> URI Class Initialized
INFO - 2026-04-27 09:28:12 --> Router Class Initialized
INFO - 2026-04-27 09:28:12 --> Output Class Initialized
INFO - 2026-04-27 09:28:12 --> Security Class Initialized
DEBUG - 2026-04-27 09:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:28:12 --> Input Class Initialized
INFO - 2026-04-27 09:28:12 --> Language Class Initialized
INFO - 2026-04-27 09:28:12 --> Loader Class Initialized
INFO - 2026-04-27 09:28:12 --> Helper loaded: url_helper
INFO - 2026-04-27 09:28:12 --> Helper loaded: file_helper
INFO - 2026-04-27 09:28:12 --> Helper loaded: form_helper
INFO - 2026-04-27 09:28:12 --> Helper loaded: security_helper
INFO - 2026-04-27 09:28:12 --> Database Driver Class Initialized
INFO - 2026-04-27 09:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:28:12 --> Upload Class Initialized
INFO - 2026-04-27 09:28:12 --> Form Validation Class Initialized
INFO - 2026-04-27 09:28:12 --> Model "M_product" initialized
INFO - 2026-04-27 09:28:12 --> Model "M_settings" initialized
INFO - 2026-04-27 09:28:12 --> Controller Class Initialized
ERROR - 2026-04-27 09:28:12 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:28:12 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:28:12 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:28:12 --> Final output sent to browser
DEBUG - 2026-04-27 09:28:12 --> Total execution time: 0.1039
INFO - 2026-04-27 09:28:40 --> Config Class Initialized
INFO - 2026-04-27 09:28:40 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:28:40 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:28:40 --> Utf8 Class Initialized
INFO - 2026-04-27 09:28:40 --> URI Class Initialized
INFO - 2026-04-27 09:28:40 --> Router Class Initialized
INFO - 2026-04-27 09:28:40 --> Output Class Initialized
INFO - 2026-04-27 09:28:40 --> Security Class Initialized
DEBUG - 2026-04-27 09:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:28:40 --> Input Class Initialized
INFO - 2026-04-27 09:28:40 --> Language Class Initialized
INFO - 2026-04-27 09:28:40 --> Loader Class Initialized
INFO - 2026-04-27 09:28:40 --> Helper loaded: url_helper
INFO - 2026-04-27 09:28:40 --> Helper loaded: file_helper
INFO - 2026-04-27 09:28:40 --> Helper loaded: form_helper
INFO - 2026-04-27 09:28:40 --> Helper loaded: security_helper
INFO - 2026-04-27 09:28:40 --> Database Driver Class Initialized
INFO - 2026-04-27 09:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:28:40 --> Upload Class Initialized
INFO - 2026-04-27 09:28:40 --> Form Validation Class Initialized
INFO - 2026-04-27 09:28:40 --> Model "M_product" initialized
INFO - 2026-04-27 09:28:40 --> Model "M_settings" initialized
INFO - 2026-04-27 09:28:40 --> Controller Class Initialized
ERROR - 2026-04-27 09:28:40 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:28:40 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:28:40 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:28:40 --> Final output sent to browser
DEBUG - 2026-04-27 09:28:40 --> Total execution time: 0.1114
INFO - 2026-04-27 09:28:41 --> Config Class Initialized
INFO - 2026-04-27 09:28:41 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:28:41 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:28:41 --> Utf8 Class Initialized
INFO - 2026-04-27 09:28:41 --> URI Class Initialized
INFO - 2026-04-27 09:28:41 --> Router Class Initialized
INFO - 2026-04-27 09:28:41 --> Output Class Initialized
INFO - 2026-04-27 09:28:41 --> Security Class Initialized
DEBUG - 2026-04-27 09:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:28:41 --> Input Class Initialized
INFO - 2026-04-27 09:28:41 --> Language Class Initialized
INFO - 2026-04-27 09:28:41 --> Loader Class Initialized
INFO - 2026-04-27 09:28:41 --> Helper loaded: url_helper
INFO - 2026-04-27 09:28:41 --> Helper loaded: file_helper
INFO - 2026-04-27 09:28:41 --> Helper loaded: form_helper
INFO - 2026-04-27 09:28:41 --> Helper loaded: security_helper
INFO - 2026-04-27 09:28:41 --> Database Driver Class Initialized
INFO - 2026-04-27 09:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:28:41 --> Upload Class Initialized
INFO - 2026-04-27 09:28:41 --> Form Validation Class Initialized
INFO - 2026-04-27 09:28:41 --> Model "M_product" initialized
INFO - 2026-04-27 09:28:41 --> Model "M_settings" initialized
INFO - 2026-04-27 09:28:41 --> Controller Class Initialized
ERROR - 2026-04-27 09:28:41 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:28:41 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:28:41 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:28:41 --> Final output sent to browser
DEBUG - 2026-04-27 09:28:41 --> Total execution time: 0.0961
INFO - 2026-04-27 09:29:27 --> Config Class Initialized
INFO - 2026-04-27 09:29:27 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:29:27 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:29:27 --> Utf8 Class Initialized
INFO - 2026-04-27 09:29:27 --> URI Class Initialized
INFO - 2026-04-27 09:29:27 --> Router Class Initialized
INFO - 2026-04-27 09:29:27 --> Output Class Initialized
INFO - 2026-04-27 09:29:27 --> Security Class Initialized
DEBUG - 2026-04-27 09:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:29:27 --> Input Class Initialized
INFO - 2026-04-27 09:29:27 --> Language Class Initialized
INFO - 2026-04-27 09:29:27 --> Loader Class Initialized
INFO - 2026-04-27 09:29:27 --> Helper loaded: url_helper
INFO - 2026-04-27 09:29:27 --> Helper loaded: file_helper
INFO - 2026-04-27 09:29:27 --> Helper loaded: form_helper
INFO - 2026-04-27 09:29:27 --> Helper loaded: security_helper
INFO - 2026-04-27 09:29:27 --> Database Driver Class Initialized
INFO - 2026-04-27 09:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:29:27 --> Upload Class Initialized
INFO - 2026-04-27 09:29:27 --> Form Validation Class Initialized
INFO - 2026-04-27 09:29:27 --> Model "M_product" initialized
INFO - 2026-04-27 09:29:27 --> Model "M_settings" initialized
INFO - 2026-04-27 09:29:27 --> Controller Class Initialized
ERROR - 2026-04-27 09:29:27 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:29:27 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:29:27 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:29:27 --> Final output sent to browser
DEBUG - 2026-04-27 09:29:27 --> Total execution time: 0.0868
INFO - 2026-04-27 09:32:25 --> Config Class Initialized
INFO - 2026-04-27 09:32:25 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:32:25 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:32:25 --> Utf8 Class Initialized
INFO - 2026-04-27 09:32:25 --> URI Class Initialized
INFO - 2026-04-27 09:32:25 --> Router Class Initialized
INFO - 2026-04-27 09:32:25 --> Output Class Initialized
INFO - 2026-04-27 09:32:25 --> Security Class Initialized
DEBUG - 2026-04-27 09:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:32:25 --> Input Class Initialized
INFO - 2026-04-27 09:32:25 --> Language Class Initialized
INFO - 2026-04-27 09:32:25 --> Loader Class Initialized
INFO - 2026-04-27 09:32:25 --> Helper loaded: url_helper
INFO - 2026-04-27 09:32:25 --> Helper loaded: file_helper
INFO - 2026-04-27 09:32:25 --> Helper loaded: form_helper
INFO - 2026-04-27 09:32:25 --> Helper loaded: security_helper
INFO - 2026-04-27 09:32:25 --> Database Driver Class Initialized
INFO - 2026-04-27 09:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:32:25 --> Upload Class Initialized
INFO - 2026-04-27 09:32:25 --> Form Validation Class Initialized
INFO - 2026-04-27 09:32:25 --> Model "M_product" initialized
INFO - 2026-04-27 09:32:25 --> Model "M_settings" initialized
INFO - 2026-04-27 09:32:25 --> Controller Class Initialized
ERROR - 2026-04-27 09:32:25 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:32:25 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:32:25 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:32:25 --> Final output sent to browser
DEBUG - 2026-04-27 09:32:25 --> Total execution time: 0.0882
INFO - 2026-04-27 09:33:22 --> Config Class Initialized
INFO - 2026-04-27 09:33:22 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:33:22 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:33:22 --> Utf8 Class Initialized
INFO - 2026-04-27 09:33:22 --> URI Class Initialized
INFO - 2026-04-27 09:33:22 --> Router Class Initialized
INFO - 2026-04-27 09:33:22 --> Output Class Initialized
INFO - 2026-04-27 09:33:22 --> Security Class Initialized
DEBUG - 2026-04-27 09:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:33:22 --> Input Class Initialized
INFO - 2026-04-27 09:33:22 --> Language Class Initialized
INFO - 2026-04-27 09:33:22 --> Loader Class Initialized
INFO - 2026-04-27 09:33:22 --> Helper loaded: url_helper
INFO - 2026-04-27 09:33:22 --> Helper loaded: file_helper
INFO - 2026-04-27 09:33:22 --> Helper loaded: form_helper
INFO - 2026-04-27 09:33:22 --> Helper loaded: security_helper
INFO - 2026-04-27 09:33:22 --> Database Driver Class Initialized
INFO - 2026-04-27 09:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:33:22 --> Upload Class Initialized
INFO - 2026-04-27 09:33:22 --> Form Validation Class Initialized
INFO - 2026-04-27 09:33:22 --> Model "M_product" initialized
INFO - 2026-04-27 09:33:22 --> Model "M_settings" initialized
INFO - 2026-04-27 09:33:22 --> Controller Class Initialized
ERROR - 2026-04-27 09:33:22 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:33:22 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:33:22 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:33:22 --> Final output sent to browser
DEBUG - 2026-04-27 09:33:22 --> Total execution time: 0.0957
INFO - 2026-04-27 09:33:42 --> Config Class Initialized
INFO - 2026-04-27 09:33:42 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:33:42 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:33:42 --> Utf8 Class Initialized
INFO - 2026-04-27 09:33:42 --> URI Class Initialized
INFO - 2026-04-27 09:33:42 --> Router Class Initialized
INFO - 2026-04-27 09:33:42 --> Output Class Initialized
INFO - 2026-04-27 09:33:42 --> Security Class Initialized
DEBUG - 2026-04-27 09:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:33:42 --> Input Class Initialized
INFO - 2026-04-27 09:33:42 --> Language Class Initialized
INFO - 2026-04-27 09:33:42 --> Loader Class Initialized
INFO - 2026-04-27 09:33:42 --> Helper loaded: url_helper
INFO - 2026-04-27 09:33:42 --> Helper loaded: file_helper
INFO - 2026-04-27 09:33:42 --> Helper loaded: form_helper
INFO - 2026-04-27 09:33:42 --> Helper loaded: security_helper
INFO - 2026-04-27 09:33:42 --> Database Driver Class Initialized
INFO - 2026-04-27 09:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:33:42 --> Upload Class Initialized
INFO - 2026-04-27 09:33:42 --> Form Validation Class Initialized
INFO - 2026-04-27 09:33:42 --> Model "M_product" initialized
INFO - 2026-04-27 09:33:42 --> Model "M_settings" initialized
INFO - 2026-04-27 09:33:42 --> Controller Class Initialized
ERROR - 2026-04-27 09:33:42 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:33:42 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:33:42 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:33:42 --> Final output sent to browser
DEBUG - 2026-04-27 09:33:42 --> Total execution time: 0.0919
INFO - 2026-04-27 09:33:42 --> Config Class Initialized
INFO - 2026-04-27 09:33:42 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:33:42 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:33:42 --> Utf8 Class Initialized
INFO - 2026-04-27 09:33:42 --> URI Class Initialized
INFO - 2026-04-27 09:33:42 --> Router Class Initialized
INFO - 2026-04-27 09:33:42 --> Output Class Initialized
INFO - 2026-04-27 09:33:42 --> Security Class Initialized
DEBUG - 2026-04-27 09:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:33:42 --> Input Class Initialized
INFO - 2026-04-27 09:33:42 --> Language Class Initialized
INFO - 2026-04-27 09:33:42 --> Loader Class Initialized
INFO - 2026-04-27 09:33:42 --> Helper loaded: url_helper
INFO - 2026-04-27 09:33:42 --> Helper loaded: file_helper
INFO - 2026-04-27 09:33:42 --> Helper loaded: form_helper
INFO - 2026-04-27 09:33:42 --> Helper loaded: security_helper
INFO - 2026-04-27 09:33:42 --> Database Driver Class Initialized
INFO - 2026-04-27 09:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:33:42 --> Upload Class Initialized
INFO - 2026-04-27 09:33:42 --> Form Validation Class Initialized
INFO - 2026-04-27 09:33:42 --> Model "M_product" initialized
INFO - 2026-04-27 09:33:42 --> Model "M_settings" initialized
INFO - 2026-04-27 09:33:42 --> Controller Class Initialized
ERROR - 2026-04-27 09:33:42 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:33:42 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:33:42 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:33:42 --> Final output sent to browser
DEBUG - 2026-04-27 09:33:42 --> Total execution time: 0.0875
INFO - 2026-04-27 09:33:43 --> Config Class Initialized
INFO - 2026-04-27 09:33:43 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:33:43 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:33:43 --> Utf8 Class Initialized
INFO - 2026-04-27 09:33:43 --> URI Class Initialized
INFO - 2026-04-27 09:33:43 --> Router Class Initialized
INFO - 2026-04-27 09:33:43 --> Output Class Initialized
INFO - 2026-04-27 09:33:43 --> Security Class Initialized
DEBUG - 2026-04-27 09:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:33:43 --> Input Class Initialized
INFO - 2026-04-27 09:33:43 --> Language Class Initialized
INFO - 2026-04-27 09:33:43 --> Loader Class Initialized
INFO - 2026-04-27 09:33:43 --> Helper loaded: url_helper
INFO - 2026-04-27 09:33:43 --> Helper loaded: file_helper
INFO - 2026-04-27 09:33:43 --> Helper loaded: form_helper
INFO - 2026-04-27 09:33:43 --> Helper loaded: security_helper
INFO - 2026-04-27 09:33:43 --> Database Driver Class Initialized
INFO - 2026-04-27 09:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:33:43 --> Upload Class Initialized
INFO - 2026-04-27 09:33:43 --> Form Validation Class Initialized
INFO - 2026-04-27 09:33:43 --> Model "M_product" initialized
INFO - 2026-04-27 09:33:43 --> Model "M_settings" initialized
INFO - 2026-04-27 09:33:43 --> Controller Class Initialized
ERROR - 2026-04-27 09:33:43 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:33:43 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:33:43 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:33:43 --> Final output sent to browser
DEBUG - 2026-04-27 09:33:43 --> Total execution time: 0.1005
INFO - 2026-04-27 09:33:43 --> Config Class Initialized
INFO - 2026-04-27 09:33:43 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:33:43 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:33:43 --> Utf8 Class Initialized
INFO - 2026-04-27 09:33:43 --> URI Class Initialized
INFO - 2026-04-27 09:33:43 --> Router Class Initialized
INFO - 2026-04-27 09:33:43 --> Output Class Initialized
INFO - 2026-04-27 09:33:43 --> Security Class Initialized
DEBUG - 2026-04-27 09:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:33:43 --> Input Class Initialized
INFO - 2026-04-27 09:33:43 --> Language Class Initialized
INFO - 2026-04-27 09:33:43 --> Loader Class Initialized
INFO - 2026-04-27 09:33:43 --> Helper loaded: url_helper
INFO - 2026-04-27 09:33:43 --> Helper loaded: file_helper
INFO - 2026-04-27 09:33:43 --> Helper loaded: form_helper
INFO - 2026-04-27 09:33:43 --> Helper loaded: security_helper
INFO - 2026-04-27 09:33:43 --> Database Driver Class Initialized
INFO - 2026-04-27 09:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:33:43 --> Upload Class Initialized
INFO - 2026-04-27 09:33:43 --> Form Validation Class Initialized
INFO - 2026-04-27 09:33:43 --> Model "M_product" initialized
INFO - 2026-04-27 09:33:43 --> Model "M_settings" initialized
INFO - 2026-04-27 09:33:43 --> Controller Class Initialized
ERROR - 2026-04-27 09:33:43 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:33:43 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:33:43 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:33:43 --> Final output sent to browser
DEBUG - 2026-04-27 09:33:43 --> Total execution time: 0.1030
INFO - 2026-04-27 09:34:04 --> Config Class Initialized
INFO - 2026-04-27 09:34:04 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:34:04 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:34:04 --> Utf8 Class Initialized
INFO - 2026-04-27 09:34:04 --> URI Class Initialized
INFO - 2026-04-27 09:34:04 --> Router Class Initialized
INFO - 2026-04-27 09:34:04 --> Output Class Initialized
INFO - 2026-04-27 09:34:04 --> Security Class Initialized
DEBUG - 2026-04-27 09:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:34:04 --> Input Class Initialized
INFO - 2026-04-27 09:34:04 --> Language Class Initialized
INFO - 2026-04-27 09:34:04 --> Loader Class Initialized
INFO - 2026-04-27 09:34:04 --> Helper loaded: url_helper
INFO - 2026-04-27 09:34:04 --> Helper loaded: file_helper
INFO - 2026-04-27 09:34:04 --> Helper loaded: form_helper
INFO - 2026-04-27 09:34:04 --> Helper loaded: security_helper
INFO - 2026-04-27 09:34:04 --> Database Driver Class Initialized
INFO - 2026-04-27 09:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:34:04 --> Upload Class Initialized
INFO - 2026-04-27 09:34:04 --> Form Validation Class Initialized
INFO - 2026-04-27 09:34:04 --> Model "M_product" initialized
INFO - 2026-04-27 09:34:04 --> Model "M_settings" initialized
INFO - 2026-04-27 09:34:04 --> Controller Class Initialized
ERROR - 2026-04-27 09:34:04 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:34:04 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:34:04 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:34:04 --> Final output sent to browser
DEBUG - 2026-04-27 09:34:04 --> Total execution time: 0.0796
INFO - 2026-04-27 09:34:05 --> Config Class Initialized
INFO - 2026-04-27 09:34:05 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:34:05 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:34:05 --> Utf8 Class Initialized
INFO - 2026-04-27 09:34:05 --> URI Class Initialized
INFO - 2026-04-27 09:34:05 --> Router Class Initialized
INFO - 2026-04-27 09:34:05 --> Output Class Initialized
INFO - 2026-04-27 09:34:05 --> Security Class Initialized
DEBUG - 2026-04-27 09:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:34:05 --> Input Class Initialized
INFO - 2026-04-27 09:34:05 --> Language Class Initialized
INFO - 2026-04-27 09:34:05 --> Loader Class Initialized
INFO - 2026-04-27 09:34:05 --> Helper loaded: url_helper
INFO - 2026-04-27 09:34:05 --> Helper loaded: file_helper
INFO - 2026-04-27 09:34:05 --> Helper loaded: form_helper
INFO - 2026-04-27 09:34:05 --> Helper loaded: security_helper
INFO - 2026-04-27 09:34:05 --> Database Driver Class Initialized
INFO - 2026-04-27 09:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:34:05 --> Upload Class Initialized
INFO - 2026-04-27 09:34:05 --> Form Validation Class Initialized
INFO - 2026-04-27 09:34:05 --> Model "M_product" initialized
INFO - 2026-04-27 09:34:05 --> Model "M_settings" initialized
INFO - 2026-04-27 09:34:05 --> Controller Class Initialized
ERROR - 2026-04-27 09:34:05 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:34:05 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:34:05 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:34:05 --> Final output sent to browser
DEBUG - 2026-04-27 09:34:05 --> Total execution time: 0.0877
INFO - 2026-04-27 09:34:35 --> Config Class Initialized
INFO - 2026-04-27 09:34:35 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:34:35 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:34:35 --> Utf8 Class Initialized
INFO - 2026-04-27 09:34:35 --> URI Class Initialized
INFO - 2026-04-27 09:34:35 --> Router Class Initialized
INFO - 2026-04-27 09:34:35 --> Output Class Initialized
INFO - 2026-04-27 09:34:35 --> Security Class Initialized
DEBUG - 2026-04-27 09:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:34:35 --> Input Class Initialized
INFO - 2026-04-27 09:34:35 --> Language Class Initialized
INFO - 2026-04-27 09:34:35 --> Loader Class Initialized
INFO - 2026-04-27 09:34:35 --> Helper loaded: url_helper
INFO - 2026-04-27 09:34:35 --> Helper loaded: file_helper
INFO - 2026-04-27 09:34:35 --> Helper loaded: form_helper
INFO - 2026-04-27 09:34:35 --> Helper loaded: security_helper
INFO - 2026-04-27 09:34:35 --> Database Driver Class Initialized
INFO - 2026-04-27 09:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:34:35 --> Upload Class Initialized
INFO - 2026-04-27 09:34:35 --> Form Validation Class Initialized
INFO - 2026-04-27 09:34:35 --> Model "M_product" initialized
INFO - 2026-04-27 09:34:35 --> Model "M_settings" initialized
INFO - 2026-04-27 09:34:35 --> Controller Class Initialized
ERROR - 2026-04-27 09:34:35 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:34:35 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:34:35 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:34:35 --> Final output sent to browser
DEBUG - 2026-04-27 09:34:35 --> Total execution time: 0.0915
INFO - 2026-04-27 09:34:36 --> Config Class Initialized
INFO - 2026-04-27 09:34:36 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:34:36 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:34:36 --> Utf8 Class Initialized
INFO - 2026-04-27 09:34:36 --> URI Class Initialized
INFO - 2026-04-27 09:34:36 --> Router Class Initialized
INFO - 2026-04-27 09:34:36 --> Output Class Initialized
INFO - 2026-04-27 09:34:36 --> Security Class Initialized
DEBUG - 2026-04-27 09:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:34:36 --> Input Class Initialized
INFO - 2026-04-27 09:34:36 --> Language Class Initialized
INFO - 2026-04-27 09:34:36 --> Loader Class Initialized
INFO - 2026-04-27 09:34:36 --> Helper loaded: url_helper
INFO - 2026-04-27 09:34:36 --> Helper loaded: file_helper
INFO - 2026-04-27 09:34:36 --> Helper loaded: form_helper
INFO - 2026-04-27 09:34:36 --> Helper loaded: security_helper
INFO - 2026-04-27 09:34:36 --> Database Driver Class Initialized
INFO - 2026-04-27 09:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:34:36 --> Upload Class Initialized
INFO - 2026-04-27 09:34:36 --> Form Validation Class Initialized
INFO - 2026-04-27 09:34:36 --> Model "M_product" initialized
INFO - 2026-04-27 09:34:36 --> Model "M_settings" initialized
INFO - 2026-04-27 09:34:36 --> Controller Class Initialized
ERROR - 2026-04-27 09:34:36 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:34:36 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:34:36 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:34:36 --> Final output sent to browser
DEBUG - 2026-04-27 09:34:36 --> Total execution time: 0.1077
INFO - 2026-04-27 09:34:36 --> Config Class Initialized
INFO - 2026-04-27 09:34:36 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:34:36 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:34:36 --> Utf8 Class Initialized
INFO - 2026-04-27 09:34:36 --> URI Class Initialized
INFO - 2026-04-27 09:34:36 --> Router Class Initialized
INFO - 2026-04-27 09:34:36 --> Output Class Initialized
INFO - 2026-04-27 09:34:36 --> Security Class Initialized
DEBUG - 2026-04-27 09:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:34:36 --> Input Class Initialized
INFO - 2026-04-27 09:34:36 --> Language Class Initialized
INFO - 2026-04-27 09:34:36 --> Loader Class Initialized
INFO - 2026-04-27 09:34:36 --> Helper loaded: url_helper
INFO - 2026-04-27 09:34:36 --> Helper loaded: file_helper
INFO - 2026-04-27 09:34:36 --> Helper loaded: form_helper
INFO - 2026-04-27 09:34:36 --> Helper loaded: security_helper
INFO - 2026-04-27 09:34:36 --> Database Driver Class Initialized
INFO - 2026-04-27 09:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:34:36 --> Upload Class Initialized
INFO - 2026-04-27 09:34:36 --> Form Validation Class Initialized
INFO - 2026-04-27 09:34:36 --> Model "M_product" initialized
INFO - 2026-04-27 09:34:36 --> Model "M_settings" initialized
INFO - 2026-04-27 09:34:36 --> Controller Class Initialized
ERROR - 2026-04-27 09:34:36 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:34:36 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:34:36 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:34:36 --> Final output sent to browser
DEBUG - 2026-04-27 09:34:36 --> Total execution time: 0.1255
INFO - 2026-04-27 09:34:36 --> Config Class Initialized
INFO - 2026-04-27 09:34:36 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:34:36 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:34:36 --> Utf8 Class Initialized
INFO - 2026-04-27 09:34:36 --> URI Class Initialized
INFO - 2026-04-27 09:34:36 --> Router Class Initialized
INFO - 2026-04-27 09:34:36 --> Output Class Initialized
INFO - 2026-04-27 09:34:36 --> Security Class Initialized
DEBUG - 2026-04-27 09:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:34:36 --> Input Class Initialized
INFO - 2026-04-27 09:34:36 --> Language Class Initialized
INFO - 2026-04-27 09:34:36 --> Loader Class Initialized
INFO - 2026-04-27 09:34:36 --> Helper loaded: url_helper
INFO - 2026-04-27 09:34:36 --> Helper loaded: file_helper
INFO - 2026-04-27 09:34:36 --> Helper loaded: form_helper
INFO - 2026-04-27 09:34:36 --> Helper loaded: security_helper
INFO - 2026-04-27 09:34:36 --> Database Driver Class Initialized
INFO - 2026-04-27 09:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:34:36 --> Upload Class Initialized
INFO - 2026-04-27 09:34:36 --> Form Validation Class Initialized
INFO - 2026-04-27 09:34:36 --> Model "M_product" initialized
INFO - 2026-04-27 09:34:36 --> Model "M_settings" initialized
INFO - 2026-04-27 09:34:36 --> Controller Class Initialized
ERROR - 2026-04-27 09:34:36 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:34:36 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:34:36 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:34:36 --> Final output sent to browser
DEBUG - 2026-04-27 09:34:36 --> Total execution time: 0.0997
INFO - 2026-04-27 09:34:57 --> Config Class Initialized
INFO - 2026-04-27 09:34:57 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:34:57 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:34:57 --> Utf8 Class Initialized
INFO - 2026-04-27 09:34:57 --> URI Class Initialized
INFO - 2026-04-27 09:34:57 --> Router Class Initialized
INFO - 2026-04-27 09:34:57 --> Output Class Initialized
INFO - 2026-04-27 09:34:57 --> Security Class Initialized
DEBUG - 2026-04-27 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:34:57 --> Input Class Initialized
INFO - 2026-04-27 09:34:57 --> Language Class Initialized
INFO - 2026-04-27 09:34:57 --> Loader Class Initialized
INFO - 2026-04-27 09:34:57 --> Helper loaded: url_helper
INFO - 2026-04-27 09:34:57 --> Helper loaded: file_helper
INFO - 2026-04-27 09:34:57 --> Helper loaded: form_helper
INFO - 2026-04-27 09:34:57 --> Helper loaded: security_helper
INFO - 2026-04-27 09:34:57 --> Database Driver Class Initialized
INFO - 2026-04-27 09:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:34:57 --> Upload Class Initialized
INFO - 2026-04-27 09:34:57 --> Form Validation Class Initialized
INFO - 2026-04-27 09:34:57 --> Model "M_product" initialized
INFO - 2026-04-27 09:34:57 --> Model "M_settings" initialized
INFO - 2026-04-27 09:34:57 --> Controller Class Initialized
ERROR - 2026-04-27 09:34:57 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:34:57 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:34:57 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:34:57 --> Final output sent to browser
DEBUG - 2026-04-27 09:34:57 --> Total execution time: 0.0887
INFO - 2026-04-27 09:35:48 --> Config Class Initialized
INFO - 2026-04-27 09:35:48 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:48 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:48 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:48 --> URI Class Initialized
INFO - 2026-04-27 09:35:48 --> Router Class Initialized
INFO - 2026-04-27 09:35:48 --> Output Class Initialized
INFO - 2026-04-27 09:35:48 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:48 --> Input Class Initialized
INFO - 2026-04-27 09:35:48 --> Language Class Initialized
INFO - 2026-04-27 09:35:48 --> Loader Class Initialized
INFO - 2026-04-27 09:35:48 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:48 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:48 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:48 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:48 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:48 --> Upload Class Initialized
INFO - 2026-04-27 09:35:48 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:48 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:48 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:48 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:48 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:48 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:48 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:48 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:48 --> Total execution time: 0.0945
INFO - 2026-04-27 09:35:49 --> Config Class Initialized
INFO - 2026-04-27 09:35:49 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:49 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:49 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:49 --> URI Class Initialized
INFO - 2026-04-27 09:35:49 --> Router Class Initialized
INFO - 2026-04-27 09:35:49 --> Output Class Initialized
INFO - 2026-04-27 09:35:49 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:49 --> Input Class Initialized
INFO - 2026-04-27 09:35:49 --> Language Class Initialized
INFO - 2026-04-27 09:35:49 --> Loader Class Initialized
INFO - 2026-04-27 09:35:49 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:49 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:49 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:49 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:49 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:49 --> Upload Class Initialized
INFO - 2026-04-27 09:35:49 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:49 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:49 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:49 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:49 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:49 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:49 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:49 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:49 --> Total execution time: 0.0866
INFO - 2026-04-27 09:35:49 --> Config Class Initialized
INFO - 2026-04-27 09:35:49 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:49 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:49 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:49 --> URI Class Initialized
INFO - 2026-04-27 09:35:49 --> Router Class Initialized
INFO - 2026-04-27 09:35:49 --> Output Class Initialized
INFO - 2026-04-27 09:35:49 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:49 --> Input Class Initialized
INFO - 2026-04-27 09:35:49 --> Language Class Initialized
INFO - 2026-04-27 09:35:49 --> Loader Class Initialized
INFO - 2026-04-27 09:35:49 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:49 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:49 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:49 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:49 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:49 --> Upload Class Initialized
INFO - 2026-04-27 09:35:49 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:49 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:49 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:49 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:49 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:49 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:49 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:49 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:49 --> Total execution time: 0.0880
INFO - 2026-04-27 09:35:49 --> Config Class Initialized
INFO - 2026-04-27 09:35:49 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:49 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:49 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:49 --> URI Class Initialized
INFO - 2026-04-27 09:35:49 --> Router Class Initialized
INFO - 2026-04-27 09:35:49 --> Output Class Initialized
INFO - 2026-04-27 09:35:49 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:49 --> Input Class Initialized
INFO - 2026-04-27 09:35:49 --> Language Class Initialized
INFO - 2026-04-27 09:35:49 --> Loader Class Initialized
INFO - 2026-04-27 09:35:49 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:49 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:49 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:49 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:49 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:49 --> Upload Class Initialized
INFO - 2026-04-27 09:35:49 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:49 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:49 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:49 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:49 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:49 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:49 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:49 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:49 --> Total execution time: 0.1052
INFO - 2026-04-27 09:35:49 --> Config Class Initialized
INFO - 2026-04-27 09:35:49 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:49 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:49 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:49 --> URI Class Initialized
INFO - 2026-04-27 09:35:49 --> Router Class Initialized
INFO - 2026-04-27 09:35:49 --> Output Class Initialized
INFO - 2026-04-27 09:35:49 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:49 --> Input Class Initialized
INFO - 2026-04-27 09:35:49 --> Language Class Initialized
INFO - 2026-04-27 09:35:50 --> Loader Class Initialized
INFO - 2026-04-27 09:35:50 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:50 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:50 --> Upload Class Initialized
INFO - 2026-04-27 09:35:50 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:50 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:50 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:50 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:50 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:50 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:50 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:50 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:50 --> Total execution time: 0.0939
INFO - 2026-04-27 09:35:50 --> Config Class Initialized
INFO - 2026-04-27 09:35:50 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:50 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:50 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:50 --> URI Class Initialized
INFO - 2026-04-27 09:35:50 --> Router Class Initialized
INFO - 2026-04-27 09:35:50 --> Output Class Initialized
INFO - 2026-04-27 09:35:50 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:50 --> Input Class Initialized
INFO - 2026-04-27 09:35:50 --> Language Class Initialized
INFO - 2026-04-27 09:35:50 --> Loader Class Initialized
INFO - 2026-04-27 09:35:50 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:50 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:50 --> Upload Class Initialized
INFO - 2026-04-27 09:35:50 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:50 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:50 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:50 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:50 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:50 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:50 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:50 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:50 --> Total execution time: 0.1143
INFO - 2026-04-27 09:35:50 --> Config Class Initialized
INFO - 2026-04-27 09:35:50 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:50 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:50 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:50 --> URI Class Initialized
INFO - 2026-04-27 09:35:50 --> Router Class Initialized
INFO - 2026-04-27 09:35:50 --> Output Class Initialized
INFO - 2026-04-27 09:35:50 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:50 --> Input Class Initialized
INFO - 2026-04-27 09:35:50 --> Language Class Initialized
INFO - 2026-04-27 09:35:50 --> Loader Class Initialized
INFO - 2026-04-27 09:35:50 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:50 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:50 --> Upload Class Initialized
INFO - 2026-04-27 09:35:50 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:50 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:50 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:50 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:50 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:50 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:50 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:50 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:50 --> Total execution time: 0.0928
INFO - 2026-04-27 09:35:50 --> Config Class Initialized
INFO - 2026-04-27 09:35:50 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:50 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:50 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:50 --> URI Class Initialized
INFO - 2026-04-27 09:35:50 --> Router Class Initialized
INFO - 2026-04-27 09:35:50 --> Output Class Initialized
INFO - 2026-04-27 09:35:50 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:50 --> Input Class Initialized
INFO - 2026-04-27 09:35:50 --> Language Class Initialized
INFO - 2026-04-27 09:35:50 --> Loader Class Initialized
INFO - 2026-04-27 09:35:50 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:50 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:50 --> Upload Class Initialized
INFO - 2026-04-27 09:35:50 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:50 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:50 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:50 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:50 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:50 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:50 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:50 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:50 --> Total execution time: 0.0902
INFO - 2026-04-27 09:35:50 --> Config Class Initialized
INFO - 2026-04-27 09:35:50 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:50 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:50 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:50 --> URI Class Initialized
INFO - 2026-04-27 09:35:50 --> Router Class Initialized
INFO - 2026-04-27 09:35:50 --> Output Class Initialized
INFO - 2026-04-27 09:35:50 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:50 --> Input Class Initialized
INFO - 2026-04-27 09:35:50 --> Language Class Initialized
INFO - 2026-04-27 09:35:50 --> Loader Class Initialized
INFO - 2026-04-27 09:35:50 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:50 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:50 --> Upload Class Initialized
INFO - 2026-04-27 09:35:50 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:50 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:50 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:50 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:50 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:50 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:50 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:50 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:50 --> Total execution time: 0.1111
INFO - 2026-04-27 09:35:50 --> Config Class Initialized
INFO - 2026-04-27 09:35:50 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:50 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:50 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:50 --> URI Class Initialized
INFO - 2026-04-27 09:35:50 --> Router Class Initialized
INFO - 2026-04-27 09:35:50 --> Output Class Initialized
INFO - 2026-04-27 09:35:50 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:50 --> Input Class Initialized
INFO - 2026-04-27 09:35:50 --> Language Class Initialized
INFO - 2026-04-27 09:35:50 --> Loader Class Initialized
INFO - 2026-04-27 09:35:50 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:50 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:50 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:50 --> Upload Class Initialized
INFO - 2026-04-27 09:35:50 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:50 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:50 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:50 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:50 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:50 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:50 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:50 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:50 --> Total execution time: 0.0943
INFO - 2026-04-27 09:35:51 --> Config Class Initialized
INFO - 2026-04-27 09:35:51 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:51 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:51 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:51 --> URI Class Initialized
INFO - 2026-04-27 09:35:51 --> Router Class Initialized
INFO - 2026-04-27 09:35:51 --> Output Class Initialized
INFO - 2026-04-27 09:35:51 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:51 --> Input Class Initialized
INFO - 2026-04-27 09:35:51 --> Language Class Initialized
INFO - 2026-04-27 09:35:51 --> Loader Class Initialized
INFO - 2026-04-27 09:35:51 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:51 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:51 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:51 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:51 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:51 --> Upload Class Initialized
INFO - 2026-04-27 09:35:51 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:51 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:51 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:51 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:51 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:51 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:51 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:51 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:51 --> Total execution time: 0.1075
INFO - 2026-04-27 09:35:51 --> Config Class Initialized
INFO - 2026-04-27 09:35:51 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:51 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:51 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:51 --> URI Class Initialized
INFO - 2026-04-27 09:35:51 --> Router Class Initialized
INFO - 2026-04-27 09:35:51 --> Output Class Initialized
INFO - 2026-04-27 09:35:51 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:51 --> Input Class Initialized
INFO - 2026-04-27 09:35:51 --> Language Class Initialized
INFO - 2026-04-27 09:35:51 --> Loader Class Initialized
INFO - 2026-04-27 09:35:51 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:51 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:51 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:51 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:51 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:51 --> Upload Class Initialized
INFO - 2026-04-27 09:35:51 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:51 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:51 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:51 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:51 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:51 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:51 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:51 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:51 --> Total execution time: 0.0992
INFO - 2026-04-27 09:35:51 --> Config Class Initialized
INFO - 2026-04-27 09:35:51 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:51 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:51 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:51 --> URI Class Initialized
INFO - 2026-04-27 09:35:51 --> Router Class Initialized
INFO - 2026-04-27 09:35:51 --> Output Class Initialized
INFO - 2026-04-27 09:35:51 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:51 --> Input Class Initialized
INFO - 2026-04-27 09:35:51 --> Language Class Initialized
INFO - 2026-04-27 09:35:51 --> Loader Class Initialized
INFO - 2026-04-27 09:35:51 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:51 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:51 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:51 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:51 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:51 --> Upload Class Initialized
INFO - 2026-04-27 09:35:51 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:51 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:51 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:51 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:51 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:51 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:51 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:51 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:51 --> Total execution time: 0.1114
INFO - 2026-04-27 09:35:52 --> Config Class Initialized
INFO - 2026-04-27 09:35:52 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:52 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:52 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:52 --> URI Class Initialized
INFO - 2026-04-27 09:35:52 --> Router Class Initialized
INFO - 2026-04-27 09:35:52 --> Output Class Initialized
INFO - 2026-04-27 09:35:52 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:52 --> Input Class Initialized
INFO - 2026-04-27 09:35:52 --> Language Class Initialized
INFO - 2026-04-27 09:35:52 --> Loader Class Initialized
INFO - 2026-04-27 09:35:52 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:52 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:52 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:52 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:52 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:52 --> Upload Class Initialized
INFO - 2026-04-27 09:35:52 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:52 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:52 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:52 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:52 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:52 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:52 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:52 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:52 --> Total execution time: 0.0883
INFO - 2026-04-27 09:35:52 --> Config Class Initialized
INFO - 2026-04-27 09:35:52 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:52 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:52 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:52 --> URI Class Initialized
INFO - 2026-04-27 09:35:52 --> Router Class Initialized
INFO - 2026-04-27 09:35:52 --> Output Class Initialized
INFO - 2026-04-27 09:35:52 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:52 --> Input Class Initialized
INFO - 2026-04-27 09:35:52 --> Language Class Initialized
INFO - 2026-04-27 09:35:52 --> Loader Class Initialized
INFO - 2026-04-27 09:35:52 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:52 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:52 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:52 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:52 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:52 --> Upload Class Initialized
INFO - 2026-04-27 09:35:52 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:52 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:52 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:52 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:52 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:52 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:52 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:52 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:52 --> Total execution time: 0.1032
INFO - 2026-04-27 09:35:52 --> Config Class Initialized
INFO - 2026-04-27 09:35:52 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:52 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:52 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:52 --> URI Class Initialized
INFO - 2026-04-27 09:35:52 --> Router Class Initialized
INFO - 2026-04-27 09:35:52 --> Output Class Initialized
INFO - 2026-04-27 09:35:52 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:52 --> Input Class Initialized
INFO - 2026-04-27 09:35:52 --> Language Class Initialized
INFO - 2026-04-27 09:35:52 --> Loader Class Initialized
INFO - 2026-04-27 09:35:52 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:52 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:52 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:52 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:52 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:52 --> Upload Class Initialized
INFO - 2026-04-27 09:35:52 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:52 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:52 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:52 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:52 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:52 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:52 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:52 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:52 --> Total execution time: 0.1109
INFO - 2026-04-27 09:35:52 --> Config Class Initialized
INFO - 2026-04-27 09:35:52 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:35:52 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:35:52 --> Utf8 Class Initialized
INFO - 2026-04-27 09:35:52 --> URI Class Initialized
INFO - 2026-04-27 09:35:52 --> Router Class Initialized
INFO - 2026-04-27 09:35:52 --> Output Class Initialized
INFO - 2026-04-27 09:35:52 --> Security Class Initialized
DEBUG - 2026-04-27 09:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:35:52 --> Input Class Initialized
INFO - 2026-04-27 09:35:52 --> Language Class Initialized
INFO - 2026-04-27 09:35:52 --> Loader Class Initialized
INFO - 2026-04-27 09:35:52 --> Helper loaded: url_helper
INFO - 2026-04-27 09:35:52 --> Helper loaded: file_helper
INFO - 2026-04-27 09:35:52 --> Helper loaded: form_helper
INFO - 2026-04-27 09:35:52 --> Helper loaded: security_helper
INFO - 2026-04-27 09:35:52 --> Database Driver Class Initialized
INFO - 2026-04-27 09:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:35:52 --> Upload Class Initialized
INFO - 2026-04-27 09:35:52 --> Form Validation Class Initialized
INFO - 2026-04-27 09:35:52 --> Model "M_product" initialized
INFO - 2026-04-27 09:35:52 --> Model "M_settings" initialized
INFO - 2026-04-27 09:35:52 --> Controller Class Initialized
ERROR - 2026-04-27 09:35:52 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:35:52 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:35:52 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:35:52 --> Final output sent to browser
DEBUG - 2026-04-27 09:35:52 --> Total execution time: 0.0882
INFO - 2026-04-27 09:36:32 --> Config Class Initialized
INFO - 2026-04-27 09:36:32 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:36:32 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:36:32 --> Utf8 Class Initialized
INFO - 2026-04-27 09:36:32 --> URI Class Initialized
INFO - 2026-04-27 09:36:32 --> Router Class Initialized
INFO - 2026-04-27 09:36:32 --> Output Class Initialized
INFO - 2026-04-27 09:36:32 --> Security Class Initialized
DEBUG - 2026-04-27 09:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:36:32 --> Input Class Initialized
INFO - 2026-04-27 09:36:32 --> Language Class Initialized
INFO - 2026-04-27 09:36:32 --> Loader Class Initialized
INFO - 2026-04-27 09:36:32 --> Helper loaded: url_helper
INFO - 2026-04-27 09:36:32 --> Helper loaded: file_helper
INFO - 2026-04-27 09:36:32 --> Helper loaded: form_helper
INFO - 2026-04-27 09:36:32 --> Helper loaded: security_helper
INFO - 2026-04-27 09:36:32 --> Database Driver Class Initialized
INFO - 2026-04-27 09:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:36:32 --> Upload Class Initialized
INFO - 2026-04-27 09:36:32 --> Form Validation Class Initialized
INFO - 2026-04-27 09:36:32 --> Model "M_product" initialized
INFO - 2026-04-27 09:36:32 --> Model "M_settings" initialized
INFO - 2026-04-27 09:36:32 --> Controller Class Initialized
ERROR - 2026-04-27 09:36:32 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:36:32 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:36:32 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:36:32 --> Final output sent to browser
DEBUG - 2026-04-27 09:36:32 --> Total execution time: 0.1574
INFO - 2026-04-27 09:38:01 --> Config Class Initialized
INFO - 2026-04-27 09:38:01 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:38:01 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:38:01 --> Utf8 Class Initialized
INFO - 2026-04-27 09:38:01 --> URI Class Initialized
INFO - 2026-04-27 09:38:01 --> Router Class Initialized
INFO - 2026-04-27 09:38:01 --> Output Class Initialized
INFO - 2026-04-27 09:38:01 --> Security Class Initialized
DEBUG - 2026-04-27 09:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:38:01 --> Input Class Initialized
INFO - 2026-04-27 09:38:01 --> Language Class Initialized
INFO - 2026-04-27 09:38:01 --> Loader Class Initialized
INFO - 2026-04-27 09:38:01 --> Helper loaded: url_helper
INFO - 2026-04-27 09:38:01 --> Helper loaded: file_helper
INFO - 2026-04-27 09:38:01 --> Helper loaded: form_helper
INFO - 2026-04-27 09:38:01 --> Helper loaded: security_helper
INFO - 2026-04-27 09:38:01 --> Database Driver Class Initialized
INFO - 2026-04-27 09:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:38:01 --> Upload Class Initialized
INFO - 2026-04-27 09:38:01 --> Form Validation Class Initialized
INFO - 2026-04-27 09:38:01 --> Model "M_product" initialized
INFO - 2026-04-27 09:38:01 --> Model "M_settings" initialized
INFO - 2026-04-27 09:38:01 --> Controller Class Initialized
ERROR - 2026-04-27 09:38:01 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:38:01 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:38:01 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:38:01 --> Final output sent to browser
DEBUG - 2026-04-27 09:38:01 --> Total execution time: 0.0952
INFO - 2026-04-27 09:38:10 --> Config Class Initialized
INFO - 2026-04-27 09:38:10 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:38:10 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:38:10 --> Utf8 Class Initialized
INFO - 2026-04-27 09:38:10 --> URI Class Initialized
INFO - 2026-04-27 09:38:10 --> Router Class Initialized
INFO - 2026-04-27 09:38:10 --> Output Class Initialized
INFO - 2026-04-27 09:38:10 --> Security Class Initialized
DEBUG - 2026-04-27 09:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:38:10 --> Input Class Initialized
INFO - 2026-04-27 09:38:10 --> Language Class Initialized
INFO - 2026-04-27 09:38:10 --> Loader Class Initialized
INFO - 2026-04-27 09:38:10 --> Helper loaded: url_helper
INFO - 2026-04-27 09:38:10 --> Helper loaded: file_helper
INFO - 2026-04-27 09:38:10 --> Helper loaded: form_helper
INFO - 2026-04-27 09:38:10 --> Helper loaded: security_helper
INFO - 2026-04-27 09:38:10 --> Database Driver Class Initialized
INFO - 2026-04-27 09:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:38:10 --> Upload Class Initialized
INFO - 2026-04-27 09:38:10 --> Form Validation Class Initialized
INFO - 2026-04-27 09:38:10 --> Model "M_product" initialized
INFO - 2026-04-27 09:38:10 --> Model "M_settings" initialized
INFO - 2026-04-27 09:38:10 --> Controller Class Initialized
ERROR - 2026-04-27 09:38:10 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:38:10 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:38:10 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:38:10 --> Final output sent to browser
DEBUG - 2026-04-27 09:38:10 --> Total execution time: 0.1069
INFO - 2026-04-27 09:39:07 --> Config Class Initialized
INFO - 2026-04-27 09:39:07 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:39:07 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:39:07 --> Utf8 Class Initialized
INFO - 2026-04-27 09:39:07 --> URI Class Initialized
INFO - 2026-04-27 09:39:07 --> Router Class Initialized
INFO - 2026-04-27 09:39:07 --> Output Class Initialized
INFO - 2026-04-27 09:39:08 --> Security Class Initialized
DEBUG - 2026-04-27 09:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:39:08 --> Input Class Initialized
INFO - 2026-04-27 09:39:08 --> Language Class Initialized
INFO - 2026-04-27 09:39:08 --> Loader Class Initialized
INFO - 2026-04-27 09:39:08 --> Helper loaded: url_helper
INFO - 2026-04-27 09:39:08 --> Helper loaded: file_helper
INFO - 2026-04-27 09:39:08 --> Helper loaded: form_helper
INFO - 2026-04-27 09:39:08 --> Helper loaded: security_helper
INFO - 2026-04-27 09:39:08 --> Database Driver Class Initialized
INFO - 2026-04-27 09:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:39:08 --> Upload Class Initialized
INFO - 2026-04-27 09:39:08 --> Form Validation Class Initialized
INFO - 2026-04-27 09:39:08 --> Model "M_product" initialized
INFO - 2026-04-27 09:39:08 --> Model "M_settings" initialized
INFO - 2026-04-27 09:39:08 --> Controller Class Initialized
ERROR - 2026-04-27 09:39:08 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\macha\application\views\dashboard.php 63
INFO - 2026-04-27 09:39:08 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:39:08 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:39:08 --> Final output sent to browser
DEBUG - 2026-04-27 09:39:08 --> Total execution time: 0.1006
INFO - 2026-04-27 09:40:43 --> Config Class Initialized
INFO - 2026-04-27 09:40:43 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:40:43 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:40:43 --> Utf8 Class Initialized
INFO - 2026-04-27 09:40:43 --> URI Class Initialized
INFO - 2026-04-27 09:40:43 --> Router Class Initialized
INFO - 2026-04-27 09:40:43 --> Output Class Initialized
INFO - 2026-04-27 09:40:43 --> Security Class Initialized
DEBUG - 2026-04-27 09:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:40:43 --> Input Class Initialized
INFO - 2026-04-27 09:40:43 --> Language Class Initialized
INFO - 2026-04-27 09:40:43 --> Loader Class Initialized
INFO - 2026-04-27 09:40:43 --> Helper loaded: url_helper
INFO - 2026-04-27 09:40:43 --> Helper loaded: file_helper
INFO - 2026-04-27 09:40:43 --> Helper loaded: form_helper
INFO - 2026-04-27 09:40:43 --> Helper loaded: security_helper
INFO - 2026-04-27 09:40:43 --> Database Driver Class Initialized
INFO - 2026-04-27 09:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:40:43 --> Upload Class Initialized
INFO - 2026-04-27 09:40:43 --> Form Validation Class Initialized
INFO - 2026-04-27 09:40:43 --> Model "M_product" initialized
INFO - 2026-04-27 09:40:43 --> Model "M_settings" initialized
INFO - 2026-04-27 09:40:43 --> Controller Class Initialized
ERROR - 2026-04-27 09:40:43 --> Query error: Unknown column 'pending' in 'where clause' - Invalid query: SELECT SUM(`total_price`) AS `total_price`
FROM `sales`
WHERE DATE(created_at) = '2026-04-27'
AND status =  pending
INFO - 2026-04-27 09:40:43 --> Language file loaded: language/english/db_lang.php
INFO - 2026-04-27 09:41:06 --> Config Class Initialized
INFO - 2026-04-27 09:41:06 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:41:06 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:41:06 --> Utf8 Class Initialized
INFO - 2026-04-27 09:41:06 --> URI Class Initialized
INFO - 2026-04-27 09:41:06 --> Router Class Initialized
INFO - 2026-04-27 09:41:06 --> Output Class Initialized
INFO - 2026-04-27 09:41:06 --> Security Class Initialized
DEBUG - 2026-04-27 09:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:41:06 --> Input Class Initialized
INFO - 2026-04-27 09:41:06 --> Language Class Initialized
INFO - 2026-04-27 09:41:06 --> Loader Class Initialized
INFO - 2026-04-27 09:41:06 --> Helper loaded: url_helper
INFO - 2026-04-27 09:41:06 --> Helper loaded: file_helper
INFO - 2026-04-27 09:41:06 --> Helper loaded: form_helper
INFO - 2026-04-27 09:41:06 --> Helper loaded: security_helper
INFO - 2026-04-27 09:41:06 --> Database Driver Class Initialized
INFO - 2026-04-27 09:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:41:06 --> Upload Class Initialized
INFO - 2026-04-27 09:41:06 --> Form Validation Class Initialized
INFO - 2026-04-27 09:41:06 --> Model "M_product" initialized
INFO - 2026-04-27 09:41:06 --> Model "M_settings" initialized
INFO - 2026-04-27 09:41:06 --> Controller Class Initialized
ERROR - 2026-04-27 09:41:06 --> Query error: Unknown column 'pending' in 'where clause' - Invalid query: SELECT SUM(`total_price`) AS `total_price`
FROM `sales`
WHERE DATE(created_at) = '2026-04-27'
AND status =  pending
INFO - 2026-04-27 09:41:06 --> Language file loaded: language/english/db_lang.php
INFO - 2026-04-27 09:41:07 --> Config Class Initialized
INFO - 2026-04-27 09:41:07 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:41:07 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:41:07 --> Utf8 Class Initialized
INFO - 2026-04-27 09:41:07 --> URI Class Initialized
INFO - 2026-04-27 09:41:07 --> Router Class Initialized
INFO - 2026-04-27 09:41:07 --> Output Class Initialized
INFO - 2026-04-27 09:41:07 --> Security Class Initialized
DEBUG - 2026-04-27 09:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:41:07 --> Input Class Initialized
INFO - 2026-04-27 09:41:07 --> Language Class Initialized
INFO - 2026-04-27 09:41:07 --> Loader Class Initialized
INFO - 2026-04-27 09:41:07 --> Helper loaded: url_helper
INFO - 2026-04-27 09:41:07 --> Helper loaded: file_helper
INFO - 2026-04-27 09:41:07 --> Helper loaded: form_helper
INFO - 2026-04-27 09:41:07 --> Helper loaded: security_helper
INFO - 2026-04-27 09:41:07 --> Database Driver Class Initialized
INFO - 2026-04-27 09:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:41:07 --> Upload Class Initialized
INFO - 2026-04-27 09:41:07 --> Form Validation Class Initialized
INFO - 2026-04-27 09:41:07 --> Model "M_product" initialized
INFO - 2026-04-27 09:41:07 --> Model "M_settings" initialized
INFO - 2026-04-27 09:41:07 --> Controller Class Initialized
ERROR - 2026-04-27 09:41:07 --> Query error: Unknown column 'pending' in 'where clause' - Invalid query: SELECT SUM(`total_price`) AS `total_price`
FROM `sales`
WHERE DATE(created_at) = '2026-04-27'
AND status =  pending
INFO - 2026-04-27 09:41:07 --> Language file loaded: language/english/db_lang.php
INFO - 2026-04-27 09:41:44 --> Config Class Initialized
INFO - 2026-04-27 09:41:44 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:41:44 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:41:44 --> Utf8 Class Initialized
INFO - 2026-04-27 09:41:44 --> URI Class Initialized
INFO - 2026-04-27 09:41:44 --> Router Class Initialized
INFO - 2026-04-27 09:41:44 --> Output Class Initialized
INFO - 2026-04-27 09:41:44 --> Security Class Initialized
DEBUG - 2026-04-27 09:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:41:44 --> Input Class Initialized
INFO - 2026-04-27 09:41:44 --> Language Class Initialized
INFO - 2026-04-27 09:41:44 --> Loader Class Initialized
INFO - 2026-04-27 09:41:44 --> Helper loaded: url_helper
INFO - 2026-04-27 09:41:44 --> Helper loaded: file_helper
INFO - 2026-04-27 09:41:44 --> Helper loaded: form_helper
INFO - 2026-04-27 09:41:44 --> Helper loaded: security_helper
INFO - 2026-04-27 09:41:44 --> Database Driver Class Initialized
INFO - 2026-04-27 09:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:41:44 --> Upload Class Initialized
INFO - 2026-04-27 09:41:44 --> Form Validation Class Initialized
INFO - 2026-04-27 09:41:44 --> Model "M_product" initialized
INFO - 2026-04-27 09:41:44 --> Model "M_settings" initialized
INFO - 2026-04-27 09:41:44 --> Controller Class Initialized
ERROR - 2026-04-27 09:41:44 --> Query error: Unknown column 'pending' in 'where clause' - Invalid query: SELECT SUM(`total_price`) AS `total_price`
FROM `sales`
WHERE DATE(created_at) = '2026-04-27'
AND status =  pending
INFO - 2026-04-27 09:41:44 --> Language file loaded: language/english/db_lang.php
INFO - 2026-04-27 09:41:45 --> Config Class Initialized
INFO - 2026-04-27 09:41:45 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:41:45 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:41:45 --> Utf8 Class Initialized
INFO - 2026-04-27 09:41:45 --> URI Class Initialized
INFO - 2026-04-27 09:41:45 --> Router Class Initialized
INFO - 2026-04-27 09:41:45 --> Output Class Initialized
INFO - 2026-04-27 09:41:45 --> Security Class Initialized
DEBUG - 2026-04-27 09:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:41:45 --> Input Class Initialized
INFO - 2026-04-27 09:41:45 --> Language Class Initialized
INFO - 2026-04-27 09:41:45 --> Loader Class Initialized
INFO - 2026-04-27 09:41:45 --> Helper loaded: url_helper
INFO - 2026-04-27 09:41:45 --> Helper loaded: file_helper
INFO - 2026-04-27 09:41:45 --> Helper loaded: form_helper
INFO - 2026-04-27 09:41:45 --> Helper loaded: security_helper
INFO - 2026-04-27 09:41:45 --> Database Driver Class Initialized
INFO - 2026-04-27 09:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:41:45 --> Upload Class Initialized
INFO - 2026-04-27 09:41:45 --> Form Validation Class Initialized
INFO - 2026-04-27 09:41:45 --> Model "M_product" initialized
INFO - 2026-04-27 09:41:45 --> Model "M_settings" initialized
INFO - 2026-04-27 09:41:45 --> Controller Class Initialized
ERROR - 2026-04-27 09:41:45 --> Query error: Unknown column 'pending' in 'where clause' - Invalid query: SELECT SUM(`total_price`) AS `total_price`
FROM `sales`
WHERE DATE(created_at) = '2026-04-27'
AND status =  pending
INFO - 2026-04-27 09:41:45 --> Language file loaded: language/english/db_lang.php
INFO - 2026-04-27 09:41:45 --> Config Class Initialized
INFO - 2026-04-27 09:41:45 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:41:45 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:41:45 --> Utf8 Class Initialized
INFO - 2026-04-27 09:41:45 --> URI Class Initialized
INFO - 2026-04-27 09:41:45 --> Router Class Initialized
INFO - 2026-04-27 09:41:45 --> Output Class Initialized
INFO - 2026-04-27 09:41:45 --> Security Class Initialized
DEBUG - 2026-04-27 09:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:41:45 --> Input Class Initialized
INFO - 2026-04-27 09:41:45 --> Language Class Initialized
INFO - 2026-04-27 09:41:45 --> Loader Class Initialized
INFO - 2026-04-27 09:41:45 --> Helper loaded: url_helper
INFO - 2026-04-27 09:41:45 --> Helper loaded: file_helper
INFO - 2026-04-27 09:41:45 --> Helper loaded: form_helper
INFO - 2026-04-27 09:41:45 --> Helper loaded: security_helper
INFO - 2026-04-27 09:41:45 --> Database Driver Class Initialized
INFO - 2026-04-27 09:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:41:45 --> Upload Class Initialized
INFO - 2026-04-27 09:41:45 --> Form Validation Class Initialized
INFO - 2026-04-27 09:41:45 --> Model "M_product" initialized
INFO - 2026-04-27 09:41:45 --> Model "M_settings" initialized
INFO - 2026-04-27 09:41:45 --> Controller Class Initialized
ERROR - 2026-04-27 09:41:45 --> Query error: Unknown column 'pending' in 'where clause' - Invalid query: SELECT SUM(`total_price`) AS `total_price`
FROM `sales`
WHERE DATE(created_at) = '2026-04-27'
AND status =  pending
INFO - 2026-04-27 09:41:45 --> Language file loaded: language/english/db_lang.php
INFO - 2026-04-27 09:41:45 --> Config Class Initialized
INFO - 2026-04-27 09:41:45 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:41:45 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:41:45 --> Utf8 Class Initialized
INFO - 2026-04-27 09:41:45 --> URI Class Initialized
INFO - 2026-04-27 09:41:45 --> Router Class Initialized
INFO - 2026-04-27 09:41:45 --> Output Class Initialized
INFO - 2026-04-27 09:41:45 --> Security Class Initialized
DEBUG - 2026-04-27 09:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:41:45 --> Input Class Initialized
INFO - 2026-04-27 09:41:45 --> Language Class Initialized
INFO - 2026-04-27 09:41:45 --> Loader Class Initialized
INFO - 2026-04-27 09:41:45 --> Helper loaded: url_helper
INFO - 2026-04-27 09:41:45 --> Helper loaded: file_helper
INFO - 2026-04-27 09:41:45 --> Helper loaded: form_helper
INFO - 2026-04-27 09:41:45 --> Helper loaded: security_helper
INFO - 2026-04-27 09:41:45 --> Database Driver Class Initialized
INFO - 2026-04-27 09:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:41:45 --> Upload Class Initialized
INFO - 2026-04-27 09:41:45 --> Form Validation Class Initialized
INFO - 2026-04-27 09:41:45 --> Model "M_product" initialized
INFO - 2026-04-27 09:41:45 --> Model "M_settings" initialized
INFO - 2026-04-27 09:41:45 --> Controller Class Initialized
ERROR - 2026-04-27 09:41:45 --> Query error: Unknown column 'pending' in 'where clause' - Invalid query: SELECT SUM(`total_price`) AS `total_price`
FROM `sales`
WHERE DATE(created_at) = '2026-04-27'
AND status =  pending
INFO - 2026-04-27 09:41:45 --> Language file loaded: language/english/db_lang.php
INFO - 2026-04-27 09:45:11 --> Config Class Initialized
INFO - 2026-04-27 09:45:11 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:45:11 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:45:11 --> Utf8 Class Initialized
INFO - 2026-04-27 09:45:11 --> URI Class Initialized
INFO - 2026-04-27 09:45:11 --> Router Class Initialized
INFO - 2026-04-27 09:45:11 --> Output Class Initialized
INFO - 2026-04-27 09:45:11 --> Security Class Initialized
DEBUG - 2026-04-27 09:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:45:11 --> Input Class Initialized
INFO - 2026-04-27 09:45:11 --> Language Class Initialized
INFO - 2026-04-27 09:45:11 --> Loader Class Initialized
INFO - 2026-04-27 09:45:11 --> Helper loaded: url_helper
INFO - 2026-04-27 09:45:11 --> Helper loaded: file_helper
INFO - 2026-04-27 09:45:11 --> Helper loaded: form_helper
INFO - 2026-04-27 09:45:11 --> Helper loaded: security_helper
INFO - 2026-04-27 09:45:11 --> Database Driver Class Initialized
INFO - 2026-04-27 09:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:45:11 --> Upload Class Initialized
INFO - 2026-04-27 09:45:11 --> Form Validation Class Initialized
INFO - 2026-04-27 09:45:11 --> Model "M_product" initialized
INFO - 2026-04-27 09:45:11 --> Model "M_settings" initialized
INFO - 2026-04-27 09:45:11 --> Controller Class Initialized
ERROR - 2026-04-27 09:45:11 --> Query error: Unknown column 'pending' in 'where clause' - Invalid query: SELECT SUM(`total_price`) AS `total_price`
FROM `sales`
WHERE DATE(created_at) = '2026-04-27'
AND status =  pending
INFO - 2026-04-27 09:45:11 --> Language file loaded: language/english/db_lang.php
INFO - 2026-04-27 09:46:36 --> Config Class Initialized
INFO - 2026-04-27 09:46:36 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:46:36 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:46:36 --> Utf8 Class Initialized
INFO - 2026-04-27 09:46:36 --> URI Class Initialized
INFO - 2026-04-27 09:46:37 --> Router Class Initialized
INFO - 2026-04-27 09:46:37 --> Output Class Initialized
INFO - 2026-04-27 09:46:37 --> Security Class Initialized
DEBUG - 2026-04-27 09:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:46:37 --> Input Class Initialized
INFO - 2026-04-27 09:46:37 --> Language Class Initialized
INFO - 2026-04-27 09:46:37 --> Loader Class Initialized
INFO - 2026-04-27 09:46:37 --> Helper loaded: url_helper
INFO - 2026-04-27 09:46:37 --> Helper loaded: file_helper
INFO - 2026-04-27 09:46:37 --> Helper loaded: form_helper
INFO - 2026-04-27 09:46:37 --> Helper loaded: security_helper
INFO - 2026-04-27 09:46:37 --> Database Driver Class Initialized
INFO - 2026-04-27 09:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:46:37 --> Upload Class Initialized
INFO - 2026-04-27 09:46:37 --> Form Validation Class Initialized
INFO - 2026-04-27 09:46:37 --> Model "M_product" initialized
INFO - 2026-04-27 09:46:37 --> Model "M_settings" initialized
INFO - 2026-04-27 09:46:37 --> Controller Class Initialized
INFO - 2026-04-27 09:46:37 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:46:37 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:46:37 --> Final output sent to browser
DEBUG - 2026-04-27 09:46:37 --> Total execution time: 0.0767
INFO - 2026-04-27 09:46:38 --> Config Class Initialized
INFO - 2026-04-27 09:46:38 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:46:38 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:46:38 --> Utf8 Class Initialized
INFO - 2026-04-27 09:46:38 --> URI Class Initialized
INFO - 2026-04-27 09:46:38 --> Router Class Initialized
INFO - 2026-04-27 09:46:38 --> Output Class Initialized
INFO - 2026-04-27 09:46:38 --> Security Class Initialized
DEBUG - 2026-04-27 09:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:46:38 --> Input Class Initialized
INFO - 2026-04-27 09:46:38 --> Language Class Initialized
INFO - 2026-04-27 09:46:38 --> Loader Class Initialized
INFO - 2026-04-27 09:46:38 --> Helper loaded: url_helper
INFO - 2026-04-27 09:46:38 --> Helper loaded: file_helper
INFO - 2026-04-27 09:46:38 --> Helper loaded: form_helper
INFO - 2026-04-27 09:46:38 --> Helper loaded: security_helper
INFO - 2026-04-27 09:46:38 --> Database Driver Class Initialized
INFO - 2026-04-27 09:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:46:38 --> Upload Class Initialized
INFO - 2026-04-27 09:46:38 --> Form Validation Class Initialized
INFO - 2026-04-27 09:46:38 --> Model "M_product" initialized
INFO - 2026-04-27 09:46:38 --> Model "M_settings" initialized
INFO - 2026-04-27 09:46:38 --> Controller Class Initialized
INFO - 2026-04-27 09:46:38 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:46:38 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:46:38 --> Final output sent to browser
DEBUG - 2026-04-27 09:46:38 --> Total execution time: 0.0789
INFO - 2026-04-27 09:47:59 --> Config Class Initialized
INFO - 2026-04-27 09:47:59 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:47:59 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:47:59 --> Utf8 Class Initialized
INFO - 2026-04-27 09:47:59 --> URI Class Initialized
INFO - 2026-04-27 09:47:59 --> Router Class Initialized
INFO - 2026-04-27 09:47:59 --> Output Class Initialized
INFO - 2026-04-27 09:47:59 --> Security Class Initialized
DEBUG - 2026-04-27 09:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:47:59 --> Input Class Initialized
INFO - 2026-04-27 09:47:59 --> Language Class Initialized
INFO - 2026-04-27 09:47:59 --> Loader Class Initialized
INFO - 2026-04-27 09:47:59 --> Helper loaded: url_helper
INFO - 2026-04-27 09:47:59 --> Helper loaded: file_helper
INFO - 2026-04-27 09:47:59 --> Helper loaded: form_helper
INFO - 2026-04-27 09:47:59 --> Helper loaded: security_helper
INFO - 2026-04-27 09:47:59 --> Database Driver Class Initialized
INFO - 2026-04-27 09:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:47:59 --> Upload Class Initialized
INFO - 2026-04-27 09:47:59 --> Form Validation Class Initialized
INFO - 2026-04-27 09:47:59 --> Model "M_product" initialized
INFO - 2026-04-27 09:47:59 --> Model "M_settings" initialized
INFO - 2026-04-27 09:47:59 --> Controller Class Initialized
INFO - 2026-04-27 09:47:59 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:47:59 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:47:59 --> Final output sent to browser
DEBUG - 2026-04-27 09:47:59 --> Total execution time: 0.1623
INFO - 2026-04-27 09:48:48 --> Config Class Initialized
INFO - 2026-04-27 09:48:48 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:48:48 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:48:48 --> Utf8 Class Initialized
INFO - 2026-04-27 09:48:48 --> URI Class Initialized
INFO - 2026-04-27 09:48:48 --> Router Class Initialized
INFO - 2026-04-27 09:48:48 --> Output Class Initialized
INFO - 2026-04-27 09:48:48 --> Security Class Initialized
DEBUG - 2026-04-27 09:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:48:48 --> Input Class Initialized
INFO - 2026-04-27 09:48:48 --> Language Class Initialized
INFO - 2026-04-27 09:48:48 --> Loader Class Initialized
INFO - 2026-04-27 09:48:48 --> Helper loaded: url_helper
INFO - 2026-04-27 09:48:48 --> Helper loaded: file_helper
INFO - 2026-04-27 09:48:48 --> Helper loaded: form_helper
INFO - 2026-04-27 09:48:48 --> Helper loaded: security_helper
INFO - 2026-04-27 09:48:48 --> Database Driver Class Initialized
INFO - 2026-04-27 09:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:48:48 --> Upload Class Initialized
INFO - 2026-04-27 09:48:48 --> Form Validation Class Initialized
INFO - 2026-04-27 09:48:48 --> Model "M_product" initialized
INFO - 2026-04-27 09:48:48 --> Model "M_settings" initialized
INFO - 2026-04-27 09:48:48 --> Controller Class Initialized
INFO - 2026-04-27 09:48:48 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:48:48 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:48:48 --> Final output sent to browser
DEBUG - 2026-04-27 09:48:48 --> Total execution time: 0.0748
INFO - 2026-04-27 09:48:49 --> Config Class Initialized
INFO - 2026-04-27 09:48:49 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:48:49 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:48:49 --> Utf8 Class Initialized
INFO - 2026-04-27 09:48:49 --> URI Class Initialized
INFO - 2026-04-27 09:48:49 --> Router Class Initialized
INFO - 2026-04-27 09:48:49 --> Output Class Initialized
INFO - 2026-04-27 09:48:49 --> Security Class Initialized
DEBUG - 2026-04-27 09:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:48:49 --> Input Class Initialized
INFO - 2026-04-27 09:48:49 --> Language Class Initialized
INFO - 2026-04-27 09:48:49 --> Loader Class Initialized
INFO - 2026-04-27 09:48:49 --> Helper loaded: url_helper
INFO - 2026-04-27 09:48:49 --> Helper loaded: file_helper
INFO - 2026-04-27 09:48:49 --> Helper loaded: form_helper
INFO - 2026-04-27 09:48:49 --> Helper loaded: security_helper
INFO - 2026-04-27 09:48:49 --> Database Driver Class Initialized
INFO - 2026-04-27 09:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:48:49 --> Upload Class Initialized
INFO - 2026-04-27 09:48:49 --> Form Validation Class Initialized
INFO - 2026-04-27 09:48:49 --> Model "M_product" initialized
INFO - 2026-04-27 09:48:49 --> Model "M_settings" initialized
INFO - 2026-04-27 09:48:49 --> Controller Class Initialized
INFO - 2026-04-27 09:48:49 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:48:49 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:48:49 --> Final output sent to browser
DEBUG - 2026-04-27 09:48:49 --> Total execution time: 0.0758
INFO - 2026-04-27 09:48:49 --> Config Class Initialized
INFO - 2026-04-27 09:48:49 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:48:49 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:48:49 --> Utf8 Class Initialized
INFO - 2026-04-27 09:48:49 --> URI Class Initialized
INFO - 2026-04-27 09:48:49 --> Router Class Initialized
INFO - 2026-04-27 09:48:49 --> Output Class Initialized
INFO - 2026-04-27 09:48:49 --> Security Class Initialized
DEBUG - 2026-04-27 09:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:48:49 --> Input Class Initialized
INFO - 2026-04-27 09:48:49 --> Language Class Initialized
INFO - 2026-04-27 09:48:49 --> Loader Class Initialized
INFO - 2026-04-27 09:48:49 --> Helper loaded: url_helper
INFO - 2026-04-27 09:48:49 --> Helper loaded: file_helper
INFO - 2026-04-27 09:48:49 --> Helper loaded: form_helper
INFO - 2026-04-27 09:48:49 --> Helper loaded: security_helper
INFO - 2026-04-27 09:48:49 --> Database Driver Class Initialized
INFO - 2026-04-27 09:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:48:49 --> Upload Class Initialized
INFO - 2026-04-27 09:48:49 --> Form Validation Class Initialized
INFO - 2026-04-27 09:48:49 --> Model "M_product" initialized
INFO - 2026-04-27 09:48:49 --> Model "M_settings" initialized
INFO - 2026-04-27 09:48:49 --> Controller Class Initialized
INFO - 2026-04-27 09:48:49 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:48:49 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:48:49 --> Final output sent to browser
DEBUG - 2026-04-27 09:48:49 --> Total execution time: 0.0792
INFO - 2026-04-27 09:48:50 --> Config Class Initialized
INFO - 2026-04-27 09:48:50 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:48:50 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:48:50 --> Utf8 Class Initialized
INFO - 2026-04-27 09:48:50 --> URI Class Initialized
INFO - 2026-04-27 09:48:50 --> Router Class Initialized
INFO - 2026-04-27 09:48:50 --> Output Class Initialized
INFO - 2026-04-27 09:48:50 --> Security Class Initialized
DEBUG - 2026-04-27 09:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:48:50 --> Input Class Initialized
INFO - 2026-04-27 09:48:50 --> Language Class Initialized
INFO - 2026-04-27 09:48:50 --> Loader Class Initialized
INFO - 2026-04-27 09:48:50 --> Helper loaded: url_helper
INFO - 2026-04-27 09:48:50 --> Helper loaded: file_helper
INFO - 2026-04-27 09:48:50 --> Helper loaded: form_helper
INFO - 2026-04-27 09:48:50 --> Helper loaded: security_helper
INFO - 2026-04-27 09:48:50 --> Database Driver Class Initialized
INFO - 2026-04-27 09:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:48:50 --> Upload Class Initialized
INFO - 2026-04-27 09:48:50 --> Form Validation Class Initialized
INFO - 2026-04-27 09:48:50 --> Model "M_product" initialized
INFO - 2026-04-27 09:48:50 --> Model "M_settings" initialized
INFO - 2026-04-27 09:48:50 --> Controller Class Initialized
INFO - 2026-04-27 09:48:50 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 09:48:50 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 09:48:50 --> Final output sent to browser
DEBUG - 2026-04-27 09:48:50 --> Total execution time: 0.0733
INFO - 2026-04-27 09:58:55 --> Config Class Initialized
INFO - 2026-04-27 09:58:55 --> Hooks Class Initialized
DEBUG - 2026-04-27 09:58:55 --> UTF-8 Support Enabled
INFO - 2026-04-27 09:58:55 --> Utf8 Class Initialized
INFO - 2026-04-27 09:58:55 --> URI Class Initialized
INFO - 2026-04-27 09:58:55 --> Router Class Initialized
INFO - 2026-04-27 09:58:55 --> Output Class Initialized
INFO - 2026-04-27 09:58:55 --> Security Class Initialized
DEBUG - 2026-04-27 09:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 09:58:55 --> Input Class Initialized
INFO - 2026-04-27 09:58:55 --> Language Class Initialized
INFO - 2026-04-27 09:58:55 --> Loader Class Initialized
INFO - 2026-04-27 09:58:55 --> Helper loaded: url_helper
INFO - 2026-04-27 09:58:55 --> Helper loaded: file_helper
INFO - 2026-04-27 09:58:55 --> Helper loaded: form_helper
INFO - 2026-04-27 09:58:55 --> Helper loaded: security_helper
INFO - 2026-04-27 09:58:55 --> Database Driver Class Initialized
INFO - 2026-04-27 09:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 09:58:55 --> Upload Class Initialized
INFO - 2026-04-27 09:58:55 --> Form Validation Class Initialized
INFO - 2026-04-27 09:58:55 --> Model "M_product" initialized
INFO - 2026-04-27 09:58:55 --> Model "M_settings" initialized
INFO - 2026-04-27 09:58:55 --> Controller Class Initialized
INFO - 2026-04-27 09:58:55 --> Final output sent to browser
DEBUG - 2026-04-27 09:58:55 --> Total execution time: 0.0785
INFO - 2026-04-27 13:46:08 --> Config Class Initialized
INFO - 2026-04-27 13:46:08 --> Hooks Class Initialized
DEBUG - 2026-04-27 13:46:08 --> UTF-8 Support Enabled
INFO - 2026-04-27 13:46:08 --> Utf8 Class Initialized
INFO - 2026-04-27 13:46:08 --> URI Class Initialized
DEBUG - 2026-04-27 13:46:08 --> No URI present. Default controller set.
INFO - 2026-04-27 13:46:08 --> Router Class Initialized
INFO - 2026-04-27 13:46:08 --> Output Class Initialized
INFO - 2026-04-27 13:46:08 --> Security Class Initialized
DEBUG - 2026-04-27 13:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 13:46:08 --> Input Class Initialized
INFO - 2026-04-27 13:46:08 --> Language Class Initialized
INFO - 2026-04-27 13:46:08 --> Loader Class Initialized
INFO - 2026-04-27 13:46:08 --> Helper loaded: url_helper
INFO - 2026-04-27 13:46:08 --> Helper loaded: file_helper
INFO - 2026-04-27 13:46:08 --> Helper loaded: form_helper
INFO - 2026-04-27 13:46:08 --> Helper loaded: security_helper
INFO - 2026-04-27 13:46:08 --> Database Driver Class Initialized
INFO - 2026-04-27 13:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 13:46:08 --> Upload Class Initialized
INFO - 2026-04-27 13:46:08 --> Form Validation Class Initialized
INFO - 2026-04-27 13:46:08 --> Model "M_product" initialized
INFO - 2026-04-27 13:46:08 --> Model "M_settings" initialized
INFO - 2026-04-27 13:46:08 --> Controller Class Initialized
INFO - 2026-04-27 13:46:08 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-27 13:46:08 --> Final output sent to browser
DEBUG - 2026-04-27 13:46:08 --> Total execution time: 0.1629
INFO - 2026-04-27 13:46:11 --> Config Class Initialized
INFO - 2026-04-27 13:46:11 --> Hooks Class Initialized
DEBUG - 2026-04-27 13:46:11 --> UTF-8 Support Enabled
INFO - 2026-04-27 13:46:11 --> Utf8 Class Initialized
INFO - 2026-04-27 13:46:11 --> URI Class Initialized
INFO - 2026-04-27 13:46:11 --> Router Class Initialized
INFO - 2026-04-27 13:46:11 --> Output Class Initialized
INFO - 2026-04-27 13:46:11 --> Security Class Initialized
DEBUG - 2026-04-27 13:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 13:46:11 --> Input Class Initialized
INFO - 2026-04-27 13:46:11 --> Language Class Initialized
INFO - 2026-04-27 13:46:11 --> Loader Class Initialized
INFO - 2026-04-27 13:46:11 --> Helper loaded: url_helper
INFO - 2026-04-27 13:46:11 --> Helper loaded: file_helper
INFO - 2026-04-27 13:46:11 --> Helper loaded: form_helper
INFO - 2026-04-27 13:46:11 --> Helper loaded: security_helper
INFO - 2026-04-27 13:46:11 --> Database Driver Class Initialized
INFO - 2026-04-27 13:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 13:46:11 --> Upload Class Initialized
INFO - 2026-04-27 13:46:11 --> Form Validation Class Initialized
INFO - 2026-04-27 13:46:11 --> Model "M_product" initialized
INFO - 2026-04-27 13:46:11 --> Model "M_settings" initialized
INFO - 2026-04-27 13:46:11 --> Controller Class Initialized
DEBUG - 2026-04-27 13:46:11 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-27 13:46:11 --> File loaded: C:\laragon\www\macha\application\views\auth/login.php
INFO - 2026-04-27 13:46:11 --> Final output sent to browser
DEBUG - 2026-04-27 13:46:11 --> Total execution time: 0.0882
INFO - 2026-04-27 13:46:13 --> Config Class Initialized
INFO - 2026-04-27 13:46:13 --> Hooks Class Initialized
DEBUG - 2026-04-27 13:46:13 --> UTF-8 Support Enabled
INFO - 2026-04-27 13:46:13 --> Utf8 Class Initialized
INFO - 2026-04-27 13:46:13 --> URI Class Initialized
INFO - 2026-04-27 13:46:13 --> Router Class Initialized
INFO - 2026-04-27 13:46:13 --> Output Class Initialized
INFO - 2026-04-27 13:46:13 --> Security Class Initialized
DEBUG - 2026-04-27 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 13:46:13 --> Input Class Initialized
INFO - 2026-04-27 13:46:13 --> Language Class Initialized
INFO - 2026-04-27 13:46:13 --> Loader Class Initialized
INFO - 2026-04-27 13:46:13 --> Helper loaded: url_helper
INFO - 2026-04-27 13:46:13 --> Helper loaded: file_helper
INFO - 2026-04-27 13:46:13 --> Helper loaded: form_helper
INFO - 2026-04-27 13:46:13 --> Helper loaded: security_helper
INFO - 2026-04-27 13:46:13 --> Database Driver Class Initialized
INFO - 2026-04-27 13:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 13:46:13 --> Upload Class Initialized
INFO - 2026-04-27 13:46:13 --> Form Validation Class Initialized
INFO - 2026-04-27 13:46:13 --> Model "M_product" initialized
INFO - 2026-04-27 13:46:13 --> Model "M_settings" initialized
INFO - 2026-04-27 13:46:13 --> Controller Class Initialized
DEBUG - 2026-04-27 13:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-27 13:46:13 --> Config Class Initialized
INFO - 2026-04-27 13:46:13 --> Hooks Class Initialized
DEBUG - 2026-04-27 13:46:13 --> UTF-8 Support Enabled
INFO - 2026-04-27 13:46:13 --> Utf8 Class Initialized
INFO - 2026-04-27 13:46:13 --> URI Class Initialized
INFO - 2026-04-27 13:46:13 --> Router Class Initialized
INFO - 2026-04-27 13:46:13 --> Output Class Initialized
INFO - 2026-04-27 13:46:13 --> Security Class Initialized
DEBUG - 2026-04-27 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 13:46:13 --> Input Class Initialized
INFO - 2026-04-27 13:46:13 --> Language Class Initialized
INFO - 2026-04-27 13:46:13 --> Loader Class Initialized
INFO - 2026-04-27 13:46:13 --> Helper loaded: url_helper
INFO - 2026-04-27 13:46:13 --> Helper loaded: file_helper
INFO - 2026-04-27 13:46:13 --> Helper loaded: form_helper
INFO - 2026-04-27 13:46:13 --> Helper loaded: security_helper
INFO - 2026-04-27 13:46:13 --> Database Driver Class Initialized
INFO - 2026-04-27 13:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 13:46:13 --> Upload Class Initialized
INFO - 2026-04-27 13:46:13 --> Form Validation Class Initialized
INFO - 2026-04-27 13:46:13 --> Model "M_product" initialized
INFO - 2026-04-27 13:46:13 --> Model "M_settings" initialized
INFO - 2026-04-27 13:46:13 --> Controller Class Initialized
INFO - 2026-04-27 13:46:13 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 13:46:13 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 13:46:13 --> Final output sent to browser
DEBUG - 2026-04-27 13:46:13 --> Total execution time: 0.1091
INFO - 2026-04-27 13:50:37 --> Config Class Initialized
INFO - 2026-04-27 13:50:37 --> Hooks Class Initialized
DEBUG - 2026-04-27 13:50:37 --> UTF-8 Support Enabled
INFO - 2026-04-27 13:50:37 --> Utf8 Class Initialized
INFO - 2026-04-27 13:50:37 --> URI Class Initialized
INFO - 2026-04-27 13:50:37 --> Router Class Initialized
INFO - 2026-04-27 13:50:37 --> Output Class Initialized
INFO - 2026-04-27 13:50:37 --> Security Class Initialized
DEBUG - 2026-04-27 13:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 13:50:37 --> Input Class Initialized
INFO - 2026-04-27 13:50:37 --> Language Class Initialized
INFO - 2026-04-27 13:50:37 --> Loader Class Initialized
INFO - 2026-04-27 13:50:37 --> Helper loaded: url_helper
INFO - 2026-04-27 13:50:37 --> Helper loaded: file_helper
INFO - 2026-04-27 13:50:37 --> Helper loaded: form_helper
INFO - 2026-04-27 13:50:37 --> Helper loaded: security_helper
INFO - 2026-04-27 13:50:37 --> Database Driver Class Initialized
INFO - 2026-04-27 13:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 13:50:37 --> Upload Class Initialized
INFO - 2026-04-27 13:50:37 --> Form Validation Class Initialized
INFO - 2026-04-27 13:50:37 --> Model "M_product" initialized
INFO - 2026-04-27 13:50:37 --> Model "M_settings" initialized
INFO - 2026-04-27 13:50:37 --> Controller Class Initialized
INFO - 2026-04-27 13:50:37 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 13:50:37 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 13:50:37 --> Final output sent to browser
DEBUG - 2026-04-27 13:50:37 --> Total execution time: 0.1120
INFO - 2026-04-27 13:54:51 --> Config Class Initialized
INFO - 2026-04-27 13:54:51 --> Hooks Class Initialized
DEBUG - 2026-04-27 13:54:51 --> UTF-8 Support Enabled
INFO - 2026-04-27 13:54:51 --> Utf8 Class Initialized
INFO - 2026-04-27 13:54:51 --> URI Class Initialized
INFO - 2026-04-27 13:54:51 --> Router Class Initialized
INFO - 2026-04-27 13:54:51 --> Output Class Initialized
INFO - 2026-04-27 13:54:51 --> Security Class Initialized
DEBUG - 2026-04-27 13:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 13:54:51 --> Input Class Initialized
INFO - 2026-04-27 13:54:51 --> Language Class Initialized
INFO - 2026-04-27 13:54:51 --> Loader Class Initialized
INFO - 2026-04-27 13:54:51 --> Helper loaded: url_helper
INFO - 2026-04-27 13:54:51 --> Helper loaded: file_helper
INFO - 2026-04-27 13:54:51 --> Helper loaded: form_helper
INFO - 2026-04-27 13:54:51 --> Helper loaded: security_helper
INFO - 2026-04-27 13:54:51 --> Database Driver Class Initialized
INFO - 2026-04-27 13:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 13:54:51 --> Upload Class Initialized
INFO - 2026-04-27 13:54:51 --> Form Validation Class Initialized
INFO - 2026-04-27 13:54:51 --> Model "M_product" initialized
INFO - 2026-04-27 13:54:51 --> Model "M_settings" initialized
INFO - 2026-04-27 13:54:51 --> Controller Class Initialized
INFO - 2026-04-27 13:54:51 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 13:54:51 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 13:54:51 --> Final output sent to browser
DEBUG - 2026-04-27 13:54:51 --> Total execution time: 0.1727
INFO - 2026-04-27 13:55:01 --> Config Class Initialized
INFO - 2026-04-27 13:55:01 --> Hooks Class Initialized
DEBUG - 2026-04-27 13:55:01 --> UTF-8 Support Enabled
INFO - 2026-04-27 13:55:01 --> Utf8 Class Initialized
INFO - 2026-04-27 13:55:01 --> URI Class Initialized
INFO - 2026-04-27 13:55:01 --> Router Class Initialized
INFO - 2026-04-27 13:55:01 --> Output Class Initialized
INFO - 2026-04-27 13:55:01 --> Security Class Initialized
DEBUG - 2026-04-27 13:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 13:55:01 --> Input Class Initialized
INFO - 2026-04-27 13:55:01 --> Language Class Initialized
INFO - 2026-04-27 13:55:01 --> Loader Class Initialized
INFO - 2026-04-27 13:55:01 --> Helper loaded: url_helper
INFO - 2026-04-27 13:55:01 --> Helper loaded: file_helper
INFO - 2026-04-27 13:55:01 --> Helper loaded: form_helper
INFO - 2026-04-27 13:55:01 --> Helper loaded: security_helper
INFO - 2026-04-27 13:55:01 --> Database Driver Class Initialized
INFO - 2026-04-27 13:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 13:55:01 --> Upload Class Initialized
INFO - 2026-04-27 13:55:01 --> Form Validation Class Initialized
INFO - 2026-04-27 13:55:01 --> Model "M_product" initialized
INFO - 2026-04-27 13:55:01 --> Model "M_settings" initialized
INFO - 2026-04-27 13:55:01 --> Controller Class Initialized
INFO - 2026-04-27 13:55:01 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 13:55:01 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 13:55:01 --> Final output sent to browser
DEBUG - 2026-04-27 13:55:01 --> Total execution time: 0.0808
INFO - 2026-04-27 13:58:09 --> Config Class Initialized
INFO - 2026-04-27 13:58:09 --> Hooks Class Initialized
DEBUG - 2026-04-27 13:58:09 --> UTF-8 Support Enabled
INFO - 2026-04-27 13:58:09 --> Utf8 Class Initialized
INFO - 2026-04-27 13:58:09 --> URI Class Initialized
INFO - 2026-04-27 13:58:09 --> Router Class Initialized
INFO - 2026-04-27 13:58:09 --> Output Class Initialized
INFO - 2026-04-27 13:58:09 --> Security Class Initialized
DEBUG - 2026-04-27 13:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 13:58:09 --> Input Class Initialized
INFO - 2026-04-27 13:58:09 --> Language Class Initialized
INFO - 2026-04-27 13:58:09 --> Loader Class Initialized
INFO - 2026-04-27 13:58:09 --> Helper loaded: url_helper
INFO - 2026-04-27 13:58:09 --> Helper loaded: file_helper
INFO - 2026-04-27 13:58:09 --> Helper loaded: form_helper
INFO - 2026-04-27 13:58:09 --> Helper loaded: security_helper
INFO - 2026-04-27 13:58:09 --> Database Driver Class Initialized
INFO - 2026-04-27 13:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 13:58:09 --> Upload Class Initialized
INFO - 2026-04-27 13:58:09 --> Form Validation Class Initialized
INFO - 2026-04-27 13:58:09 --> Model "M_product" initialized
INFO - 2026-04-27 13:58:09 --> Model "M_settings" initialized
INFO - 2026-04-27 13:58:09 --> Controller Class Initialized
INFO - 2026-04-27 13:58:09 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 13:58:09 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 13:58:09 --> Final output sent to browser
DEBUG - 2026-04-27 13:58:09 --> Total execution time: 0.0947
INFO - 2026-04-27 13:58:15 --> Config Class Initialized
INFO - 2026-04-27 13:58:15 --> Hooks Class Initialized
DEBUG - 2026-04-27 13:58:15 --> UTF-8 Support Enabled
INFO - 2026-04-27 13:58:15 --> Utf8 Class Initialized
INFO - 2026-04-27 13:58:15 --> URI Class Initialized
INFO - 2026-04-27 13:58:15 --> Router Class Initialized
INFO - 2026-04-27 13:58:15 --> Output Class Initialized
INFO - 2026-04-27 13:58:15 --> Security Class Initialized
DEBUG - 2026-04-27 13:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 13:58:15 --> Input Class Initialized
INFO - 2026-04-27 13:58:15 --> Language Class Initialized
INFO - 2026-04-27 13:58:15 --> Loader Class Initialized
INFO - 2026-04-27 13:58:15 --> Helper loaded: url_helper
INFO - 2026-04-27 13:58:15 --> Helper loaded: file_helper
INFO - 2026-04-27 13:58:15 --> Helper loaded: form_helper
INFO - 2026-04-27 13:58:15 --> Helper loaded: security_helper
INFO - 2026-04-27 13:58:15 --> Database Driver Class Initialized
INFO - 2026-04-27 13:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 13:58:15 --> Upload Class Initialized
INFO - 2026-04-27 13:58:15 --> Form Validation Class Initialized
INFO - 2026-04-27 13:58:15 --> Model "M_product" initialized
INFO - 2026-04-27 13:58:15 --> Model "M_settings" initialized
INFO - 2026-04-27 13:58:15 --> Controller Class Initialized
INFO - 2026-04-27 13:58:15 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 13:58:15 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 13:58:15 --> Final output sent to browser
DEBUG - 2026-04-27 13:58:15 --> Total execution time: 0.1248
INFO - 2026-04-27 13:58:16 --> Config Class Initialized
INFO - 2026-04-27 13:58:16 --> Hooks Class Initialized
DEBUG - 2026-04-27 13:58:16 --> UTF-8 Support Enabled
INFO - 2026-04-27 13:58:16 --> Utf8 Class Initialized
INFO - 2026-04-27 13:58:16 --> URI Class Initialized
INFO - 2026-04-27 13:58:16 --> Router Class Initialized
INFO - 2026-04-27 13:58:16 --> Output Class Initialized
INFO - 2026-04-27 13:58:16 --> Security Class Initialized
DEBUG - 2026-04-27 13:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 13:58:16 --> Input Class Initialized
INFO - 2026-04-27 13:58:16 --> Language Class Initialized
INFO - 2026-04-27 13:58:16 --> Loader Class Initialized
INFO - 2026-04-27 13:58:16 --> Helper loaded: url_helper
INFO - 2026-04-27 13:58:16 --> Helper loaded: file_helper
INFO - 2026-04-27 13:58:16 --> Helper loaded: form_helper
INFO - 2026-04-27 13:58:16 --> Helper loaded: security_helper
INFO - 2026-04-27 13:58:16 --> Database Driver Class Initialized
INFO - 2026-04-27 13:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 13:58:16 --> Upload Class Initialized
INFO - 2026-04-27 13:58:16 --> Form Validation Class Initialized
INFO - 2026-04-27 13:58:16 --> Model "M_product" initialized
INFO - 2026-04-27 13:58:16 --> Model "M_settings" initialized
INFO - 2026-04-27 13:58:16 --> Controller Class Initialized
INFO - 2026-04-27 13:58:16 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 13:58:16 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 13:58:16 --> Final output sent to browser
DEBUG - 2026-04-27 13:58:16 --> Total execution time: 0.0860
INFO - 2026-04-27 13:58:30 --> Config Class Initialized
INFO - 2026-04-27 13:58:30 --> Hooks Class Initialized
DEBUG - 2026-04-27 13:58:30 --> UTF-8 Support Enabled
INFO - 2026-04-27 13:58:30 --> Utf8 Class Initialized
INFO - 2026-04-27 13:58:30 --> URI Class Initialized
INFO - 2026-04-27 13:58:30 --> Router Class Initialized
INFO - 2026-04-27 13:58:30 --> Output Class Initialized
INFO - 2026-04-27 13:58:30 --> Security Class Initialized
DEBUG - 2026-04-27 13:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 13:58:30 --> Input Class Initialized
INFO - 2026-04-27 13:58:30 --> Language Class Initialized
INFO - 2026-04-27 13:58:30 --> Loader Class Initialized
INFO - 2026-04-27 13:58:30 --> Helper loaded: url_helper
INFO - 2026-04-27 13:58:30 --> Helper loaded: file_helper
INFO - 2026-04-27 13:58:30 --> Helper loaded: form_helper
INFO - 2026-04-27 13:58:30 --> Helper loaded: security_helper
INFO - 2026-04-27 13:58:30 --> Database Driver Class Initialized
INFO - 2026-04-27 13:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 13:58:30 --> Upload Class Initialized
INFO - 2026-04-27 13:58:30 --> Form Validation Class Initialized
INFO - 2026-04-27 13:58:30 --> Model "M_product" initialized
INFO - 2026-04-27 13:58:30 --> Model "M_settings" initialized
INFO - 2026-04-27 13:58:30 --> Controller Class Initialized
INFO - 2026-04-27 13:58:30 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 13:58:30 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 13:58:30 --> Final output sent to browser
DEBUG - 2026-04-27 13:58:30 --> Total execution time: 0.0810
INFO - 2026-04-27 13:58:32 --> Config Class Initialized
INFO - 2026-04-27 13:58:32 --> Hooks Class Initialized
DEBUG - 2026-04-27 13:58:32 --> UTF-8 Support Enabled
INFO - 2026-04-27 13:58:32 --> Utf8 Class Initialized
INFO - 2026-04-27 13:58:32 --> URI Class Initialized
INFO - 2026-04-27 13:58:32 --> Router Class Initialized
INFO - 2026-04-27 13:58:32 --> Output Class Initialized
INFO - 2026-04-27 13:58:32 --> Security Class Initialized
DEBUG - 2026-04-27 13:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 13:58:32 --> Input Class Initialized
INFO - 2026-04-27 13:58:32 --> Language Class Initialized
INFO - 2026-04-27 13:58:32 --> Loader Class Initialized
INFO - 2026-04-27 13:58:32 --> Helper loaded: url_helper
INFO - 2026-04-27 13:58:32 --> Helper loaded: file_helper
INFO - 2026-04-27 13:58:32 --> Helper loaded: form_helper
INFO - 2026-04-27 13:58:32 --> Helper loaded: security_helper
INFO - 2026-04-27 13:58:32 --> Database Driver Class Initialized
INFO - 2026-04-27 13:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 13:58:32 --> Upload Class Initialized
INFO - 2026-04-27 13:58:32 --> Form Validation Class Initialized
INFO - 2026-04-27 13:58:32 --> Model "M_product" initialized
INFO - 2026-04-27 13:58:32 --> Model "M_settings" initialized
INFO - 2026-04-27 13:58:32 --> Controller Class Initialized
DEBUG - 2026-04-27 13:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-27 13:58:32 --> Config Class Initialized
INFO - 2026-04-27 13:58:32 --> Hooks Class Initialized
DEBUG - 2026-04-27 13:58:32 --> UTF-8 Support Enabled
INFO - 2026-04-27 13:58:32 --> Utf8 Class Initialized
INFO - 2026-04-27 13:58:32 --> URI Class Initialized
INFO - 2026-04-27 13:58:32 --> Router Class Initialized
INFO - 2026-04-27 13:58:32 --> Output Class Initialized
INFO - 2026-04-27 13:58:32 --> Security Class Initialized
DEBUG - 2026-04-27 13:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 13:58:32 --> Input Class Initialized
INFO - 2026-04-27 13:58:32 --> Language Class Initialized
INFO - 2026-04-27 13:58:32 --> Loader Class Initialized
INFO - 2026-04-27 13:58:32 --> Helper loaded: url_helper
INFO - 2026-04-27 13:58:32 --> Helper loaded: file_helper
INFO - 2026-04-27 13:58:32 --> Helper loaded: form_helper
INFO - 2026-04-27 13:58:32 --> Helper loaded: security_helper
INFO - 2026-04-27 13:58:32 --> Database Driver Class Initialized
INFO - 2026-04-27 13:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 13:58:32 --> Upload Class Initialized
INFO - 2026-04-27 13:58:32 --> Form Validation Class Initialized
INFO - 2026-04-27 13:58:32 --> Model "M_product" initialized
INFO - 2026-04-27 13:58:32 --> Model "M_settings" initialized
INFO - 2026-04-27 13:58:32 --> Controller Class Initialized
INFO - 2026-04-27 13:58:32 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 13:58:32 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 13:58:32 --> Final output sent to browser
DEBUG - 2026-04-27 13:58:32 --> Total execution time: 0.0976
INFO - 2026-04-27 13:59:25 --> Config Class Initialized
INFO - 2026-04-27 13:59:25 --> Hooks Class Initialized
DEBUG - 2026-04-27 13:59:25 --> UTF-8 Support Enabled
INFO - 2026-04-27 13:59:25 --> Utf8 Class Initialized
INFO - 2026-04-27 13:59:25 --> URI Class Initialized
INFO - 2026-04-27 13:59:25 --> Router Class Initialized
INFO - 2026-04-27 13:59:25 --> Output Class Initialized
INFO - 2026-04-27 13:59:25 --> Security Class Initialized
DEBUG - 2026-04-27 13:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 13:59:25 --> Input Class Initialized
INFO - 2026-04-27 13:59:25 --> Language Class Initialized
INFO - 2026-04-27 13:59:25 --> Loader Class Initialized
INFO - 2026-04-27 13:59:25 --> Helper loaded: url_helper
INFO - 2026-04-27 13:59:25 --> Helper loaded: file_helper
INFO - 2026-04-27 13:59:25 --> Helper loaded: form_helper
INFO - 2026-04-27 13:59:25 --> Helper loaded: security_helper
INFO - 2026-04-27 13:59:25 --> Database Driver Class Initialized
INFO - 2026-04-27 13:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 13:59:25 --> Upload Class Initialized
INFO - 2026-04-27 13:59:25 --> Form Validation Class Initialized
INFO - 2026-04-27 13:59:25 --> Model "M_product" initialized
INFO - 2026-04-27 13:59:25 --> Model "M_settings" initialized
INFO - 2026-04-27 13:59:25 --> Controller Class Initialized
INFO - 2026-04-27 13:59:25 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 13:59:25 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 13:59:25 --> Final output sent to browser
DEBUG - 2026-04-27 13:59:25 --> Total execution time: 0.0787
INFO - 2026-04-27 14:01:22 --> Config Class Initialized
INFO - 2026-04-27 14:01:22 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:01:22 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:01:22 --> Utf8 Class Initialized
INFO - 2026-04-27 14:01:22 --> URI Class Initialized
INFO - 2026-04-27 14:01:22 --> Router Class Initialized
INFO - 2026-04-27 14:01:22 --> Output Class Initialized
INFO - 2026-04-27 14:01:22 --> Security Class Initialized
DEBUG - 2026-04-27 14:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:01:22 --> Input Class Initialized
INFO - 2026-04-27 14:01:22 --> Language Class Initialized
INFO - 2026-04-27 14:01:22 --> Loader Class Initialized
INFO - 2026-04-27 14:01:22 --> Helper loaded: url_helper
INFO - 2026-04-27 14:01:22 --> Helper loaded: file_helper
INFO - 2026-04-27 14:01:22 --> Helper loaded: form_helper
INFO - 2026-04-27 14:01:22 --> Helper loaded: security_helper
INFO - 2026-04-27 14:01:22 --> Database Driver Class Initialized
INFO - 2026-04-27 14:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:01:22 --> Upload Class Initialized
INFO - 2026-04-27 14:01:22 --> Form Validation Class Initialized
INFO - 2026-04-27 14:01:22 --> Model "M_product" initialized
INFO - 2026-04-27 14:01:22 --> Model "M_settings" initialized
INFO - 2026-04-27 14:01:22 --> Controller Class Initialized
INFO - 2026-04-27 14:01:22 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 14:01:22 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:01:22 --> Final output sent to browser
DEBUG - 2026-04-27 14:01:22 --> Total execution time: 0.0775
INFO - 2026-04-27 14:01:28 --> Config Class Initialized
INFO - 2026-04-27 14:01:28 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:01:28 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:01:28 --> Utf8 Class Initialized
INFO - 2026-04-27 14:01:28 --> URI Class Initialized
INFO - 2026-04-27 14:01:28 --> Router Class Initialized
INFO - 2026-04-27 14:01:28 --> Output Class Initialized
INFO - 2026-04-27 14:01:28 --> Security Class Initialized
DEBUG - 2026-04-27 14:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:01:28 --> Input Class Initialized
INFO - 2026-04-27 14:01:28 --> Language Class Initialized
INFO - 2026-04-27 14:01:28 --> Loader Class Initialized
INFO - 2026-04-27 14:01:28 --> Helper loaded: url_helper
INFO - 2026-04-27 14:01:28 --> Helper loaded: file_helper
INFO - 2026-04-27 14:01:28 --> Helper loaded: form_helper
INFO - 2026-04-27 14:01:28 --> Helper loaded: security_helper
INFO - 2026-04-27 14:01:28 --> Database Driver Class Initialized
INFO - 2026-04-27 14:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:01:28 --> Upload Class Initialized
INFO - 2026-04-27 14:01:28 --> Form Validation Class Initialized
INFO - 2026-04-27 14:01:28 --> Model "M_product" initialized
INFO - 2026-04-27 14:01:28 --> Model "M_settings" initialized
INFO - 2026-04-27 14:01:28 --> Controller Class Initialized
DEBUG - 2026-04-27 14:01:28 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2026-04-27 14:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-27 14:01:28 --> File loaded: C:\laragon\www\macha\application\views\products/list_product.php
INFO - 2026-04-27 14:01:28 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:01:28 --> Final output sent to browser
DEBUG - 2026-04-27 14:01:28 --> Total execution time: 0.0765
INFO - 2026-04-27 14:01:28 --> Config Class Initialized
INFO - 2026-04-27 14:01:28 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:01:28 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:01:28 --> Utf8 Class Initialized
INFO - 2026-04-27 14:01:28 --> URI Class Initialized
INFO - 2026-04-27 14:01:28 --> Router Class Initialized
INFO - 2026-04-27 14:01:28 --> Output Class Initialized
INFO - 2026-04-27 14:01:28 --> Security Class Initialized
DEBUG - 2026-04-27 14:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:01:28 --> Input Class Initialized
INFO - 2026-04-27 14:01:28 --> Language Class Initialized
INFO - 2026-04-27 14:01:28 --> Loader Class Initialized
INFO - 2026-04-27 14:01:28 --> Helper loaded: url_helper
INFO - 2026-04-27 14:01:28 --> Helper loaded: file_helper
INFO - 2026-04-27 14:01:28 --> Helper loaded: form_helper
INFO - 2026-04-27 14:01:28 --> Helper loaded: security_helper
INFO - 2026-04-27 14:01:28 --> Database Driver Class Initialized
INFO - 2026-04-27 14:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:01:28 --> Upload Class Initialized
INFO - 2026-04-27 14:01:28 --> Form Validation Class Initialized
INFO - 2026-04-27 14:01:28 --> Model "M_product" initialized
INFO - 2026-04-27 14:01:28 --> Model "M_settings" initialized
INFO - 2026-04-27 14:01:28 --> Controller Class Initialized
DEBUG - 2026-04-27 14:01:28 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2026-04-27 14:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-27 14:01:28 --> File loaded: C:\laragon\www\macha\application\views\products/add_product.php
INFO - 2026-04-27 14:01:28 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:01:28 --> Final output sent to browser
DEBUG - 2026-04-27 14:01:28 --> Total execution time: 0.0837
INFO - 2026-04-27 14:01:29 --> Config Class Initialized
INFO - 2026-04-27 14:01:29 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:01:29 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:01:29 --> Utf8 Class Initialized
INFO - 2026-04-27 14:01:29 --> URI Class Initialized
INFO - 2026-04-27 14:01:29 --> Router Class Initialized
INFO - 2026-04-27 14:01:29 --> Output Class Initialized
INFO - 2026-04-27 14:01:29 --> Security Class Initialized
DEBUG - 2026-04-27 14:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:01:29 --> Input Class Initialized
INFO - 2026-04-27 14:01:29 --> Language Class Initialized
INFO - 2026-04-27 14:01:29 --> Loader Class Initialized
INFO - 2026-04-27 14:01:29 --> Helper loaded: url_helper
INFO - 2026-04-27 14:01:29 --> Helper loaded: file_helper
INFO - 2026-04-27 14:01:29 --> Helper loaded: form_helper
INFO - 2026-04-27 14:01:29 --> Helper loaded: security_helper
INFO - 2026-04-27 14:01:29 --> Database Driver Class Initialized
INFO - 2026-04-27 14:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:01:29 --> Upload Class Initialized
INFO - 2026-04-27 14:01:29 --> Form Validation Class Initialized
INFO - 2026-04-27 14:01:29 --> Model "M_product" initialized
INFO - 2026-04-27 14:01:29 --> Model "M_settings" initialized
INFO - 2026-04-27 14:01:29 --> Controller Class Initialized
DEBUG - 2026-04-27 14:01:29 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2026-04-27 14:01:29 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-27 14:01:29 --> File loaded: C:\laragon\www\macha\application\views\products/add_product.php
INFO - 2026-04-27 14:01:29 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:01:29 --> Final output sent to browser
DEBUG - 2026-04-27 14:01:29 --> Total execution time: 0.0845
INFO - 2026-04-27 14:01:29 --> Config Class Initialized
INFO - 2026-04-27 14:01:29 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:01:29 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:01:29 --> Utf8 Class Initialized
INFO - 2026-04-27 14:01:29 --> URI Class Initialized
INFO - 2026-04-27 14:01:29 --> Router Class Initialized
INFO - 2026-04-27 14:01:29 --> Output Class Initialized
INFO - 2026-04-27 14:01:29 --> Security Class Initialized
DEBUG - 2026-04-27 14:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:01:29 --> Input Class Initialized
INFO - 2026-04-27 14:01:29 --> Language Class Initialized
INFO - 2026-04-27 14:01:29 --> Loader Class Initialized
INFO - 2026-04-27 14:01:29 --> Helper loaded: url_helper
INFO - 2026-04-27 14:01:29 --> Helper loaded: file_helper
INFO - 2026-04-27 14:01:29 --> Helper loaded: form_helper
INFO - 2026-04-27 14:01:29 --> Helper loaded: security_helper
INFO - 2026-04-27 14:01:29 --> Database Driver Class Initialized
INFO - 2026-04-27 14:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:01:29 --> Upload Class Initialized
INFO - 2026-04-27 14:01:29 --> Form Validation Class Initialized
INFO - 2026-04-27 14:01:29 --> Model "M_product" initialized
INFO - 2026-04-27 14:01:29 --> Model "M_settings" initialized
INFO - 2026-04-27 14:01:29 --> Controller Class Initialized
INFO - 2026-04-27 14:01:29 --> File loaded: C:\laragon\www\macha\application\views\admin/settings.php
INFO - 2026-04-27 14:01:29 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:01:29 --> Final output sent to browser
DEBUG - 2026-04-27 14:01:29 --> Total execution time: 0.1652
INFO - 2026-04-27 14:01:34 --> Config Class Initialized
INFO - 2026-04-27 14:01:34 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:01:34 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:01:34 --> Utf8 Class Initialized
INFO - 2026-04-27 14:01:34 --> URI Class Initialized
INFO - 2026-04-27 14:01:34 --> Router Class Initialized
INFO - 2026-04-27 14:01:34 --> Output Class Initialized
INFO - 2026-04-27 14:01:34 --> Security Class Initialized
DEBUG - 2026-04-27 14:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:01:34 --> Input Class Initialized
INFO - 2026-04-27 14:01:34 --> Language Class Initialized
INFO - 2026-04-27 14:01:34 --> Loader Class Initialized
INFO - 2026-04-27 14:01:34 --> Helper loaded: url_helper
INFO - 2026-04-27 14:01:34 --> Helper loaded: file_helper
INFO - 2026-04-27 14:01:34 --> Helper loaded: form_helper
INFO - 2026-04-27 14:01:34 --> Helper loaded: security_helper
INFO - 2026-04-27 14:01:34 --> Database Driver Class Initialized
INFO - 2026-04-27 14:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:01:34 --> Upload Class Initialized
INFO - 2026-04-27 14:01:34 --> Form Validation Class Initialized
INFO - 2026-04-27 14:01:34 --> Model "M_product" initialized
INFO - 2026-04-27 14:01:34 --> Model "M_settings" initialized
INFO - 2026-04-27 14:01:34 --> Controller Class Initialized
INFO - 2026-04-27 14:01:34 --> File loaded: C:\laragon\www\macha\application\views\admin/settings.php
INFO - 2026-04-27 14:01:34 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:01:34 --> Final output sent to browser
DEBUG - 2026-04-27 14:01:34 --> Total execution time: 0.1005
INFO - 2026-04-27 14:01:49 --> Config Class Initialized
INFO - 2026-04-27 14:01:49 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:01:49 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:01:49 --> Utf8 Class Initialized
INFO - 2026-04-27 14:01:49 --> URI Class Initialized
DEBUG - 2026-04-27 14:01:49 --> No URI present. Default controller set.
INFO - 2026-04-27 14:01:49 --> Router Class Initialized
INFO - 2026-04-27 14:01:49 --> Output Class Initialized
INFO - 2026-04-27 14:01:49 --> Security Class Initialized
DEBUG - 2026-04-27 14:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:01:49 --> Input Class Initialized
INFO - 2026-04-27 14:01:49 --> Language Class Initialized
INFO - 2026-04-27 14:01:49 --> Loader Class Initialized
INFO - 2026-04-27 14:01:49 --> Helper loaded: url_helper
INFO - 2026-04-27 14:01:49 --> Helper loaded: file_helper
INFO - 2026-04-27 14:01:49 --> Helper loaded: form_helper
INFO - 2026-04-27 14:01:49 --> Helper loaded: security_helper
INFO - 2026-04-27 14:01:49 --> Database Driver Class Initialized
INFO - 2026-04-27 14:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:01:49 --> Upload Class Initialized
INFO - 2026-04-27 14:01:49 --> Form Validation Class Initialized
INFO - 2026-04-27 14:01:49 --> Model "M_product" initialized
INFO - 2026-04-27 14:01:49 --> Model "M_settings" initialized
INFO - 2026-04-27 14:01:49 --> Controller Class Initialized
INFO - 2026-04-27 14:01:49 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-27 14:01:49 --> Final output sent to browser
DEBUG - 2026-04-27 14:01:49 --> Total execution time: 0.0837
INFO - 2026-04-27 14:02:44 --> Config Class Initialized
INFO - 2026-04-27 14:02:44 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:02:44 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:02:44 --> Utf8 Class Initialized
INFO - 2026-04-27 14:02:44 --> URI Class Initialized
INFO - 2026-04-27 14:02:44 --> Router Class Initialized
INFO - 2026-04-27 14:02:44 --> Output Class Initialized
INFO - 2026-04-27 14:02:44 --> Security Class Initialized
DEBUG - 2026-04-27 14:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:02:44 --> Input Class Initialized
INFO - 2026-04-27 14:02:44 --> Language Class Initialized
INFO - 2026-04-27 14:02:44 --> Loader Class Initialized
INFO - 2026-04-27 14:02:44 --> Helper loaded: url_helper
INFO - 2026-04-27 14:02:44 --> Helper loaded: file_helper
INFO - 2026-04-27 14:02:44 --> Helper loaded: form_helper
INFO - 2026-04-27 14:02:44 --> Helper loaded: security_helper
INFO - 2026-04-27 14:02:44 --> Database Driver Class Initialized
INFO - 2026-04-27 14:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:02:44 --> Upload Class Initialized
INFO - 2026-04-27 14:02:44 --> Form Validation Class Initialized
INFO - 2026-04-27 14:02:44 --> Model "M_product" initialized
INFO - 2026-04-27 14:02:44 --> Model "M_settings" initialized
INFO - 2026-04-27 14:02:44 --> Controller Class Initialized
INFO - 2026-04-27 14:02:44 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 14:02:44 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:02:44 --> Final output sent to browser
DEBUG - 2026-04-27 14:02:44 --> Total execution time: 0.0901
INFO - 2026-04-27 14:02:48 --> Config Class Initialized
INFO - 2026-04-27 14:02:48 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:02:48 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:02:48 --> Utf8 Class Initialized
INFO - 2026-04-27 14:02:48 --> URI Class Initialized
INFO - 2026-04-27 14:02:48 --> Router Class Initialized
INFO - 2026-04-27 14:02:48 --> Output Class Initialized
INFO - 2026-04-27 14:02:48 --> Security Class Initialized
DEBUG - 2026-04-27 14:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:02:48 --> Input Class Initialized
INFO - 2026-04-27 14:02:48 --> Language Class Initialized
INFO - 2026-04-27 14:02:48 --> Loader Class Initialized
INFO - 2026-04-27 14:02:48 --> Helper loaded: url_helper
INFO - 2026-04-27 14:02:48 --> Helper loaded: file_helper
INFO - 2026-04-27 14:02:48 --> Helper loaded: form_helper
INFO - 2026-04-27 14:02:48 --> Helper loaded: security_helper
INFO - 2026-04-27 14:02:48 --> Database Driver Class Initialized
INFO - 2026-04-27 14:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:02:48 --> Upload Class Initialized
INFO - 2026-04-27 14:02:48 --> Form Validation Class Initialized
INFO - 2026-04-27 14:02:48 --> Model "M_product" initialized
INFO - 2026-04-27 14:02:48 --> Model "M_settings" initialized
INFO - 2026-04-27 14:02:48 --> Controller Class Initialized
INFO - 2026-04-27 14:02:48 --> Model "M_sales" initialized
INFO - 2026-04-27 14:02:48 --> File loaded: C:\laragon\www\macha\application\views\admin/order_list.php
INFO - 2026-04-27 14:02:48 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:02:48 --> Final output sent to browser
DEBUG - 2026-04-27 14:02:48 --> Total execution time: 0.0789
INFO - 2026-04-27 14:02:52 --> Config Class Initialized
INFO - 2026-04-27 14:02:52 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:02:52 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:02:52 --> Utf8 Class Initialized
INFO - 2026-04-27 14:02:52 --> URI Class Initialized
INFO - 2026-04-27 14:02:52 --> Router Class Initialized
INFO - 2026-04-27 14:02:52 --> Output Class Initialized
INFO - 2026-04-27 14:02:52 --> Security Class Initialized
DEBUG - 2026-04-27 14:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:02:52 --> Input Class Initialized
INFO - 2026-04-27 14:02:52 --> Language Class Initialized
INFO - 2026-04-27 14:02:52 --> Loader Class Initialized
INFO - 2026-04-27 14:02:52 --> Helper loaded: url_helper
INFO - 2026-04-27 14:02:52 --> Helper loaded: file_helper
INFO - 2026-04-27 14:02:52 --> Helper loaded: form_helper
INFO - 2026-04-27 14:02:52 --> Helper loaded: security_helper
INFO - 2026-04-27 14:02:52 --> Database Driver Class Initialized
INFO - 2026-04-27 14:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:02:52 --> Upload Class Initialized
INFO - 2026-04-27 14:02:52 --> Form Validation Class Initialized
INFO - 2026-04-27 14:02:52 --> Model "M_product" initialized
INFO - 2026-04-27 14:02:52 --> Model "M_settings" initialized
INFO - 2026-04-27 14:02:52 --> Controller Class Initialized
DEBUG - 2026-04-27 14:02:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2026-04-27 14:02:52 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-27 14:02:52 --> File loaded: C:\laragon\www\macha\application\views\products/list_product.php
INFO - 2026-04-27 14:02:52 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:02:52 --> Final output sent to browser
DEBUG - 2026-04-27 14:02:52 --> Total execution time: 0.1078
INFO - 2026-04-27 14:02:53 --> Config Class Initialized
INFO - 2026-04-27 14:02:53 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:02:53 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:02:53 --> Utf8 Class Initialized
INFO - 2026-04-27 14:02:53 --> URI Class Initialized
INFO - 2026-04-27 14:02:53 --> Router Class Initialized
INFO - 2026-04-27 14:02:53 --> Output Class Initialized
INFO - 2026-04-27 14:02:53 --> Security Class Initialized
DEBUG - 2026-04-27 14:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:02:53 --> Input Class Initialized
INFO - 2026-04-27 14:02:53 --> Language Class Initialized
INFO - 2026-04-27 14:02:53 --> Loader Class Initialized
INFO - 2026-04-27 14:02:53 --> Helper loaded: url_helper
INFO - 2026-04-27 14:02:53 --> Helper loaded: file_helper
INFO - 2026-04-27 14:02:53 --> Helper loaded: form_helper
INFO - 2026-04-27 14:02:53 --> Helper loaded: security_helper
INFO - 2026-04-27 14:02:53 --> Database Driver Class Initialized
INFO - 2026-04-27 14:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:02:53 --> Upload Class Initialized
INFO - 2026-04-27 14:02:53 --> Form Validation Class Initialized
INFO - 2026-04-27 14:02:53 --> Model "M_product" initialized
INFO - 2026-04-27 14:02:53 --> Model "M_settings" initialized
INFO - 2026-04-27 14:02:53 --> Controller Class Initialized
DEBUG - 2026-04-27 14:02:53 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2026-04-27 14:02:53 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-27 14:02:53 --> File loaded: C:\laragon\www\macha\application\views\products/add_product.php
INFO - 2026-04-27 14:02:53 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:02:53 --> Final output sent to browser
DEBUG - 2026-04-27 14:02:53 --> Total execution time: 0.0786
INFO - 2026-04-27 14:02:53 --> Config Class Initialized
INFO - 2026-04-27 14:02:53 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:02:53 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:02:53 --> Utf8 Class Initialized
INFO - 2026-04-27 14:02:53 --> URI Class Initialized
INFO - 2026-04-27 14:02:53 --> Router Class Initialized
INFO - 2026-04-27 14:02:53 --> Output Class Initialized
INFO - 2026-04-27 14:02:53 --> Security Class Initialized
DEBUG - 2026-04-27 14:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:02:53 --> Input Class Initialized
INFO - 2026-04-27 14:02:53 --> Language Class Initialized
INFO - 2026-04-27 14:02:53 --> Loader Class Initialized
INFO - 2026-04-27 14:02:53 --> Helper loaded: url_helper
INFO - 2026-04-27 14:02:53 --> Helper loaded: file_helper
INFO - 2026-04-27 14:02:53 --> Helper loaded: form_helper
INFO - 2026-04-27 14:02:53 --> Helper loaded: security_helper
INFO - 2026-04-27 14:02:54 --> Database Driver Class Initialized
INFO - 2026-04-27 14:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:02:54 --> Upload Class Initialized
INFO - 2026-04-27 14:02:54 --> Form Validation Class Initialized
INFO - 2026-04-27 14:02:54 --> Model "M_product" initialized
INFO - 2026-04-27 14:02:54 --> Model "M_settings" initialized
INFO - 2026-04-27 14:02:54 --> Controller Class Initialized
DEBUG - 2026-04-27 14:02:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2026-04-27 14:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-27 14:02:54 --> File loaded: C:\laragon\www\macha\application\views\products/add_product.php
INFO - 2026-04-27 14:02:54 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:02:54 --> Final output sent to browser
DEBUG - 2026-04-27 14:02:54 --> Total execution time: 0.0749
INFO - 2026-04-27 14:02:55 --> Config Class Initialized
INFO - 2026-04-27 14:02:55 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:02:55 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:02:55 --> Utf8 Class Initialized
INFO - 2026-04-27 14:02:55 --> URI Class Initialized
INFO - 2026-04-27 14:02:55 --> Router Class Initialized
INFO - 2026-04-27 14:02:55 --> Output Class Initialized
INFO - 2026-04-27 14:02:55 --> Security Class Initialized
DEBUG - 2026-04-27 14:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:02:55 --> Input Class Initialized
INFO - 2026-04-27 14:02:55 --> Language Class Initialized
INFO - 2026-04-27 14:02:55 --> Loader Class Initialized
INFO - 2026-04-27 14:02:55 --> Helper loaded: url_helper
INFO - 2026-04-27 14:02:55 --> Helper loaded: file_helper
INFO - 2026-04-27 14:02:55 --> Helper loaded: form_helper
INFO - 2026-04-27 14:02:55 --> Helper loaded: security_helper
INFO - 2026-04-27 14:02:55 --> Database Driver Class Initialized
INFO - 2026-04-27 14:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:02:55 --> Upload Class Initialized
INFO - 2026-04-27 14:02:55 --> Form Validation Class Initialized
INFO - 2026-04-27 14:02:55 --> Model "M_product" initialized
INFO - 2026-04-27 14:02:55 --> Model "M_settings" initialized
INFO - 2026-04-27 14:02:55 --> Controller Class Initialized
INFO - 2026-04-27 14:02:55 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 14:02:55 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:02:55 --> Final output sent to browser
DEBUG - 2026-04-27 14:02:55 --> Total execution time: 0.0996
INFO - 2026-04-27 14:07:54 --> Config Class Initialized
INFO - 2026-04-27 14:07:54 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:07:54 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:07:54 --> Utf8 Class Initialized
INFO - 2026-04-27 14:07:54 --> URI Class Initialized
INFO - 2026-04-27 14:07:54 --> Router Class Initialized
INFO - 2026-04-27 14:07:54 --> Output Class Initialized
INFO - 2026-04-27 14:07:54 --> Security Class Initialized
DEBUG - 2026-04-27 14:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:07:54 --> Input Class Initialized
INFO - 2026-04-27 14:07:54 --> Language Class Initialized
INFO - 2026-04-27 14:07:54 --> Loader Class Initialized
INFO - 2026-04-27 14:07:54 --> Helper loaded: url_helper
INFO - 2026-04-27 14:07:54 --> Helper loaded: file_helper
INFO - 2026-04-27 14:07:54 --> Helper loaded: form_helper
INFO - 2026-04-27 14:07:54 --> Helper loaded: security_helper
INFO - 2026-04-27 14:07:54 --> Database Driver Class Initialized
INFO - 2026-04-27 14:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:07:54 --> Upload Class Initialized
INFO - 2026-04-27 14:07:54 --> Form Validation Class Initialized
INFO - 2026-04-27 14:07:54 --> Model "M_product" initialized
INFO - 2026-04-27 14:07:54 --> Model "M_settings" initialized
INFO - 2026-04-27 14:07:54 --> Controller Class Initialized
INFO - 2026-04-27 14:07:54 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-27 14:07:54 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:07:54 --> Final output sent to browser
DEBUG - 2026-04-27 14:07:54 --> Total execution time: 0.0809
INFO - 2026-04-27 14:08:01 --> Config Class Initialized
INFO - 2026-04-27 14:08:01 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:08:01 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:08:01 --> Utf8 Class Initialized
INFO - 2026-04-27 14:08:01 --> URI Class Initialized
INFO - 2026-04-27 14:08:01 --> Router Class Initialized
INFO - 2026-04-27 14:08:01 --> Output Class Initialized
INFO - 2026-04-27 14:08:01 --> Security Class Initialized
DEBUG - 2026-04-27 14:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:08:01 --> Input Class Initialized
INFO - 2026-04-27 14:08:01 --> Language Class Initialized
INFO - 2026-04-27 14:08:01 --> Loader Class Initialized
INFO - 2026-04-27 14:08:01 --> Helper loaded: url_helper
INFO - 2026-04-27 14:08:01 --> Helper loaded: file_helper
INFO - 2026-04-27 14:08:01 --> Helper loaded: form_helper
INFO - 2026-04-27 14:08:01 --> Helper loaded: security_helper
INFO - 2026-04-27 14:08:01 --> Database Driver Class Initialized
INFO - 2026-04-27 14:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:08:01 --> Upload Class Initialized
INFO - 2026-04-27 14:08:01 --> Form Validation Class Initialized
INFO - 2026-04-27 14:08:01 --> Model "M_product" initialized
INFO - 2026-04-27 14:08:01 --> Model "M_settings" initialized
INFO - 2026-04-27 14:08:01 --> Controller Class Initialized
INFO - 2026-04-27 14:08:01 --> File loaded: C:\laragon\www\macha\application\views\admin/settings.php
INFO - 2026-04-27 14:08:01 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:08:01 --> Final output sent to browser
DEBUG - 2026-04-27 14:08:01 --> Total execution time: 0.0852
INFO - 2026-04-27 14:08:07 --> Config Class Initialized
INFO - 2026-04-27 14:08:07 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:08:07 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:08:07 --> Utf8 Class Initialized
INFO - 2026-04-27 14:08:07 --> URI Class Initialized
INFO - 2026-04-27 14:08:07 --> Router Class Initialized
INFO - 2026-04-27 14:08:07 --> Output Class Initialized
INFO - 2026-04-27 14:08:07 --> Security Class Initialized
DEBUG - 2026-04-27 14:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:08:07 --> Input Class Initialized
INFO - 2026-04-27 14:08:07 --> Language Class Initialized
INFO - 2026-04-27 14:08:07 --> Loader Class Initialized
INFO - 2026-04-27 14:08:07 --> Helper loaded: url_helper
INFO - 2026-04-27 14:08:07 --> Helper loaded: file_helper
INFO - 2026-04-27 14:08:07 --> Helper loaded: form_helper
INFO - 2026-04-27 14:08:07 --> Helper loaded: security_helper
INFO - 2026-04-27 14:08:07 --> Database Driver Class Initialized
INFO - 2026-04-27 14:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:08:07 --> Upload Class Initialized
INFO - 2026-04-27 14:08:07 --> Form Validation Class Initialized
INFO - 2026-04-27 14:08:07 --> Model "M_product" initialized
INFO - 2026-04-27 14:08:07 --> Model "M_settings" initialized
INFO - 2026-04-27 14:08:07 --> Controller Class Initialized
INFO - 2026-04-27 14:08:07 --> Model "M_sales" initialized
ERROR - 2026-04-27 14:08:07 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 90
ERROR - 2026-04-27 14:08:07 --> Severity: 8192 --> substr(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 91
ERROR - 2026-04-27 14:08:07 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 90
ERROR - 2026-04-27 14:08:07 --> Severity: 8192 --> substr(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 91
ERROR - 2026-04-27 14:08:07 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 90
ERROR - 2026-04-27 14:08:07 --> Severity: 8192 --> substr(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 91
ERROR - 2026-04-27 14:08:07 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 90
ERROR - 2026-04-27 14:08:07 --> Severity: 8192 --> substr(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 91
ERROR - 2026-04-27 14:08:07 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 90
ERROR - 2026-04-27 14:08:07 --> Severity: 8192 --> substr(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 91
ERROR - 2026-04-27 14:08:07 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 90
ERROR - 2026-04-27 14:08:07 --> Severity: 8192 --> substr(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 91
ERROR - 2026-04-27 14:08:07 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 90
ERROR - 2026-04-27 14:08:07 --> Severity: 8192 --> substr(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 91
INFO - 2026-04-27 14:08:07 --> File loaded: C:\laragon\www\macha\application\views\admin/order_history.php
INFO - 2026-04-27 14:08:07 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:08:07 --> Final output sent to browser
DEBUG - 2026-04-27 14:08:07 --> Total execution time: 0.0996
INFO - 2026-04-27 14:11:03 --> Config Class Initialized
INFO - 2026-04-27 14:11:03 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:11:03 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:11:03 --> Utf8 Class Initialized
INFO - 2026-04-27 14:11:03 --> URI Class Initialized
INFO - 2026-04-27 14:11:03 --> Router Class Initialized
INFO - 2026-04-27 14:11:03 --> Output Class Initialized
INFO - 2026-04-27 14:11:03 --> Security Class Initialized
DEBUG - 2026-04-27 14:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:11:03 --> Input Class Initialized
INFO - 2026-04-27 14:11:03 --> Language Class Initialized
INFO - 2026-04-27 14:11:03 --> Loader Class Initialized
INFO - 2026-04-27 14:11:03 --> Helper loaded: url_helper
INFO - 2026-04-27 14:11:03 --> Helper loaded: file_helper
INFO - 2026-04-27 14:11:03 --> Helper loaded: form_helper
INFO - 2026-04-27 14:11:03 --> Helper loaded: security_helper
INFO - 2026-04-27 14:11:03 --> Database Driver Class Initialized
INFO - 2026-04-27 14:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:11:03 --> Upload Class Initialized
INFO - 2026-04-27 14:11:03 --> Form Validation Class Initialized
INFO - 2026-04-27 14:11:03 --> Model "M_product" initialized
INFO - 2026-04-27 14:11:03 --> Model "M_settings" initialized
INFO - 2026-04-27 14:11:03 --> Controller Class Initialized
INFO - 2026-04-27 14:11:03 --> Model "M_sales" initialized
ERROR - 2026-04-27 14:11:03 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 90
ERROR - 2026-04-27 14:11:03 --> Severity: 8192 --> substr(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 91
ERROR - 2026-04-27 14:11:03 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 90
ERROR - 2026-04-27 14:11:03 --> Severity: 8192 --> substr(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 91
ERROR - 2026-04-27 14:11:03 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 90
ERROR - 2026-04-27 14:11:03 --> Severity: 8192 --> substr(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 91
ERROR - 2026-04-27 14:11:03 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 90
ERROR - 2026-04-27 14:11:03 --> Severity: 8192 --> substr(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 91
ERROR - 2026-04-27 14:11:03 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 90
ERROR - 2026-04-27 14:11:03 --> Severity: 8192 --> substr(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 91
ERROR - 2026-04-27 14:11:03 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 90
ERROR - 2026-04-27 14:11:03 --> Severity: 8192 --> substr(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 91
ERROR - 2026-04-27 14:11:03 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 90
ERROR - 2026-04-27 14:11:03 --> Severity: 8192 --> substr(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\macha\application\views\admin\order_history.php 91
INFO - 2026-04-27 14:11:03 --> File loaded: C:\laragon\www\macha\application\views\admin/order_history.php
INFO - 2026-04-27 14:11:03 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-27 14:11:03 --> Final output sent to browser
DEBUG - 2026-04-27 14:11:03 --> Total execution time: 0.0950
INFO - 2026-04-27 14:11:06 --> Config Class Initialized
INFO - 2026-04-27 14:11:06 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:11:06 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:11:06 --> Utf8 Class Initialized
INFO - 2026-04-27 14:11:06 --> URI Class Initialized
DEBUG - 2026-04-27 14:11:06 --> No URI present. Default controller set.
INFO - 2026-04-27 14:11:06 --> Router Class Initialized
INFO - 2026-04-27 14:11:06 --> Output Class Initialized
INFO - 2026-04-27 14:11:06 --> Security Class Initialized
DEBUG - 2026-04-27 14:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:11:06 --> Input Class Initialized
INFO - 2026-04-27 14:11:06 --> Language Class Initialized
INFO - 2026-04-27 14:11:06 --> Loader Class Initialized
INFO - 2026-04-27 14:11:06 --> Helper loaded: url_helper
INFO - 2026-04-27 14:11:06 --> Helper loaded: file_helper
INFO - 2026-04-27 14:11:06 --> Helper loaded: form_helper
INFO - 2026-04-27 14:11:06 --> Helper loaded: security_helper
INFO - 2026-04-27 14:11:06 --> Database Driver Class Initialized
INFO - 2026-04-27 14:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:11:06 --> Upload Class Initialized
INFO - 2026-04-27 14:11:06 --> Form Validation Class Initialized
INFO - 2026-04-27 14:11:06 --> Model "M_product" initialized
INFO - 2026-04-27 14:11:06 --> Model "M_settings" initialized
INFO - 2026-04-27 14:11:06 --> Controller Class Initialized
INFO - 2026-04-27 14:11:06 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-27 14:11:06 --> Final output sent to browser
DEBUG - 2026-04-27 14:11:06 --> Total execution time: 0.0852
INFO - 2026-04-27 14:11:13 --> Config Class Initialized
INFO - 2026-04-27 14:11:13 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:11:13 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:11:13 --> Utf8 Class Initialized
INFO - 2026-04-27 14:11:13 --> URI Class Initialized
INFO - 2026-04-27 14:11:13 --> Router Class Initialized
INFO - 2026-04-27 14:11:13 --> Output Class Initialized
INFO - 2026-04-27 14:11:13 --> Security Class Initialized
DEBUG - 2026-04-27 14:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:11:13 --> Input Class Initialized
INFO - 2026-04-27 14:11:13 --> Language Class Initialized
INFO - 2026-04-27 14:11:13 --> Loader Class Initialized
INFO - 2026-04-27 14:11:13 --> Helper loaded: url_helper
INFO - 2026-04-27 14:11:13 --> Helper loaded: file_helper
INFO - 2026-04-27 14:11:13 --> Helper loaded: form_helper
INFO - 2026-04-27 14:11:13 --> Helper loaded: security_helper
INFO - 2026-04-27 14:11:13 --> Database Driver Class Initialized
INFO - 2026-04-27 14:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:11:13 --> Upload Class Initialized
INFO - 2026-04-27 14:11:13 --> Form Validation Class Initialized
INFO - 2026-04-27 14:11:13 --> Model "M_product" initialized
INFO - 2026-04-27 14:11:13 --> Model "M_settings" initialized
INFO - 2026-04-27 14:11:13 --> Controller Class Initialized
INFO - 2026-04-27 14:11:13 --> User Agent Class Initialized
INFO - 2026-04-27 14:11:13 --> Database Forge Class Initialized
INFO - 2026-04-27 14:11:13 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-04-27 14:11:13 --> Final output sent to browser
DEBUG - 2026-04-27 14:11:13 --> Total execution time: 0.0948
INFO - 2026-04-27 14:15:42 --> Config Class Initialized
INFO - 2026-04-27 14:15:42 --> Hooks Class Initialized
DEBUG - 2026-04-27 14:15:42 --> UTF-8 Support Enabled
INFO - 2026-04-27 14:15:42 --> Utf8 Class Initialized
INFO - 2026-04-27 14:15:42 --> URI Class Initialized
INFO - 2026-04-27 14:15:42 --> Router Class Initialized
INFO - 2026-04-27 14:15:42 --> Output Class Initialized
INFO - 2026-04-27 14:15:42 --> Security Class Initialized
DEBUG - 2026-04-27 14:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-27 14:15:42 --> Input Class Initialized
INFO - 2026-04-27 14:15:42 --> Language Class Initialized
INFO - 2026-04-27 14:15:42 --> Loader Class Initialized
INFO - 2026-04-27 14:15:42 --> Helper loaded: url_helper
INFO - 2026-04-27 14:15:42 --> Helper loaded: file_helper
INFO - 2026-04-27 14:15:42 --> Helper loaded: form_helper
INFO - 2026-04-27 14:15:42 --> Helper loaded: security_helper
INFO - 2026-04-27 14:15:42 --> Database Driver Class Initialized
INFO - 2026-04-27 14:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-27 14:15:42 --> Upload Class Initialized
INFO - 2026-04-27 14:15:42 --> Form Validation Class Initialized
INFO - 2026-04-27 14:15:42 --> Model "M_product" initialized
INFO - 2026-04-27 14:15:42 --> Model "M_settings" initialized
INFO - 2026-04-27 14:15:42 --> Controller Class Initialized
INFO - 2026-04-27 14:15:42 --> User Agent Class Initialized
INFO - 2026-04-27 14:15:42 --> Database Forge Class Initialized
INFO - 2026-04-27 14:15:42 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-04-27 14:15:42 --> Final output sent to browser
DEBUG - 2026-04-27 14:15:42 --> Total execution time: 0.0807
