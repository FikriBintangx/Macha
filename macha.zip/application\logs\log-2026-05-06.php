<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-05-06 03:59:56 --> Config Class Initialized
INFO - 2026-05-06 03:59:56 --> Hooks Class Initialized
DEBUG - 2026-05-06 03:59:56 --> UTF-8 Support Enabled
INFO - 2026-05-06 03:59:56 --> Utf8 Class Initialized
INFO - 2026-05-06 03:59:56 --> URI Class Initialized
DEBUG - 2026-05-06 03:59:56 --> No URI present. Default controller set.
INFO - 2026-05-06 03:59:56 --> Router Class Initialized
INFO - 2026-05-06 03:59:56 --> Output Class Initialized
INFO - 2026-05-06 03:59:56 --> Security Class Initialized
DEBUG - 2026-05-06 03:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 03:59:56 --> Input Class Initialized
INFO - 2026-05-06 03:59:56 --> Language Class Initialized
INFO - 2026-05-06 03:59:56 --> Loader Class Initialized
INFO - 2026-05-06 03:59:56 --> Helper loaded: url_helper
INFO - 2026-05-06 03:59:56 --> Helper loaded: file_helper
INFO - 2026-05-06 03:59:56 --> Helper loaded: form_helper
INFO - 2026-05-06 03:59:56 --> Helper loaded: security_helper
INFO - 2026-05-06 03:59:57 --> Database Driver Class Initialized
INFO - 2026-05-06 03:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 03:59:57 --> Upload Class Initialized
INFO - 2026-05-06 03:59:57 --> Form Validation Class Initialized
INFO - 2026-05-06 03:59:57 --> Model "M_product" initialized
INFO - 2026-05-06 03:59:57 --> Model "M_settings" initialized
INFO - 2026-05-06 03:59:57 --> Controller Class Initialized
INFO - 2026-05-06 03:59:57 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 03:59:57 --> Final output sent to browser
DEBUG - 2026-05-06 03:59:57 --> Total execution time: 1.7985
INFO - 2026-05-06 04:00:05 --> Config Class Initialized
INFO - 2026-05-06 04:00:05 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:00:05 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:00:05 --> Utf8 Class Initialized
INFO - 2026-05-06 04:00:05 --> URI Class Initialized
INFO - 2026-05-06 04:00:05 --> Router Class Initialized
INFO - 2026-05-06 04:00:05 --> Output Class Initialized
INFO - 2026-05-06 04:00:05 --> Security Class Initialized
DEBUG - 2026-05-06 04:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:00:05 --> Input Class Initialized
INFO - 2026-05-06 04:00:05 --> Language Class Initialized
INFO - 2026-05-06 04:00:05 --> Loader Class Initialized
INFO - 2026-05-06 04:00:05 --> Helper loaded: url_helper
INFO - 2026-05-06 04:00:05 --> Helper loaded: file_helper
INFO - 2026-05-06 04:00:05 --> Helper loaded: form_helper
INFO - 2026-05-06 04:00:05 --> Helper loaded: security_helper
INFO - 2026-05-06 04:00:05 --> Database Driver Class Initialized
INFO - 2026-05-06 04:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:00:05 --> Upload Class Initialized
INFO - 2026-05-06 04:00:05 --> Form Validation Class Initialized
INFO - 2026-05-06 04:00:05 --> Model "M_product" initialized
INFO - 2026-05-06 04:00:05 --> Model "M_settings" initialized
INFO - 2026-05-06 04:00:05 --> Controller Class Initialized
DEBUG - 2026-05-06 04:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-06 04:00:05 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 04:00:05 --> File loaded: C:\laragon\www\macha\application\views\auth/login.php
INFO - 2026-05-06 04:00:05 --> Final output sent to browser
DEBUG - 2026-05-06 04:00:05 --> Total execution time: 0.1900
INFO - 2026-05-06 04:01:01 --> Config Class Initialized
INFO - 2026-05-06 04:01:01 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:01:01 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:01:01 --> Utf8 Class Initialized
INFO - 2026-05-06 04:01:01 --> URI Class Initialized
INFO - 2026-05-06 04:01:01 --> Router Class Initialized
INFO - 2026-05-06 04:01:01 --> Output Class Initialized
INFO - 2026-05-06 04:01:01 --> Security Class Initialized
DEBUG - 2026-05-06 04:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:01:01 --> Input Class Initialized
INFO - 2026-05-06 04:01:01 --> Language Class Initialized
INFO - 2026-05-06 04:01:01 --> Loader Class Initialized
INFO - 2026-05-06 04:01:01 --> Helper loaded: url_helper
INFO - 2026-05-06 04:01:01 --> Helper loaded: file_helper
INFO - 2026-05-06 04:01:01 --> Helper loaded: form_helper
INFO - 2026-05-06 04:01:01 --> Helper loaded: security_helper
INFO - 2026-05-06 04:01:01 --> Database Driver Class Initialized
INFO - 2026-05-06 04:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:01:01 --> Upload Class Initialized
INFO - 2026-05-06 04:01:01 --> Form Validation Class Initialized
INFO - 2026-05-06 04:01:01 --> Model "M_product" initialized
INFO - 2026-05-06 04:01:01 --> Model "M_settings" initialized
INFO - 2026-05-06 04:01:01 --> Controller Class Initialized
DEBUG - 2026-05-06 04:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-06 04:01:01 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 04:01:01 --> File loaded: C:\laragon\www\macha\application\views\auth/login.php
INFO - 2026-05-06 04:01:01 --> Final output sent to browser
DEBUG - 2026-05-06 04:01:01 --> Total execution time: 0.0829
INFO - 2026-05-06 04:01:28 --> Config Class Initialized
INFO - 2026-05-06 04:01:28 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:01:28 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:01:28 --> Utf8 Class Initialized
INFO - 2026-05-06 04:01:28 --> URI Class Initialized
INFO - 2026-05-06 04:01:28 --> Router Class Initialized
INFO - 2026-05-06 04:01:28 --> Output Class Initialized
INFO - 2026-05-06 04:01:28 --> Security Class Initialized
DEBUG - 2026-05-06 04:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:01:28 --> Input Class Initialized
INFO - 2026-05-06 04:01:28 --> Language Class Initialized
INFO - 2026-05-06 04:01:28 --> Loader Class Initialized
INFO - 2026-05-06 04:01:28 --> Helper loaded: url_helper
INFO - 2026-05-06 04:01:28 --> Helper loaded: file_helper
INFO - 2026-05-06 04:01:28 --> Helper loaded: form_helper
INFO - 2026-05-06 04:01:28 --> Helper loaded: security_helper
INFO - 2026-05-06 04:01:28 --> Database Driver Class Initialized
INFO - 2026-05-06 04:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:01:28 --> Upload Class Initialized
INFO - 2026-05-06 04:01:28 --> Form Validation Class Initialized
INFO - 2026-05-06 04:01:28 --> Model "M_product" initialized
INFO - 2026-05-06 04:01:28 --> Model "M_settings" initialized
INFO - 2026-05-06 04:01:28 --> Controller Class Initialized
DEBUG - 2026-05-06 04:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-06 04:01:28 --> Config Class Initialized
INFO - 2026-05-06 04:01:28 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:01:28 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:01:28 --> Utf8 Class Initialized
INFO - 2026-05-06 04:01:28 --> URI Class Initialized
INFO - 2026-05-06 04:01:28 --> Router Class Initialized
INFO - 2026-05-06 04:01:28 --> Output Class Initialized
INFO - 2026-05-06 04:01:28 --> Security Class Initialized
DEBUG - 2026-05-06 04:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:01:28 --> Input Class Initialized
INFO - 2026-05-06 04:01:28 --> Language Class Initialized
INFO - 2026-05-06 04:01:28 --> Loader Class Initialized
INFO - 2026-05-06 04:01:28 --> Helper loaded: url_helper
INFO - 2026-05-06 04:01:28 --> Helper loaded: file_helper
INFO - 2026-05-06 04:01:28 --> Helper loaded: form_helper
INFO - 2026-05-06 04:01:28 --> Helper loaded: security_helper
INFO - 2026-05-06 04:01:28 --> Database Driver Class Initialized
INFO - 2026-05-06 04:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:01:28 --> Upload Class Initialized
INFO - 2026-05-06 04:01:28 --> Form Validation Class Initialized
INFO - 2026-05-06 04:01:28 --> Model "M_product" initialized
INFO - 2026-05-06 04:01:28 --> Model "M_settings" initialized
INFO - 2026-05-06 04:01:28 --> Controller Class Initialized
INFO - 2026-05-06 04:01:28 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 04:01:28 --> Final output sent to browser
DEBUG - 2026-05-06 04:01:28 --> Total execution time: 0.0943
INFO - 2026-05-06 04:02:02 --> Config Class Initialized
INFO - 2026-05-06 04:02:02 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:02:02 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:02:02 --> Utf8 Class Initialized
INFO - 2026-05-06 04:02:02 --> URI Class Initialized
INFO - 2026-05-06 04:02:02 --> Router Class Initialized
INFO - 2026-05-06 04:02:02 --> Output Class Initialized
INFO - 2026-05-06 04:02:02 --> Security Class Initialized
DEBUG - 2026-05-06 04:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:02:02 --> Input Class Initialized
INFO - 2026-05-06 04:02:02 --> Language Class Initialized
INFO - 2026-05-06 04:02:02 --> Loader Class Initialized
INFO - 2026-05-06 04:02:02 --> Helper loaded: url_helper
INFO - 2026-05-06 04:02:02 --> Helper loaded: file_helper
INFO - 2026-05-06 04:02:02 --> Helper loaded: form_helper
INFO - 2026-05-06 04:02:02 --> Helper loaded: security_helper
INFO - 2026-05-06 04:02:02 --> Database Driver Class Initialized
INFO - 2026-05-06 04:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:02:02 --> Upload Class Initialized
INFO - 2026-05-06 04:02:02 --> Form Validation Class Initialized
INFO - 2026-05-06 04:02:02 --> Model "M_product" initialized
INFO - 2026-05-06 04:02:02 --> Model "M_settings" initialized
INFO - 2026-05-06 04:02:02 --> Controller Class Initialized
INFO - 2026-05-06 04:02:02 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 04:02:02 --> Final output sent to browser
DEBUG - 2026-05-06 04:02:02 --> Total execution time: 0.0917
INFO - 2026-05-06 04:02:08 --> Config Class Initialized
INFO - 2026-05-06 04:02:08 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:02:08 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:02:09 --> Utf8 Class Initialized
INFO - 2026-05-06 04:02:09 --> URI Class Initialized
INFO - 2026-05-06 04:02:09 --> Router Class Initialized
INFO - 2026-05-06 04:02:09 --> Output Class Initialized
INFO - 2026-05-06 04:02:09 --> Security Class Initialized
DEBUG - 2026-05-06 04:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:02:09 --> Input Class Initialized
INFO - 2026-05-06 04:02:09 --> Language Class Initialized
INFO - 2026-05-06 04:02:09 --> Loader Class Initialized
INFO - 2026-05-06 04:02:09 --> Helper loaded: url_helper
INFO - 2026-05-06 04:02:09 --> Helper loaded: file_helper
INFO - 2026-05-06 04:02:09 --> Helper loaded: form_helper
INFO - 2026-05-06 04:02:09 --> Helper loaded: security_helper
INFO - 2026-05-06 04:02:09 --> Database Driver Class Initialized
INFO - 2026-05-06 04:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:02:09 --> Upload Class Initialized
INFO - 2026-05-06 04:02:09 --> Form Validation Class Initialized
INFO - 2026-05-06 04:02:09 --> Model "M_product" initialized
INFO - 2026-05-06 04:02:09 --> Model "M_settings" initialized
INFO - 2026-05-06 04:02:09 --> Controller Class Initialized
INFO - 2026-05-06 04:02:09 --> Model "M_sales" initialized
INFO - 2026-05-06 04:02:09 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:02:09 --> File loaded: C:\laragon\www\macha\application\views\user/order_history.php
INFO - 2026-05-06 04:02:09 --> Final output sent to browser
DEBUG - 2026-05-06 04:02:09 --> Total execution time: 0.2770
INFO - 2026-05-06 04:02:14 --> Config Class Initialized
INFO - 2026-05-06 04:02:14 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:02:14 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:02:14 --> Utf8 Class Initialized
INFO - 2026-05-06 04:02:14 --> URI Class Initialized
INFO - 2026-05-06 04:02:14 --> Router Class Initialized
INFO - 2026-05-06 04:02:14 --> Output Class Initialized
INFO - 2026-05-06 04:02:14 --> Security Class Initialized
DEBUG - 2026-05-06 04:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:02:14 --> Input Class Initialized
INFO - 2026-05-06 04:02:14 --> Language Class Initialized
INFO - 2026-05-06 04:02:14 --> Loader Class Initialized
INFO - 2026-05-06 04:02:14 --> Helper loaded: url_helper
INFO - 2026-05-06 04:02:14 --> Helper loaded: file_helper
INFO - 2026-05-06 04:02:14 --> Helper loaded: form_helper
INFO - 2026-05-06 04:02:14 --> Helper loaded: security_helper
INFO - 2026-05-06 04:02:14 --> Database Driver Class Initialized
INFO - 2026-05-06 04:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:02:14 --> Upload Class Initialized
INFO - 2026-05-06 04:02:14 --> Form Validation Class Initialized
INFO - 2026-05-06 04:02:14 --> Model "M_product" initialized
INFO - 2026-05-06 04:02:14 --> Model "M_settings" initialized
INFO - 2026-05-06 04:02:14 --> Controller Class Initialized
DEBUG - 2026-05-06 04:02:14 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-06 04:02:14 --> Config Class Initialized
INFO - 2026-05-06 04:02:14 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:02:14 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:02:14 --> Utf8 Class Initialized
INFO - 2026-05-06 04:02:14 --> URI Class Initialized
INFO - 2026-05-06 04:02:14 --> Router Class Initialized
INFO - 2026-05-06 04:02:14 --> Output Class Initialized
INFO - 2026-05-06 04:02:14 --> Security Class Initialized
DEBUG - 2026-05-06 04:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:02:14 --> Input Class Initialized
INFO - 2026-05-06 04:02:14 --> Language Class Initialized
INFO - 2026-05-06 04:02:14 --> Loader Class Initialized
INFO - 2026-05-06 04:02:14 --> Helper loaded: url_helper
INFO - 2026-05-06 04:02:14 --> Helper loaded: file_helper
INFO - 2026-05-06 04:02:14 --> Helper loaded: form_helper
INFO - 2026-05-06 04:02:14 --> Helper loaded: security_helper
INFO - 2026-05-06 04:02:14 --> Database Driver Class Initialized
INFO - 2026-05-06 04:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:02:14 --> Upload Class Initialized
INFO - 2026-05-06 04:02:14 --> Form Validation Class Initialized
INFO - 2026-05-06 04:02:14 --> Model "M_product" initialized
INFO - 2026-05-06 04:02:14 --> Model "M_settings" initialized
INFO - 2026-05-06 04:02:14 --> Controller Class Initialized
DEBUG - 2026-05-06 04:02:14 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-06 04:02:14 --> File loaded: C:\laragon\www\macha\application\views\auth/login.php
INFO - 2026-05-06 04:02:14 --> Final output sent to browser
DEBUG - 2026-05-06 04:02:14 --> Total execution time: 0.0740
INFO - 2026-05-06 04:03:37 --> Config Class Initialized
INFO - 2026-05-06 04:03:37 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:03:37 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:03:37 --> Utf8 Class Initialized
INFO - 2026-05-06 04:03:37 --> URI Class Initialized
INFO - 2026-05-06 04:03:37 --> Router Class Initialized
INFO - 2026-05-06 04:03:37 --> Output Class Initialized
INFO - 2026-05-06 04:03:37 --> Security Class Initialized
DEBUG - 2026-05-06 04:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:03:37 --> Input Class Initialized
INFO - 2026-05-06 04:03:37 --> Language Class Initialized
INFO - 2026-05-06 04:03:37 --> Loader Class Initialized
INFO - 2026-05-06 04:03:37 --> Helper loaded: url_helper
INFO - 2026-05-06 04:03:37 --> Helper loaded: file_helper
INFO - 2026-05-06 04:03:37 --> Helper loaded: form_helper
INFO - 2026-05-06 04:03:37 --> Helper loaded: security_helper
INFO - 2026-05-06 04:03:37 --> Database Driver Class Initialized
INFO - 2026-05-06 04:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:03:37 --> Upload Class Initialized
INFO - 2026-05-06 04:03:37 --> Form Validation Class Initialized
INFO - 2026-05-06 04:03:37 --> Model "M_product" initialized
INFO - 2026-05-06 04:03:37 --> Model "M_settings" initialized
INFO - 2026-05-06 04:03:37 --> Controller Class Initialized
DEBUG - 2026-05-06 04:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-06 04:03:37 --> File loaded: C:\laragon\www\macha\application\views\auth/login.php
INFO - 2026-05-06 04:03:37 --> Final output sent to browser
DEBUG - 2026-05-06 04:03:37 --> Total execution time: 0.0746
INFO - 2026-05-06 04:03:45 --> Config Class Initialized
INFO - 2026-05-06 04:03:45 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:03:45 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:03:45 --> Utf8 Class Initialized
INFO - 2026-05-06 04:03:45 --> URI Class Initialized
INFO - 2026-05-06 04:03:45 --> Router Class Initialized
INFO - 2026-05-06 04:03:45 --> Output Class Initialized
INFO - 2026-05-06 04:03:45 --> Security Class Initialized
DEBUG - 2026-05-06 04:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:03:45 --> Input Class Initialized
INFO - 2026-05-06 04:03:45 --> Language Class Initialized
INFO - 2026-05-06 04:03:45 --> Loader Class Initialized
INFO - 2026-05-06 04:03:45 --> Helper loaded: url_helper
INFO - 2026-05-06 04:03:45 --> Helper loaded: file_helper
INFO - 2026-05-06 04:03:45 --> Helper loaded: form_helper
INFO - 2026-05-06 04:03:45 --> Helper loaded: security_helper
INFO - 2026-05-06 04:03:45 --> Database Driver Class Initialized
INFO - 2026-05-06 04:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:03:46 --> Upload Class Initialized
INFO - 2026-05-06 04:03:46 --> Form Validation Class Initialized
INFO - 2026-05-06 04:03:46 --> Model "M_product" initialized
INFO - 2026-05-06 04:03:46 --> Model "M_settings" initialized
INFO - 2026-05-06 04:03:46 --> Controller Class Initialized
DEBUG - 2026-05-06 04:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2026-05-06 04:03:46 --> Config Class Initialized
INFO - 2026-05-06 04:03:46 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:03:46 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:03:46 --> Utf8 Class Initialized
INFO - 2026-05-06 04:03:46 --> URI Class Initialized
INFO - 2026-05-06 04:03:46 --> Router Class Initialized
INFO - 2026-05-06 04:03:46 --> Output Class Initialized
INFO - 2026-05-06 04:03:46 --> Security Class Initialized
DEBUG - 2026-05-06 04:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:03:46 --> Input Class Initialized
INFO - 2026-05-06 04:03:46 --> Language Class Initialized
INFO - 2026-05-06 04:03:46 --> Loader Class Initialized
INFO - 2026-05-06 04:03:46 --> Helper loaded: url_helper
INFO - 2026-05-06 04:03:46 --> Helper loaded: file_helper
INFO - 2026-05-06 04:03:46 --> Helper loaded: form_helper
INFO - 2026-05-06 04:03:46 --> Helper loaded: security_helper
INFO - 2026-05-06 04:03:46 --> Database Driver Class Initialized
INFO - 2026-05-06 04:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:03:46 --> Upload Class Initialized
INFO - 2026-05-06 04:03:46 --> Form Validation Class Initialized
INFO - 2026-05-06 04:03:46 --> Model "M_product" initialized
INFO - 2026-05-06 04:03:46 --> Model "M_settings" initialized
INFO - 2026-05-06 04:03:46 --> Controller Class Initialized
INFO - 2026-05-06 04:03:46 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 04:03:46 --> Final output sent to browser
DEBUG - 2026-05-06 04:03:46 --> Total execution time: 0.0935
INFO - 2026-05-06 04:03:53 --> Config Class Initialized
INFO - 2026-05-06 04:03:53 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:03:53 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:03:53 --> Utf8 Class Initialized
INFO - 2026-05-06 04:03:53 --> URI Class Initialized
INFO - 2026-05-06 04:03:53 --> Router Class Initialized
INFO - 2026-05-06 04:03:53 --> Output Class Initialized
INFO - 2026-05-06 04:03:53 --> Security Class Initialized
DEBUG - 2026-05-06 04:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:03:53 --> Input Class Initialized
INFO - 2026-05-06 04:03:53 --> Language Class Initialized
INFO - 2026-05-06 04:03:53 --> Loader Class Initialized
INFO - 2026-05-06 04:03:53 --> Helper loaded: url_helper
INFO - 2026-05-06 04:03:53 --> Helper loaded: file_helper
INFO - 2026-05-06 04:03:53 --> Helper loaded: form_helper
INFO - 2026-05-06 04:03:53 --> Helper loaded: security_helper
INFO - 2026-05-06 04:03:53 --> Database Driver Class Initialized
INFO - 2026-05-06 04:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:03:53 --> Upload Class Initialized
INFO - 2026-05-06 04:03:53 --> Form Validation Class Initialized
INFO - 2026-05-06 04:03:53 --> Model "M_product" initialized
INFO - 2026-05-06 04:03:53 --> Model "M_settings" initialized
INFO - 2026-05-06 04:03:53 --> Controller Class Initialized
INFO - 2026-05-06 04:03:53 --> User Agent Class Initialized
INFO - 2026-05-06 04:03:53 --> Database Forge Class Initialized
INFO - 2026-05-06 04:03:53 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:03:53 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:03:53 --> Final output sent to browser
DEBUG - 2026-05-06 04:03:53 --> Total execution time: 0.4218
INFO - 2026-05-06 04:09:18 --> Config Class Initialized
INFO - 2026-05-06 04:09:18 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:09:18 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:09:18 --> Utf8 Class Initialized
INFO - 2026-05-06 04:09:18 --> URI Class Initialized
INFO - 2026-05-06 04:09:18 --> Router Class Initialized
INFO - 2026-05-06 04:09:18 --> Output Class Initialized
INFO - 2026-05-06 04:09:18 --> Security Class Initialized
DEBUG - 2026-05-06 04:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:09:18 --> Input Class Initialized
INFO - 2026-05-06 04:09:18 --> Language Class Initialized
INFO - 2026-05-06 04:09:18 --> Loader Class Initialized
INFO - 2026-05-06 04:09:18 --> Helper loaded: url_helper
INFO - 2026-05-06 04:09:18 --> Helper loaded: file_helper
INFO - 2026-05-06 04:09:18 --> Helper loaded: form_helper
INFO - 2026-05-06 04:09:18 --> Helper loaded: security_helper
INFO - 2026-05-06 04:09:18 --> Database Driver Class Initialized
INFO - 2026-05-06 04:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:09:18 --> Upload Class Initialized
INFO - 2026-05-06 04:09:18 --> Form Validation Class Initialized
INFO - 2026-05-06 04:09:18 --> Model "M_product" initialized
INFO - 2026-05-06 04:09:18 --> Model "M_settings" initialized
INFO - 2026-05-06 04:09:18 --> Controller Class Initialized
INFO - 2026-05-06 04:09:18 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 04:09:18 --> Final output sent to browser
DEBUG - 2026-05-06 04:09:18 --> Total execution time: 0.0954
INFO - 2026-05-06 04:09:28 --> Config Class Initialized
INFO - 2026-05-06 04:09:28 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:09:28 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:09:28 --> Utf8 Class Initialized
INFO - 2026-05-06 04:09:28 --> URI Class Initialized
INFO - 2026-05-06 04:09:28 --> Router Class Initialized
INFO - 2026-05-06 04:09:28 --> Output Class Initialized
INFO - 2026-05-06 04:09:28 --> Security Class Initialized
DEBUG - 2026-05-06 04:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:09:28 --> Input Class Initialized
INFO - 2026-05-06 04:09:28 --> Language Class Initialized
INFO - 2026-05-06 04:09:28 --> Loader Class Initialized
INFO - 2026-05-06 04:09:28 --> Helper loaded: url_helper
INFO - 2026-05-06 04:09:28 --> Helper loaded: file_helper
INFO - 2026-05-06 04:09:28 --> Helper loaded: form_helper
INFO - 2026-05-06 04:09:28 --> Helper loaded: security_helper
INFO - 2026-05-06 04:09:28 --> Database Driver Class Initialized
INFO - 2026-05-06 04:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:09:28 --> Upload Class Initialized
INFO - 2026-05-06 04:09:28 --> Form Validation Class Initialized
INFO - 2026-05-06 04:09:28 --> Model "M_product" initialized
INFO - 2026-05-06 04:09:28 --> Model "M_settings" initialized
INFO - 2026-05-06 04:09:28 --> Controller Class Initialized
INFO - 2026-05-06 04:09:28 --> User Agent Class Initialized
INFO - 2026-05-06 04:09:28 --> Database Forge Class Initialized
INFO - 2026-05-06 04:09:28 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:09:28 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:09:28 --> Final output sent to browser
DEBUG - 2026-05-06 04:09:28 --> Total execution time: 0.1101
INFO - 2026-05-06 04:13:14 --> Config Class Initialized
INFO - 2026-05-06 04:13:14 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:13:14 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:13:14 --> Utf8 Class Initialized
INFO - 2026-05-06 04:13:14 --> URI Class Initialized
INFO - 2026-05-06 04:13:14 --> Router Class Initialized
INFO - 2026-05-06 04:13:14 --> Output Class Initialized
INFO - 2026-05-06 04:13:14 --> Security Class Initialized
DEBUG - 2026-05-06 04:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:13:14 --> Input Class Initialized
INFO - 2026-05-06 04:13:14 --> Language Class Initialized
INFO - 2026-05-06 04:13:14 --> Loader Class Initialized
INFO - 2026-05-06 04:13:14 --> Helper loaded: url_helper
INFO - 2026-05-06 04:13:14 --> Helper loaded: file_helper
INFO - 2026-05-06 04:13:14 --> Helper loaded: form_helper
INFO - 2026-05-06 04:13:14 --> Helper loaded: security_helper
INFO - 2026-05-06 04:13:14 --> Database Driver Class Initialized
INFO - 2026-05-06 04:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:13:14 --> Upload Class Initialized
INFO - 2026-05-06 04:13:14 --> Form Validation Class Initialized
INFO - 2026-05-06 04:13:14 --> Model "M_product" initialized
INFO - 2026-05-06 04:13:14 --> Model "M_settings" initialized
INFO - 2026-05-06 04:13:14 --> Controller Class Initialized
INFO - 2026-05-06 04:13:14 --> User Agent Class Initialized
INFO - 2026-05-06 04:13:14 --> Database Forge Class Initialized
INFO - 2026-05-06 04:13:14 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:13:14 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:13:14 --> Final output sent to browser
DEBUG - 2026-05-06 04:13:14 --> Total execution time: 0.0981
INFO - 2026-05-06 04:15:13 --> Config Class Initialized
INFO - 2026-05-06 04:15:13 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:15:13 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:15:13 --> Utf8 Class Initialized
INFO - 2026-05-06 04:15:13 --> URI Class Initialized
INFO - 2026-05-06 04:15:13 --> Router Class Initialized
INFO - 2026-05-06 04:15:13 --> Output Class Initialized
INFO - 2026-05-06 04:15:13 --> Security Class Initialized
DEBUG - 2026-05-06 04:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:15:13 --> Input Class Initialized
INFO - 2026-05-06 04:15:13 --> Language Class Initialized
INFO - 2026-05-06 04:15:13 --> Loader Class Initialized
INFO - 2026-05-06 04:15:13 --> Helper loaded: url_helper
INFO - 2026-05-06 04:15:13 --> Helper loaded: file_helper
INFO - 2026-05-06 04:15:13 --> Helper loaded: form_helper
INFO - 2026-05-06 04:15:13 --> Helper loaded: security_helper
INFO - 2026-05-06 04:15:13 --> Database Driver Class Initialized
INFO - 2026-05-06 04:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:15:13 --> Upload Class Initialized
INFO - 2026-05-06 04:15:13 --> Form Validation Class Initialized
INFO - 2026-05-06 04:15:13 --> Model "M_product" initialized
INFO - 2026-05-06 04:15:13 --> Model "M_settings" initialized
INFO - 2026-05-06 04:15:13 --> Controller Class Initialized
INFO - 2026-05-06 04:15:13 --> User Agent Class Initialized
INFO - 2026-05-06 04:15:13 --> Database Forge Class Initialized
INFO - 2026-05-06 04:15:13 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:15:13 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:15:13 --> Final output sent to browser
DEBUG - 2026-05-06 04:15:13 --> Total execution time: 0.1141
INFO - 2026-05-06 04:15:19 --> Config Class Initialized
INFO - 2026-05-06 04:15:19 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:15:19 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:15:19 --> Utf8 Class Initialized
INFO - 2026-05-06 04:15:19 --> URI Class Initialized
INFO - 2026-05-06 04:15:19 --> Router Class Initialized
INFO - 2026-05-06 04:15:19 --> Output Class Initialized
INFO - 2026-05-06 04:15:19 --> Security Class Initialized
DEBUG - 2026-05-06 04:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:15:19 --> Input Class Initialized
INFO - 2026-05-06 04:15:19 --> Language Class Initialized
INFO - 2026-05-06 04:15:19 --> Loader Class Initialized
INFO - 2026-05-06 04:15:19 --> Helper loaded: url_helper
INFO - 2026-05-06 04:15:19 --> Helper loaded: file_helper
INFO - 2026-05-06 04:15:19 --> Helper loaded: form_helper
INFO - 2026-05-06 04:15:19 --> Helper loaded: security_helper
INFO - 2026-05-06 04:15:19 --> Database Driver Class Initialized
INFO - 2026-05-06 04:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:15:19 --> Upload Class Initialized
INFO - 2026-05-06 04:15:19 --> Form Validation Class Initialized
INFO - 2026-05-06 04:15:19 --> Model "M_product" initialized
INFO - 2026-05-06 04:15:19 --> Model "M_settings" initialized
INFO - 2026-05-06 04:15:19 --> Controller Class Initialized
INFO - 2026-05-06 04:15:19 --> User Agent Class Initialized
INFO - 2026-05-06 04:15:19 --> Database Forge Class Initialized
INFO - 2026-05-06 04:15:19 --> Final output sent to browser
DEBUG - 2026-05-06 04:15:19 --> Total execution time: 0.0862
INFO - 2026-05-06 04:15:19 --> Config Class Initialized
INFO - 2026-05-06 04:15:19 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:15:19 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:15:19 --> Utf8 Class Initialized
INFO - 2026-05-06 04:15:19 --> URI Class Initialized
INFO - 2026-05-06 04:15:19 --> Router Class Initialized
INFO - 2026-05-06 04:15:19 --> Output Class Initialized
INFO - 2026-05-06 04:15:19 --> Security Class Initialized
DEBUG - 2026-05-06 04:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:15:19 --> Input Class Initialized
INFO - 2026-05-06 04:15:19 --> Language Class Initialized
INFO - 2026-05-06 04:15:19 --> Loader Class Initialized
INFO - 2026-05-06 04:15:19 --> Helper loaded: url_helper
INFO - 2026-05-06 04:15:19 --> Helper loaded: file_helper
INFO - 2026-05-06 04:15:19 --> Helper loaded: form_helper
INFO - 2026-05-06 04:15:19 --> Helper loaded: security_helper
INFO - 2026-05-06 04:15:19 --> Database Driver Class Initialized
INFO - 2026-05-06 04:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:15:19 --> Upload Class Initialized
INFO - 2026-05-06 04:15:19 --> Form Validation Class Initialized
INFO - 2026-05-06 04:15:19 --> Model "M_product" initialized
INFO - 2026-05-06 04:15:19 --> Model "M_settings" initialized
INFO - 2026-05-06 04:15:19 --> Controller Class Initialized
INFO - 2026-05-06 04:15:19 --> User Agent Class Initialized
INFO - 2026-05-06 04:15:19 --> Database Forge Class Initialized
INFO - 2026-05-06 04:15:19 --> Final output sent to browser
DEBUG - 2026-05-06 04:15:19 --> Total execution time: 0.1062
INFO - 2026-05-06 04:16:00 --> Config Class Initialized
INFO - 2026-05-06 04:16:00 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:16:00 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:16:00 --> Utf8 Class Initialized
INFO - 2026-05-06 04:16:00 --> URI Class Initialized
DEBUG - 2026-05-06 04:16:00 --> No URI present. Default controller set.
INFO - 2026-05-06 04:16:00 --> Router Class Initialized
INFO - 2026-05-06 04:16:00 --> Output Class Initialized
INFO - 2026-05-06 04:16:00 --> Security Class Initialized
DEBUG - 2026-05-06 04:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:16:00 --> Input Class Initialized
INFO - 2026-05-06 04:16:00 --> Language Class Initialized
INFO - 2026-05-06 04:16:00 --> Loader Class Initialized
INFO - 2026-05-06 04:16:00 --> Helper loaded: url_helper
INFO - 2026-05-06 04:16:00 --> Helper loaded: file_helper
INFO - 2026-05-06 04:16:00 --> Helper loaded: form_helper
INFO - 2026-05-06 04:16:00 --> Helper loaded: security_helper
INFO - 2026-05-06 04:16:00 --> Database Driver Class Initialized
INFO - 2026-05-06 04:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:16:00 --> Upload Class Initialized
INFO - 2026-05-06 04:16:00 --> Form Validation Class Initialized
INFO - 2026-05-06 04:16:00 --> Model "M_product" initialized
INFO - 2026-05-06 04:16:00 --> Model "M_settings" initialized
INFO - 2026-05-06 04:16:00 --> Controller Class Initialized
INFO - 2026-05-06 04:16:00 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 04:16:00 --> Final output sent to browser
DEBUG - 2026-05-06 04:16:00 --> Total execution time: 0.0875
INFO - 2026-05-06 04:17:17 --> Config Class Initialized
INFO - 2026-05-06 04:17:17 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:17:17 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:17:17 --> Utf8 Class Initialized
INFO - 2026-05-06 04:17:17 --> URI Class Initialized
INFO - 2026-05-06 04:17:17 --> Router Class Initialized
INFO - 2026-05-06 04:17:17 --> Output Class Initialized
INFO - 2026-05-06 04:17:17 --> Security Class Initialized
DEBUG - 2026-05-06 04:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:17:17 --> Input Class Initialized
INFO - 2026-05-06 04:17:17 --> Language Class Initialized
INFO - 2026-05-06 04:17:17 --> Loader Class Initialized
INFO - 2026-05-06 04:17:17 --> Helper loaded: url_helper
INFO - 2026-05-06 04:17:17 --> Helper loaded: file_helper
INFO - 2026-05-06 04:17:17 --> Helper loaded: form_helper
INFO - 2026-05-06 04:17:17 --> Helper loaded: security_helper
INFO - 2026-05-06 04:17:17 --> Database Driver Class Initialized
INFO - 2026-05-06 04:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:17:17 --> Upload Class Initialized
INFO - 2026-05-06 04:17:17 --> Form Validation Class Initialized
INFO - 2026-05-06 04:17:17 --> Model "M_product" initialized
INFO - 2026-05-06 04:17:17 --> Model "M_settings" initialized
INFO - 2026-05-06 04:17:17 --> Controller Class Initialized
INFO - 2026-05-06 04:17:17 --> User Agent Class Initialized
INFO - 2026-05-06 04:17:17 --> Database Forge Class Initialized
INFO - 2026-05-06 04:17:17 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:17:17 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:17:17 --> Final output sent to browser
DEBUG - 2026-05-06 04:17:17 --> Total execution time: 0.0964
INFO - 2026-05-06 04:17:21 --> Config Class Initialized
INFO - 2026-05-06 04:17:21 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:17:21 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:17:21 --> Utf8 Class Initialized
INFO - 2026-05-06 04:17:21 --> URI Class Initialized
INFO - 2026-05-06 04:17:21 --> Router Class Initialized
INFO - 2026-05-06 04:17:21 --> Output Class Initialized
INFO - 2026-05-06 04:17:21 --> Security Class Initialized
DEBUG - 2026-05-06 04:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:17:21 --> Input Class Initialized
INFO - 2026-05-06 04:17:21 --> Language Class Initialized
INFO - 2026-05-06 04:17:21 --> Loader Class Initialized
INFO - 2026-05-06 04:17:21 --> Helper loaded: url_helper
INFO - 2026-05-06 04:17:21 --> Helper loaded: file_helper
INFO - 2026-05-06 04:17:21 --> Helper loaded: form_helper
INFO - 2026-05-06 04:17:21 --> Helper loaded: security_helper
INFO - 2026-05-06 04:17:21 --> Database Driver Class Initialized
INFO - 2026-05-06 04:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:17:21 --> Upload Class Initialized
INFO - 2026-05-06 04:17:21 --> Form Validation Class Initialized
INFO - 2026-05-06 04:17:21 --> Model "M_product" initialized
INFO - 2026-05-06 04:17:21 --> Model "M_settings" initialized
INFO - 2026-05-06 04:17:21 --> Controller Class Initialized
INFO - 2026-05-06 04:17:21 --> User Agent Class Initialized
INFO - 2026-05-06 04:17:21 --> Database Forge Class Initialized
INFO - 2026-05-06 04:17:21 --> Final output sent to browser
DEBUG - 2026-05-06 04:17:21 --> Total execution time: 0.0833
INFO - 2026-05-06 04:17:23 --> Config Class Initialized
INFO - 2026-05-06 04:17:23 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:17:23 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:17:23 --> Utf8 Class Initialized
INFO - 2026-05-06 04:17:23 --> URI Class Initialized
INFO - 2026-05-06 04:17:23 --> Router Class Initialized
INFO - 2026-05-06 04:17:23 --> Output Class Initialized
INFO - 2026-05-06 04:17:23 --> Security Class Initialized
DEBUG - 2026-05-06 04:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:17:23 --> Input Class Initialized
INFO - 2026-05-06 04:17:23 --> Language Class Initialized
INFO - 2026-05-06 04:17:23 --> Loader Class Initialized
INFO - 2026-05-06 04:17:23 --> Helper loaded: url_helper
INFO - 2026-05-06 04:17:23 --> Helper loaded: file_helper
INFO - 2026-05-06 04:17:23 --> Helper loaded: form_helper
INFO - 2026-05-06 04:17:23 --> Helper loaded: security_helper
INFO - 2026-05-06 04:17:23 --> Database Driver Class Initialized
INFO - 2026-05-06 04:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:17:23 --> Upload Class Initialized
INFO - 2026-05-06 04:17:23 --> Form Validation Class Initialized
INFO - 2026-05-06 04:17:23 --> Model "M_product" initialized
INFO - 2026-05-06 04:17:23 --> Model "M_settings" initialized
INFO - 2026-05-06 04:17:23 --> Controller Class Initialized
INFO - 2026-05-06 04:17:23 --> User Agent Class Initialized
INFO - 2026-05-06 04:17:23 --> Database Forge Class Initialized
INFO - 2026-05-06 04:17:23 --> Final output sent to browser
DEBUG - 2026-05-06 04:17:23 --> Total execution time: 0.0821
INFO - 2026-05-06 04:17:23 --> Config Class Initialized
INFO - 2026-05-06 04:17:23 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:17:23 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:17:23 --> Utf8 Class Initialized
INFO - 2026-05-06 04:17:23 --> URI Class Initialized
INFO - 2026-05-06 04:17:23 --> Router Class Initialized
INFO - 2026-05-06 04:17:23 --> Output Class Initialized
INFO - 2026-05-06 04:17:23 --> Security Class Initialized
DEBUG - 2026-05-06 04:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:17:23 --> Input Class Initialized
INFO - 2026-05-06 04:17:23 --> Language Class Initialized
INFO - 2026-05-06 04:17:23 --> Loader Class Initialized
INFO - 2026-05-06 04:17:23 --> Helper loaded: url_helper
INFO - 2026-05-06 04:17:23 --> Helper loaded: file_helper
INFO - 2026-05-06 04:17:23 --> Helper loaded: form_helper
INFO - 2026-05-06 04:17:23 --> Helper loaded: security_helper
INFO - 2026-05-06 04:17:23 --> Database Driver Class Initialized
INFO - 2026-05-06 04:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:17:23 --> Upload Class Initialized
INFO - 2026-05-06 04:17:23 --> Form Validation Class Initialized
INFO - 2026-05-06 04:17:23 --> Model "M_product" initialized
INFO - 2026-05-06 04:17:23 --> Model "M_settings" initialized
INFO - 2026-05-06 04:17:23 --> Controller Class Initialized
INFO - 2026-05-06 04:17:23 --> User Agent Class Initialized
INFO - 2026-05-06 04:17:23 --> Database Forge Class Initialized
INFO - 2026-05-06 04:17:23 --> Final output sent to browser
DEBUG - 2026-05-06 04:17:23 --> Total execution time: 0.0803
INFO - 2026-05-06 04:17:24 --> Config Class Initialized
INFO - 2026-05-06 04:17:24 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:17:24 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:17:24 --> Utf8 Class Initialized
INFO - 2026-05-06 04:17:24 --> URI Class Initialized
INFO - 2026-05-06 04:17:24 --> Router Class Initialized
INFO - 2026-05-06 04:17:24 --> Output Class Initialized
INFO - 2026-05-06 04:17:24 --> Security Class Initialized
DEBUG - 2026-05-06 04:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:17:24 --> Input Class Initialized
INFO - 2026-05-06 04:17:24 --> Language Class Initialized
INFO - 2026-05-06 04:17:24 --> Loader Class Initialized
INFO - 2026-05-06 04:17:24 --> Helper loaded: url_helper
INFO - 2026-05-06 04:17:24 --> Helper loaded: file_helper
INFO - 2026-05-06 04:17:24 --> Helper loaded: form_helper
INFO - 2026-05-06 04:17:24 --> Helper loaded: security_helper
INFO - 2026-05-06 04:17:24 --> Database Driver Class Initialized
INFO - 2026-05-06 04:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:17:24 --> Upload Class Initialized
INFO - 2026-05-06 04:17:24 --> Form Validation Class Initialized
INFO - 2026-05-06 04:17:24 --> Model "M_product" initialized
INFO - 2026-05-06 04:17:24 --> Model "M_settings" initialized
INFO - 2026-05-06 04:17:24 --> Controller Class Initialized
INFO - 2026-05-06 04:17:24 --> User Agent Class Initialized
INFO - 2026-05-06 04:17:24 --> Database Forge Class Initialized
INFO - 2026-05-06 04:17:24 --> Final output sent to browser
DEBUG - 2026-05-06 04:17:24 --> Total execution time: 0.0848
INFO - 2026-05-06 04:19:31 --> Config Class Initialized
INFO - 2026-05-06 04:19:31 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:19:31 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:19:31 --> Utf8 Class Initialized
INFO - 2026-05-06 04:19:31 --> URI Class Initialized
INFO - 2026-05-06 04:19:31 --> Router Class Initialized
INFO - 2026-05-06 04:19:31 --> Output Class Initialized
INFO - 2026-05-06 04:19:31 --> Security Class Initialized
DEBUG - 2026-05-06 04:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:19:31 --> Input Class Initialized
INFO - 2026-05-06 04:19:31 --> Language Class Initialized
INFO - 2026-05-06 04:19:31 --> Loader Class Initialized
INFO - 2026-05-06 04:19:31 --> Helper loaded: url_helper
INFO - 2026-05-06 04:19:31 --> Helper loaded: file_helper
INFO - 2026-05-06 04:19:31 --> Helper loaded: form_helper
INFO - 2026-05-06 04:19:31 --> Helper loaded: security_helper
INFO - 2026-05-06 04:19:31 --> Database Driver Class Initialized
INFO - 2026-05-06 04:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:19:31 --> Upload Class Initialized
INFO - 2026-05-06 04:19:31 --> Form Validation Class Initialized
INFO - 2026-05-06 04:19:31 --> Model "M_product" initialized
INFO - 2026-05-06 04:19:31 --> Model "M_settings" initialized
INFO - 2026-05-06 04:19:31 --> Controller Class Initialized
INFO - 2026-05-06 04:19:31 --> User Agent Class Initialized
INFO - 2026-05-06 04:19:31 --> Database Forge Class Initialized
INFO - 2026-05-06 04:19:31 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:19:31 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:19:31 --> Final output sent to browser
DEBUG - 2026-05-06 04:19:31 --> Total execution time: 0.0869
INFO - 2026-05-06 04:19:36 --> Config Class Initialized
INFO - 2026-05-06 04:19:36 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:19:36 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:19:36 --> Utf8 Class Initialized
INFO - 2026-05-06 04:19:36 --> URI Class Initialized
INFO - 2026-05-06 04:19:36 --> Router Class Initialized
INFO - 2026-05-06 04:19:36 --> Output Class Initialized
INFO - 2026-05-06 04:19:36 --> Security Class Initialized
DEBUG - 2026-05-06 04:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:19:36 --> Input Class Initialized
INFO - 2026-05-06 04:19:36 --> Language Class Initialized
INFO - 2026-05-06 04:19:36 --> Loader Class Initialized
INFO - 2026-05-06 04:19:36 --> Helper loaded: url_helper
INFO - 2026-05-06 04:19:36 --> Helper loaded: file_helper
INFO - 2026-05-06 04:19:36 --> Helper loaded: form_helper
INFO - 2026-05-06 04:19:36 --> Helper loaded: security_helper
INFO - 2026-05-06 04:19:36 --> Database Driver Class Initialized
INFO - 2026-05-06 04:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:19:36 --> Upload Class Initialized
INFO - 2026-05-06 04:19:36 --> Form Validation Class Initialized
INFO - 2026-05-06 04:19:36 --> Model "M_product" initialized
INFO - 2026-05-06 04:19:36 --> Model "M_settings" initialized
INFO - 2026-05-06 04:19:36 --> Controller Class Initialized
INFO - 2026-05-06 04:19:36 --> User Agent Class Initialized
INFO - 2026-05-06 04:19:36 --> Database Forge Class Initialized
INFO - 2026-05-06 04:19:36 --> Final output sent to browser
DEBUG - 2026-05-06 04:19:36 --> Total execution time: 0.1001
INFO - 2026-05-06 04:19:37 --> Config Class Initialized
INFO - 2026-05-06 04:19:37 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:19:37 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:19:37 --> Utf8 Class Initialized
INFO - 2026-05-06 04:19:37 --> URI Class Initialized
INFO - 2026-05-06 04:19:37 --> Router Class Initialized
INFO - 2026-05-06 04:19:37 --> Output Class Initialized
INFO - 2026-05-06 04:19:37 --> Security Class Initialized
DEBUG - 2026-05-06 04:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:19:37 --> Input Class Initialized
INFO - 2026-05-06 04:19:37 --> Language Class Initialized
INFO - 2026-05-06 04:19:37 --> Loader Class Initialized
INFO - 2026-05-06 04:19:37 --> Helper loaded: url_helper
INFO - 2026-05-06 04:19:37 --> Helper loaded: file_helper
INFO - 2026-05-06 04:19:37 --> Helper loaded: form_helper
INFO - 2026-05-06 04:19:37 --> Helper loaded: security_helper
INFO - 2026-05-06 04:19:37 --> Database Driver Class Initialized
INFO - 2026-05-06 04:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:19:37 --> Upload Class Initialized
INFO - 2026-05-06 04:19:37 --> Form Validation Class Initialized
INFO - 2026-05-06 04:19:37 --> Model "M_product" initialized
INFO - 2026-05-06 04:19:37 --> Model "M_settings" initialized
INFO - 2026-05-06 04:19:37 --> Controller Class Initialized
INFO - 2026-05-06 04:19:37 --> User Agent Class Initialized
INFO - 2026-05-06 04:19:37 --> Database Forge Class Initialized
INFO - 2026-05-06 04:19:37 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:19:37 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:19:37 --> Final output sent to browser
DEBUG - 2026-05-06 04:19:37 --> Total execution time: 0.0953
INFO - 2026-05-06 04:19:40 --> Config Class Initialized
INFO - 2026-05-06 04:19:40 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:19:40 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:19:40 --> Utf8 Class Initialized
INFO - 2026-05-06 04:19:40 --> URI Class Initialized
INFO - 2026-05-06 04:19:40 --> Router Class Initialized
INFO - 2026-05-06 04:19:40 --> Output Class Initialized
INFO - 2026-05-06 04:19:40 --> Security Class Initialized
DEBUG - 2026-05-06 04:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:19:40 --> Input Class Initialized
INFO - 2026-05-06 04:19:40 --> Language Class Initialized
INFO - 2026-05-06 04:19:40 --> Loader Class Initialized
INFO - 2026-05-06 04:19:40 --> Helper loaded: url_helper
INFO - 2026-05-06 04:19:40 --> Helper loaded: file_helper
INFO - 2026-05-06 04:19:40 --> Helper loaded: form_helper
INFO - 2026-05-06 04:19:40 --> Helper loaded: security_helper
INFO - 2026-05-06 04:19:40 --> Database Driver Class Initialized
INFO - 2026-05-06 04:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:19:40 --> Upload Class Initialized
INFO - 2026-05-06 04:19:40 --> Form Validation Class Initialized
INFO - 2026-05-06 04:19:40 --> Model "M_product" initialized
INFO - 2026-05-06 04:19:40 --> Model "M_settings" initialized
INFO - 2026-05-06 04:19:40 --> Controller Class Initialized
INFO - 2026-05-06 04:19:40 --> User Agent Class Initialized
INFO - 2026-05-06 04:19:40 --> Database Forge Class Initialized
INFO - 2026-05-06 04:19:40 --> Final output sent to browser
DEBUG - 2026-05-06 04:19:40 --> Total execution time: 0.0831
INFO - 2026-05-06 04:20:00 --> Config Class Initialized
INFO - 2026-05-06 04:20:00 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:20:00 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:20:00 --> Utf8 Class Initialized
INFO - 2026-05-06 04:20:00 --> URI Class Initialized
INFO - 2026-05-06 04:20:00 --> Router Class Initialized
INFO - 2026-05-06 04:20:00 --> Output Class Initialized
INFO - 2026-05-06 04:20:00 --> Security Class Initialized
DEBUG - 2026-05-06 04:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:20:00 --> Input Class Initialized
INFO - 2026-05-06 04:20:00 --> Language Class Initialized
ERROR - 2026-05-06 04:20:00 --> 404 Page Not Found: Auth/login
INFO - 2026-05-06 04:20:28 --> Config Class Initialized
INFO - 2026-05-06 04:20:28 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:20:28 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:20:28 --> Utf8 Class Initialized
INFO - 2026-05-06 04:20:28 --> URI Class Initialized
INFO - 2026-05-06 04:20:28 --> Router Class Initialized
INFO - 2026-05-06 04:20:28 --> Output Class Initialized
INFO - 2026-05-06 04:20:28 --> Security Class Initialized
DEBUG - 2026-05-06 04:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:20:28 --> Input Class Initialized
INFO - 2026-05-06 04:20:28 --> Language Class Initialized
INFO - 2026-05-06 04:20:28 --> Loader Class Initialized
INFO - 2026-05-06 04:20:28 --> Helper loaded: url_helper
INFO - 2026-05-06 04:20:28 --> Helper loaded: file_helper
INFO - 2026-05-06 04:20:28 --> Helper loaded: form_helper
INFO - 2026-05-06 04:20:28 --> Helper loaded: security_helper
INFO - 2026-05-06 04:20:28 --> Database Driver Class Initialized
INFO - 2026-05-06 04:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:20:28 --> Upload Class Initialized
INFO - 2026-05-06 04:20:28 --> Form Validation Class Initialized
INFO - 2026-05-06 04:20:28 --> Model "M_product" initialized
INFO - 2026-05-06 04:20:28 --> Model "M_settings" initialized
INFO - 2026-05-06 04:20:28 --> Controller Class Initialized
INFO - 2026-05-06 04:20:28 --> User Agent Class Initialized
INFO - 2026-05-06 04:20:28 --> Database Forge Class Initialized
INFO - 2026-05-06 04:20:28 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:20:28 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:20:28 --> Final output sent to browser
DEBUG - 2026-05-06 04:20:28 --> Total execution time: 0.1104
INFO - 2026-05-06 04:20:28 --> Config Class Initialized
INFO - 2026-05-06 04:20:28 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:20:28 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:20:28 --> Utf8 Class Initialized
INFO - 2026-05-06 04:20:28 --> URI Class Initialized
DEBUG - 2026-05-06 04:20:28 --> No URI present. Default controller set.
INFO - 2026-05-06 04:20:28 --> Router Class Initialized
INFO - 2026-05-06 04:20:28 --> Output Class Initialized
INFO - 2026-05-06 04:20:28 --> Security Class Initialized
DEBUG - 2026-05-06 04:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:20:28 --> Input Class Initialized
INFO - 2026-05-06 04:20:28 --> Language Class Initialized
INFO - 2026-05-06 04:20:28 --> Loader Class Initialized
INFO - 2026-05-06 04:20:29 --> Helper loaded: url_helper
INFO - 2026-05-06 04:20:29 --> Helper loaded: file_helper
INFO - 2026-05-06 04:20:29 --> Helper loaded: form_helper
INFO - 2026-05-06 04:20:29 --> Helper loaded: security_helper
INFO - 2026-05-06 04:20:29 --> Database Driver Class Initialized
INFO - 2026-05-06 04:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:20:29 --> Upload Class Initialized
INFO - 2026-05-06 04:20:29 --> Form Validation Class Initialized
INFO - 2026-05-06 04:20:29 --> Model "M_product" initialized
INFO - 2026-05-06 04:20:29 --> Model "M_settings" initialized
INFO - 2026-05-06 04:20:29 --> Controller Class Initialized
INFO - 2026-05-06 04:20:29 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 04:20:29 --> Final output sent to browser
DEBUG - 2026-05-06 04:20:29 --> Total execution time: 0.1022
INFO - 2026-05-06 04:20:35 --> Config Class Initialized
INFO - 2026-05-06 04:20:35 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:20:35 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:20:35 --> Utf8 Class Initialized
INFO - 2026-05-06 04:20:35 --> URI Class Initialized
INFO - 2026-05-06 04:20:35 --> Router Class Initialized
INFO - 2026-05-06 04:20:35 --> Output Class Initialized
INFO - 2026-05-06 04:20:35 --> Security Class Initialized
DEBUG - 2026-05-06 04:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:20:35 --> Input Class Initialized
INFO - 2026-05-06 04:20:35 --> Language Class Initialized
INFO - 2026-05-06 04:20:35 --> Loader Class Initialized
INFO - 2026-05-06 04:20:35 --> Helper loaded: url_helper
INFO - 2026-05-06 04:20:35 --> Helper loaded: file_helper
INFO - 2026-05-06 04:20:35 --> Helper loaded: form_helper
INFO - 2026-05-06 04:20:35 --> Helper loaded: security_helper
INFO - 2026-05-06 04:20:35 --> Database Driver Class Initialized
INFO - 2026-05-06 04:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:20:35 --> Upload Class Initialized
INFO - 2026-05-06 04:20:35 --> Form Validation Class Initialized
INFO - 2026-05-06 04:20:35 --> Model "M_product" initialized
INFO - 2026-05-06 04:20:35 --> Model "M_settings" initialized
INFO - 2026-05-06 04:20:35 --> Controller Class Initialized
INFO - 2026-05-06 04:20:35 --> Model "M_sales" initialized
INFO - 2026-05-06 04:20:35 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:20:35 --> File loaded: C:\laragon\www\macha\application\views\user/order_history.php
INFO - 2026-05-06 04:20:35 --> Final output sent to browser
DEBUG - 2026-05-06 04:20:35 --> Total execution time: 0.0927
INFO - 2026-05-06 04:20:40 --> Config Class Initialized
INFO - 2026-05-06 04:20:40 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:20:40 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:20:40 --> Utf8 Class Initialized
INFO - 2026-05-06 04:20:40 --> URI Class Initialized
INFO - 2026-05-06 04:20:40 --> Router Class Initialized
INFO - 2026-05-06 04:20:40 --> Output Class Initialized
INFO - 2026-05-06 04:20:40 --> Security Class Initialized
DEBUG - 2026-05-06 04:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:20:40 --> Input Class Initialized
INFO - 2026-05-06 04:20:40 --> Language Class Initialized
ERROR - 2026-05-06 04:20:40 --> 404 Page Not Found: Auth/login
INFO - 2026-05-06 04:21:12 --> Config Class Initialized
INFO - 2026-05-06 04:21:12 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:21:12 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:21:12 --> Utf8 Class Initialized
INFO - 2026-05-06 04:21:12 --> URI Class Initialized
INFO - 2026-05-06 04:21:12 --> Router Class Initialized
INFO - 2026-05-06 04:21:12 --> Output Class Initialized
INFO - 2026-05-06 04:21:12 --> Security Class Initialized
DEBUG - 2026-05-06 04:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:21:12 --> Input Class Initialized
INFO - 2026-05-06 04:21:12 --> Language Class Initialized
INFO - 2026-05-06 04:21:12 --> Loader Class Initialized
INFO - 2026-05-06 04:21:12 --> Helper loaded: url_helper
INFO - 2026-05-06 04:21:12 --> Helper loaded: file_helper
INFO - 2026-05-06 04:21:12 --> Helper loaded: form_helper
INFO - 2026-05-06 04:21:12 --> Helper loaded: security_helper
INFO - 2026-05-06 04:21:12 --> Database Driver Class Initialized
INFO - 2026-05-06 04:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:21:12 --> Upload Class Initialized
INFO - 2026-05-06 04:21:12 --> Form Validation Class Initialized
INFO - 2026-05-06 04:21:12 --> Model "M_product" initialized
INFO - 2026-05-06 04:21:12 --> Model "M_settings" initialized
INFO - 2026-05-06 04:21:12 --> Controller Class Initialized
INFO - 2026-05-06 04:21:12 --> User Agent Class Initialized
INFO - 2026-05-06 04:21:12 --> Database Forge Class Initialized
INFO - 2026-05-06 04:21:12 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:21:12 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:21:12 --> Final output sent to browser
DEBUG - 2026-05-06 04:21:12 --> Total execution time: 0.0824
INFO - 2026-05-06 04:24:38 --> Config Class Initialized
INFO - 2026-05-06 04:24:38 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:24:38 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:24:38 --> Utf8 Class Initialized
INFO - 2026-05-06 04:24:38 --> URI Class Initialized
INFO - 2026-05-06 04:24:38 --> Router Class Initialized
INFO - 2026-05-06 04:24:38 --> Output Class Initialized
INFO - 2026-05-06 04:24:38 --> Security Class Initialized
DEBUG - 2026-05-06 04:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:24:38 --> Input Class Initialized
INFO - 2026-05-06 04:24:38 --> Language Class Initialized
INFO - 2026-05-06 04:24:38 --> Loader Class Initialized
INFO - 2026-05-06 04:24:38 --> Helper loaded: url_helper
INFO - 2026-05-06 04:24:38 --> Helper loaded: file_helper
INFO - 2026-05-06 04:24:38 --> Helper loaded: form_helper
INFO - 2026-05-06 04:24:38 --> Helper loaded: security_helper
INFO - 2026-05-06 04:24:38 --> Database Driver Class Initialized
INFO - 2026-05-06 04:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:24:38 --> Upload Class Initialized
INFO - 2026-05-06 04:24:38 --> Form Validation Class Initialized
INFO - 2026-05-06 04:24:38 --> Model "M_product" initialized
INFO - 2026-05-06 04:24:38 --> Model "M_settings" initialized
INFO - 2026-05-06 04:24:38 --> Controller Class Initialized
INFO - 2026-05-06 04:24:38 --> User Agent Class Initialized
INFO - 2026-05-06 04:24:38 --> Database Forge Class Initialized
INFO - 2026-05-06 04:24:38 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:24:38 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:24:38 --> Final output sent to browser
DEBUG - 2026-05-06 04:24:38 --> Total execution time: 0.1171
INFO - 2026-05-06 04:24:48 --> Config Class Initialized
INFO - 2026-05-06 04:24:48 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:24:48 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:24:48 --> Utf8 Class Initialized
INFO - 2026-05-06 04:24:48 --> URI Class Initialized
INFO - 2026-05-06 04:24:48 --> Router Class Initialized
INFO - 2026-05-06 04:24:48 --> Output Class Initialized
INFO - 2026-05-06 04:24:48 --> Security Class Initialized
DEBUG - 2026-05-06 04:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:24:48 --> Input Class Initialized
INFO - 2026-05-06 04:24:48 --> Language Class Initialized
INFO - 2026-05-06 04:24:48 --> Loader Class Initialized
INFO - 2026-05-06 04:24:48 --> Helper loaded: url_helper
INFO - 2026-05-06 04:24:48 --> Helper loaded: file_helper
INFO - 2026-05-06 04:24:48 --> Helper loaded: form_helper
INFO - 2026-05-06 04:24:48 --> Helper loaded: security_helper
INFO - 2026-05-06 04:24:48 --> Database Driver Class Initialized
INFO - 2026-05-06 04:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:24:48 --> Upload Class Initialized
INFO - 2026-05-06 04:24:48 --> Form Validation Class Initialized
INFO - 2026-05-06 04:24:48 --> Model "M_product" initialized
INFO - 2026-05-06 04:24:48 --> Model "M_settings" initialized
INFO - 2026-05-06 04:24:48 --> Controller Class Initialized
INFO - 2026-05-06 04:24:48 --> Model "M_sales" initialized
INFO - 2026-05-06 04:24:48 --> File loaded: C:\laragon\www\macha\application\views\user/profile.php
INFO - 2026-05-06 04:24:48 --> Final output sent to browser
DEBUG - 2026-05-06 04:24:48 --> Total execution time: 0.1247
INFO - 2026-05-06 04:24:51 --> Config Class Initialized
INFO - 2026-05-06 04:24:51 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:24:51 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:24:51 --> Utf8 Class Initialized
INFO - 2026-05-06 04:24:51 --> URI Class Initialized
DEBUG - 2026-05-06 04:24:51 --> No URI present. Default controller set.
INFO - 2026-05-06 04:24:51 --> Router Class Initialized
INFO - 2026-05-06 04:24:51 --> Output Class Initialized
INFO - 2026-05-06 04:24:51 --> Security Class Initialized
DEBUG - 2026-05-06 04:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:24:51 --> Input Class Initialized
INFO - 2026-05-06 04:24:51 --> Language Class Initialized
INFO - 2026-05-06 04:24:51 --> Loader Class Initialized
INFO - 2026-05-06 04:24:51 --> Helper loaded: url_helper
INFO - 2026-05-06 04:24:51 --> Helper loaded: file_helper
INFO - 2026-05-06 04:24:51 --> Helper loaded: form_helper
INFO - 2026-05-06 04:24:51 --> Helper loaded: security_helper
INFO - 2026-05-06 04:24:51 --> Database Driver Class Initialized
INFO - 2026-05-06 04:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:24:51 --> Upload Class Initialized
INFO - 2026-05-06 04:24:51 --> Form Validation Class Initialized
INFO - 2026-05-06 04:24:51 --> Model "M_product" initialized
INFO - 2026-05-06 04:24:51 --> Model "M_settings" initialized
INFO - 2026-05-06 04:24:51 --> Controller Class Initialized
INFO - 2026-05-06 04:24:51 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 04:24:51 --> Final output sent to browser
DEBUG - 2026-05-06 04:24:51 --> Total execution time: 0.0785
INFO - 2026-05-06 04:25:42 --> Config Class Initialized
INFO - 2026-05-06 04:25:42 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:25:42 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:25:42 --> Utf8 Class Initialized
INFO - 2026-05-06 04:25:42 --> URI Class Initialized
INFO - 2026-05-06 04:25:42 --> Router Class Initialized
INFO - 2026-05-06 04:25:42 --> Output Class Initialized
INFO - 2026-05-06 04:25:42 --> Security Class Initialized
DEBUG - 2026-05-06 04:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:25:42 --> Input Class Initialized
INFO - 2026-05-06 04:25:42 --> Language Class Initialized
INFO - 2026-05-06 04:25:42 --> Loader Class Initialized
INFO - 2026-05-06 04:25:42 --> Helper loaded: url_helper
INFO - 2026-05-06 04:25:42 --> Helper loaded: file_helper
INFO - 2026-05-06 04:25:42 --> Helper loaded: form_helper
INFO - 2026-05-06 04:25:42 --> Helper loaded: security_helper
INFO - 2026-05-06 04:25:42 --> Database Driver Class Initialized
INFO - 2026-05-06 04:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:25:42 --> Upload Class Initialized
INFO - 2026-05-06 04:25:42 --> Form Validation Class Initialized
INFO - 2026-05-06 04:25:42 --> Model "M_product" initialized
INFO - 2026-05-06 04:25:42 --> Model "M_settings" initialized
INFO - 2026-05-06 04:25:42 --> Controller Class Initialized
INFO - 2026-05-06 04:25:42 --> User Agent Class Initialized
INFO - 2026-05-06 04:25:42 --> Database Forge Class Initialized
INFO - 2026-05-06 04:25:42 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:25:42 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:25:42 --> Final output sent to browser
DEBUG - 2026-05-06 04:25:42 --> Total execution time: 0.0938
INFO - 2026-05-06 04:25:53 --> Config Class Initialized
INFO - 2026-05-06 04:25:53 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:25:53 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:25:53 --> Utf8 Class Initialized
INFO - 2026-05-06 04:25:53 --> URI Class Initialized
INFO - 2026-05-06 04:25:53 --> Router Class Initialized
INFO - 2026-05-06 04:25:53 --> Output Class Initialized
INFO - 2026-05-06 04:25:53 --> Security Class Initialized
DEBUG - 2026-05-06 04:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:25:53 --> Input Class Initialized
INFO - 2026-05-06 04:25:53 --> Language Class Initialized
INFO - 2026-05-06 04:25:53 --> Loader Class Initialized
INFO - 2026-05-06 04:25:53 --> Helper loaded: url_helper
INFO - 2026-05-06 04:25:53 --> Helper loaded: file_helper
INFO - 2026-05-06 04:25:53 --> Helper loaded: form_helper
INFO - 2026-05-06 04:25:53 --> Helper loaded: security_helper
INFO - 2026-05-06 04:25:53 --> Database Driver Class Initialized
INFO - 2026-05-06 04:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:25:53 --> Upload Class Initialized
INFO - 2026-05-06 04:25:53 --> Form Validation Class Initialized
INFO - 2026-05-06 04:25:53 --> Model "M_product" initialized
INFO - 2026-05-06 04:25:53 --> Model "M_settings" initialized
INFO - 2026-05-06 04:25:53 --> Controller Class Initialized
INFO - 2026-05-06 04:25:53 --> User Agent Class Initialized
INFO - 2026-05-06 04:25:53 --> Database Forge Class Initialized
INFO - 2026-05-06 04:25:53 --> Final output sent to browser
DEBUG - 2026-05-06 04:25:53 --> Total execution time: 0.0815
INFO - 2026-05-06 04:25:53 --> Config Class Initialized
INFO - 2026-05-06 04:25:53 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:25:53 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:25:53 --> Utf8 Class Initialized
INFO - 2026-05-06 04:25:53 --> URI Class Initialized
INFO - 2026-05-06 04:25:53 --> Router Class Initialized
INFO - 2026-05-06 04:25:53 --> Output Class Initialized
INFO - 2026-05-06 04:25:53 --> Security Class Initialized
DEBUG - 2026-05-06 04:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:25:53 --> Input Class Initialized
INFO - 2026-05-06 04:25:53 --> Language Class Initialized
INFO - 2026-05-06 04:25:53 --> Loader Class Initialized
INFO - 2026-05-06 04:25:53 --> Helper loaded: url_helper
INFO - 2026-05-06 04:25:53 --> Helper loaded: file_helper
INFO - 2026-05-06 04:25:53 --> Helper loaded: form_helper
INFO - 2026-05-06 04:25:53 --> Helper loaded: security_helper
INFO - 2026-05-06 04:25:53 --> Database Driver Class Initialized
INFO - 2026-05-06 04:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:25:53 --> Upload Class Initialized
INFO - 2026-05-06 04:25:53 --> Form Validation Class Initialized
INFO - 2026-05-06 04:25:53 --> Model "M_product" initialized
INFO - 2026-05-06 04:25:53 --> Model "M_settings" initialized
INFO - 2026-05-06 04:25:53 --> Controller Class Initialized
INFO - 2026-05-06 04:25:53 --> User Agent Class Initialized
INFO - 2026-05-06 04:25:53 --> Database Forge Class Initialized
INFO - 2026-05-06 04:25:53 --> Final output sent to browser
DEBUG - 2026-05-06 04:25:53 --> Total execution time: 0.0948
INFO - 2026-05-06 04:25:55 --> Config Class Initialized
INFO - 2026-05-06 04:25:55 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:25:55 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:25:55 --> Utf8 Class Initialized
INFO - 2026-05-06 04:25:55 --> URI Class Initialized
INFO - 2026-05-06 04:25:55 --> Router Class Initialized
INFO - 2026-05-06 04:25:55 --> Output Class Initialized
INFO - 2026-05-06 04:25:55 --> Security Class Initialized
DEBUG - 2026-05-06 04:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:25:55 --> Input Class Initialized
INFO - 2026-05-06 04:25:55 --> Language Class Initialized
INFO - 2026-05-06 04:25:55 --> Loader Class Initialized
INFO - 2026-05-06 04:25:55 --> Helper loaded: url_helper
INFO - 2026-05-06 04:25:55 --> Helper loaded: file_helper
INFO - 2026-05-06 04:25:55 --> Helper loaded: form_helper
INFO - 2026-05-06 04:25:55 --> Helper loaded: security_helper
INFO - 2026-05-06 04:25:55 --> Database Driver Class Initialized
INFO - 2026-05-06 04:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:25:55 --> Upload Class Initialized
INFO - 2026-05-06 04:25:55 --> Form Validation Class Initialized
INFO - 2026-05-06 04:25:55 --> Model "M_product" initialized
INFO - 2026-05-06 04:25:55 --> Model "M_settings" initialized
INFO - 2026-05-06 04:25:55 --> Controller Class Initialized
INFO - 2026-05-06 04:25:55 --> User Agent Class Initialized
INFO - 2026-05-06 04:25:55 --> Database Forge Class Initialized
INFO - 2026-05-06 04:25:55 --> Final output sent to browser
DEBUG - 2026-05-06 04:25:55 --> Total execution time: 0.0775
INFO - 2026-05-06 04:25:56 --> Config Class Initialized
INFO - 2026-05-06 04:25:56 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:25:56 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:25:56 --> Utf8 Class Initialized
INFO - 2026-05-06 04:25:56 --> URI Class Initialized
INFO - 2026-05-06 04:25:56 --> Router Class Initialized
INFO - 2026-05-06 04:25:56 --> Output Class Initialized
INFO - 2026-05-06 04:25:56 --> Security Class Initialized
DEBUG - 2026-05-06 04:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:25:56 --> Input Class Initialized
INFO - 2026-05-06 04:25:56 --> Language Class Initialized
INFO - 2026-05-06 04:25:56 --> Loader Class Initialized
INFO - 2026-05-06 04:25:56 --> Helper loaded: url_helper
INFO - 2026-05-06 04:25:56 --> Helper loaded: file_helper
INFO - 2026-05-06 04:25:56 --> Helper loaded: form_helper
INFO - 2026-05-06 04:25:56 --> Helper loaded: security_helper
INFO - 2026-05-06 04:25:56 --> Database Driver Class Initialized
INFO - 2026-05-06 04:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:25:56 --> Upload Class Initialized
INFO - 2026-05-06 04:25:56 --> Form Validation Class Initialized
INFO - 2026-05-06 04:25:56 --> Model "M_product" initialized
INFO - 2026-05-06 04:25:56 --> Model "M_settings" initialized
INFO - 2026-05-06 04:25:56 --> Controller Class Initialized
INFO - 2026-05-06 04:25:56 --> User Agent Class Initialized
INFO - 2026-05-06 04:25:56 --> Database Forge Class Initialized
INFO - 2026-05-06 04:25:56 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:25:56 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:25:56 --> Final output sent to browser
DEBUG - 2026-05-06 04:25:56 --> Total execution time: 0.1014
INFO - 2026-05-06 04:31:25 --> Config Class Initialized
INFO - 2026-05-06 04:31:25 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:31:25 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:31:25 --> Utf8 Class Initialized
INFO - 2026-05-06 04:31:25 --> URI Class Initialized
INFO - 2026-05-06 04:31:25 --> Router Class Initialized
INFO - 2026-05-06 04:31:25 --> Output Class Initialized
INFO - 2026-05-06 04:31:25 --> Security Class Initialized
DEBUG - 2026-05-06 04:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:31:25 --> Input Class Initialized
INFO - 2026-05-06 04:31:25 --> Language Class Initialized
INFO - 2026-05-06 04:31:25 --> Loader Class Initialized
INFO - 2026-05-06 04:31:25 --> Helper loaded: url_helper
INFO - 2026-05-06 04:31:25 --> Helper loaded: file_helper
INFO - 2026-05-06 04:31:25 --> Helper loaded: form_helper
INFO - 2026-05-06 04:31:25 --> Helper loaded: security_helper
INFO - 2026-05-06 04:31:25 --> Database Driver Class Initialized
INFO - 2026-05-06 04:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:31:25 --> Upload Class Initialized
INFO - 2026-05-06 04:31:25 --> Form Validation Class Initialized
INFO - 2026-05-06 04:31:25 --> Model "M_product" initialized
INFO - 2026-05-06 04:31:25 --> Model "M_settings" initialized
INFO - 2026-05-06 04:31:25 --> Controller Class Initialized
INFO - 2026-05-06 04:31:25 --> User Agent Class Initialized
INFO - 2026-05-06 04:31:25 --> Database Forge Class Initialized
INFO - 2026-05-06 04:31:25 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:31:25 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:31:25 --> Final output sent to browser
DEBUG - 2026-05-06 04:31:25 --> Total execution time: 0.1030
INFO - 2026-05-06 04:31:27 --> Config Class Initialized
INFO - 2026-05-06 04:31:27 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:31:27 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:31:27 --> Utf8 Class Initialized
INFO - 2026-05-06 04:31:27 --> URI Class Initialized
INFO - 2026-05-06 04:31:27 --> Router Class Initialized
INFO - 2026-05-06 04:31:27 --> Output Class Initialized
INFO - 2026-05-06 04:31:27 --> Security Class Initialized
DEBUG - 2026-05-06 04:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:31:27 --> Input Class Initialized
INFO - 2026-05-06 04:31:27 --> Language Class Initialized
INFO - 2026-05-06 04:31:27 --> Loader Class Initialized
INFO - 2026-05-06 04:31:27 --> Helper loaded: url_helper
INFO - 2026-05-06 04:31:27 --> Helper loaded: file_helper
INFO - 2026-05-06 04:31:27 --> Helper loaded: form_helper
INFO - 2026-05-06 04:31:27 --> Helper loaded: security_helper
INFO - 2026-05-06 04:31:27 --> Database Driver Class Initialized
INFO - 2026-05-06 04:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:31:27 --> Upload Class Initialized
INFO - 2026-05-06 04:31:27 --> Form Validation Class Initialized
INFO - 2026-05-06 04:31:27 --> Model "M_product" initialized
INFO - 2026-05-06 04:31:27 --> Model "M_settings" initialized
INFO - 2026-05-06 04:31:27 --> Controller Class Initialized
INFO - 2026-05-06 04:31:27 --> User Agent Class Initialized
INFO - 2026-05-06 04:31:27 --> Database Forge Class Initialized
INFO - 2026-05-06 04:31:27 --> Final output sent to browser
DEBUG - 2026-05-06 04:31:27 --> Total execution time: 0.1087
INFO - 2026-05-06 04:31:30 --> Config Class Initialized
INFO - 2026-05-06 04:31:30 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:31:30 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:31:30 --> Utf8 Class Initialized
INFO - 2026-05-06 04:31:30 --> URI Class Initialized
INFO - 2026-05-06 04:31:30 --> Router Class Initialized
INFO - 2026-05-06 04:31:30 --> Output Class Initialized
INFO - 2026-05-06 04:31:30 --> Security Class Initialized
DEBUG - 2026-05-06 04:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:31:30 --> Input Class Initialized
INFO - 2026-05-06 04:31:30 --> Language Class Initialized
INFO - 2026-05-06 04:31:30 --> Loader Class Initialized
INFO - 2026-05-06 04:31:30 --> Helper loaded: url_helper
INFO - 2026-05-06 04:31:30 --> Helper loaded: file_helper
INFO - 2026-05-06 04:31:30 --> Helper loaded: form_helper
INFO - 2026-05-06 04:31:30 --> Helper loaded: security_helper
INFO - 2026-05-06 04:31:30 --> Database Driver Class Initialized
INFO - 2026-05-06 04:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:31:30 --> Upload Class Initialized
INFO - 2026-05-06 04:31:30 --> Form Validation Class Initialized
INFO - 2026-05-06 04:31:30 --> Model "M_product" initialized
INFO - 2026-05-06 04:31:30 --> Model "M_settings" initialized
INFO - 2026-05-06 04:31:30 --> Controller Class Initialized
INFO - 2026-05-06 04:31:30 --> User Agent Class Initialized
INFO - 2026-05-06 04:31:30 --> Database Forge Class Initialized
INFO - 2026-05-06 04:31:30 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:31:30 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:31:30 --> Final output sent to browser
DEBUG - 2026-05-06 04:31:30 --> Total execution time: 0.0907
INFO - 2026-05-06 04:31:31 --> Config Class Initialized
INFO - 2026-05-06 04:31:31 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:31:31 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:31:31 --> Utf8 Class Initialized
INFO - 2026-05-06 04:31:31 --> URI Class Initialized
INFO - 2026-05-06 04:31:31 --> Router Class Initialized
INFO - 2026-05-06 04:31:31 --> Output Class Initialized
INFO - 2026-05-06 04:31:31 --> Security Class Initialized
DEBUG - 2026-05-06 04:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:31:31 --> Input Class Initialized
INFO - 2026-05-06 04:31:31 --> Language Class Initialized
INFO - 2026-05-06 04:31:31 --> Loader Class Initialized
INFO - 2026-05-06 04:31:31 --> Helper loaded: url_helper
INFO - 2026-05-06 04:31:31 --> Helper loaded: file_helper
INFO - 2026-05-06 04:31:31 --> Helper loaded: form_helper
INFO - 2026-05-06 04:31:31 --> Helper loaded: security_helper
INFO - 2026-05-06 04:31:31 --> Database Driver Class Initialized
INFO - 2026-05-06 04:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:31:31 --> Upload Class Initialized
INFO - 2026-05-06 04:31:31 --> Form Validation Class Initialized
INFO - 2026-05-06 04:31:31 --> Model "M_product" initialized
INFO - 2026-05-06 04:31:31 --> Model "M_settings" initialized
INFO - 2026-05-06 04:31:31 --> Controller Class Initialized
INFO - 2026-05-06 04:31:31 --> User Agent Class Initialized
INFO - 2026-05-06 04:31:31 --> Database Forge Class Initialized
INFO - 2026-05-06 04:31:31 --> Final output sent to browser
DEBUG - 2026-05-06 04:31:31 --> Total execution time: 0.1022
INFO - 2026-05-06 04:31:33 --> Config Class Initialized
INFO - 2026-05-06 04:31:33 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:31:33 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:31:33 --> Utf8 Class Initialized
INFO - 2026-05-06 04:31:33 --> URI Class Initialized
DEBUG - 2026-05-06 04:31:33 --> No URI present. Default controller set.
INFO - 2026-05-06 04:31:33 --> Router Class Initialized
INFO - 2026-05-06 04:31:33 --> Output Class Initialized
INFO - 2026-05-06 04:31:33 --> Security Class Initialized
DEBUG - 2026-05-06 04:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:31:33 --> Input Class Initialized
INFO - 2026-05-06 04:31:33 --> Language Class Initialized
INFO - 2026-05-06 04:31:33 --> Loader Class Initialized
INFO - 2026-05-06 04:31:33 --> Helper loaded: url_helper
INFO - 2026-05-06 04:31:33 --> Helper loaded: file_helper
INFO - 2026-05-06 04:31:33 --> Helper loaded: form_helper
INFO - 2026-05-06 04:31:33 --> Helper loaded: security_helper
INFO - 2026-05-06 04:31:33 --> Database Driver Class Initialized
INFO - 2026-05-06 04:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:31:33 --> Upload Class Initialized
INFO - 2026-05-06 04:31:33 --> Form Validation Class Initialized
INFO - 2026-05-06 04:31:33 --> Model "M_product" initialized
INFO - 2026-05-06 04:31:33 --> Model "M_settings" initialized
INFO - 2026-05-06 04:31:33 --> Controller Class Initialized
INFO - 2026-05-06 04:31:33 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 04:31:33 --> Final output sent to browser
DEBUG - 2026-05-06 04:31:33 --> Total execution time: 0.0829
INFO - 2026-05-06 04:31:38 --> Config Class Initialized
INFO - 2026-05-06 04:31:38 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:31:38 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:31:38 --> Utf8 Class Initialized
INFO - 2026-05-06 04:31:38 --> URI Class Initialized
INFO - 2026-05-06 04:31:38 --> Router Class Initialized
INFO - 2026-05-06 04:31:38 --> Output Class Initialized
INFO - 2026-05-06 04:31:38 --> Security Class Initialized
DEBUG - 2026-05-06 04:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:31:38 --> Input Class Initialized
INFO - 2026-05-06 04:31:38 --> Language Class Initialized
INFO - 2026-05-06 04:31:38 --> Loader Class Initialized
INFO - 2026-05-06 04:31:38 --> Helper loaded: url_helper
INFO - 2026-05-06 04:31:38 --> Helper loaded: file_helper
INFO - 2026-05-06 04:31:38 --> Helper loaded: form_helper
INFO - 2026-05-06 04:31:38 --> Helper loaded: security_helper
INFO - 2026-05-06 04:31:38 --> Database Driver Class Initialized
INFO - 2026-05-06 04:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:31:38 --> Upload Class Initialized
INFO - 2026-05-06 04:31:38 --> Form Validation Class Initialized
INFO - 2026-05-06 04:31:38 --> Model "M_product" initialized
INFO - 2026-05-06 04:31:38 --> Model "M_settings" initialized
INFO - 2026-05-06 04:31:38 --> Controller Class Initialized
INFO - 2026-05-06 04:31:38 --> User Agent Class Initialized
INFO - 2026-05-06 04:31:38 --> Database Forge Class Initialized
INFO - 2026-05-06 04:31:38 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:31:38 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:31:38 --> Final output sent to browser
DEBUG - 2026-05-06 04:31:38 --> Total execution time: 0.1048
INFO - 2026-05-06 04:31:54 --> Config Class Initialized
INFO - 2026-05-06 04:31:54 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:31:54 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:31:54 --> Utf8 Class Initialized
INFO - 2026-05-06 04:31:54 --> URI Class Initialized
INFO - 2026-05-06 04:31:54 --> Router Class Initialized
INFO - 2026-05-06 04:31:54 --> Output Class Initialized
INFO - 2026-05-06 04:31:54 --> Security Class Initialized
DEBUG - 2026-05-06 04:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:31:54 --> Input Class Initialized
INFO - 2026-05-06 04:31:54 --> Language Class Initialized
INFO - 2026-05-06 04:31:54 --> Loader Class Initialized
INFO - 2026-05-06 04:31:54 --> Helper loaded: url_helper
INFO - 2026-05-06 04:31:54 --> Helper loaded: file_helper
INFO - 2026-05-06 04:31:54 --> Helper loaded: form_helper
INFO - 2026-05-06 04:31:54 --> Helper loaded: security_helper
INFO - 2026-05-06 04:31:54 --> Database Driver Class Initialized
INFO - 2026-05-06 04:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:31:54 --> Upload Class Initialized
INFO - 2026-05-06 04:31:54 --> Form Validation Class Initialized
INFO - 2026-05-06 04:31:54 --> Model "M_product" initialized
INFO - 2026-05-06 04:31:54 --> Model "M_settings" initialized
INFO - 2026-05-06 04:31:54 --> Controller Class Initialized
INFO - 2026-05-06 04:31:54 --> User Agent Class Initialized
INFO - 2026-05-06 04:31:54 --> Database Forge Class Initialized
INFO - 2026-05-06 04:31:54 --> Final output sent to browser
DEBUG - 2026-05-06 04:31:54 --> Total execution time: 0.0903
INFO - 2026-05-06 04:31:55 --> Config Class Initialized
INFO - 2026-05-06 04:31:55 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:31:55 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:31:55 --> Utf8 Class Initialized
INFO - 2026-05-06 04:31:55 --> URI Class Initialized
INFO - 2026-05-06 04:31:55 --> Router Class Initialized
INFO - 2026-05-06 04:31:55 --> Output Class Initialized
INFO - 2026-05-06 04:31:55 --> Security Class Initialized
DEBUG - 2026-05-06 04:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:31:55 --> Input Class Initialized
INFO - 2026-05-06 04:31:55 --> Language Class Initialized
INFO - 2026-05-06 04:31:55 --> Loader Class Initialized
INFO - 2026-05-06 04:31:55 --> Helper loaded: url_helper
INFO - 2026-05-06 04:31:55 --> Helper loaded: file_helper
INFO - 2026-05-06 04:31:55 --> Helper loaded: form_helper
INFO - 2026-05-06 04:31:55 --> Helper loaded: security_helper
INFO - 2026-05-06 04:31:55 --> Database Driver Class Initialized
INFO - 2026-05-06 04:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:31:55 --> Upload Class Initialized
INFO - 2026-05-06 04:31:55 --> Form Validation Class Initialized
INFO - 2026-05-06 04:31:55 --> Model "M_product" initialized
INFO - 2026-05-06 04:31:55 --> Model "M_settings" initialized
INFO - 2026-05-06 04:31:55 --> Controller Class Initialized
INFO - 2026-05-06 04:31:55 --> User Agent Class Initialized
INFO - 2026-05-06 04:31:55 --> Database Forge Class Initialized
INFO - 2026-05-06 04:31:55 --> Final output sent to browser
DEBUG - 2026-05-06 04:31:55 --> Total execution time: 0.1273
INFO - 2026-05-06 04:33:27 --> Config Class Initialized
INFO - 2026-05-06 04:33:27 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:33:27 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:33:27 --> Utf8 Class Initialized
INFO - 2026-05-06 04:33:27 --> URI Class Initialized
INFO - 2026-05-06 04:33:27 --> Router Class Initialized
INFO - 2026-05-06 04:33:27 --> Output Class Initialized
INFO - 2026-05-06 04:33:27 --> Security Class Initialized
DEBUG - 2026-05-06 04:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:33:27 --> Input Class Initialized
INFO - 2026-05-06 04:33:27 --> Language Class Initialized
INFO - 2026-05-06 04:33:27 --> Loader Class Initialized
INFO - 2026-05-06 04:33:27 --> Helper loaded: url_helper
INFO - 2026-05-06 04:33:27 --> Helper loaded: file_helper
INFO - 2026-05-06 04:33:27 --> Helper loaded: form_helper
INFO - 2026-05-06 04:33:27 --> Helper loaded: security_helper
INFO - 2026-05-06 04:33:27 --> Database Driver Class Initialized
INFO - 2026-05-06 04:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:33:27 --> Upload Class Initialized
INFO - 2026-05-06 04:33:27 --> Form Validation Class Initialized
INFO - 2026-05-06 04:33:27 --> Model "M_product" initialized
INFO - 2026-05-06 04:33:27 --> Model "M_settings" initialized
INFO - 2026-05-06 04:33:27 --> Controller Class Initialized
INFO - 2026-05-06 04:33:27 --> User Agent Class Initialized
INFO - 2026-05-06 04:33:27 --> Database Forge Class Initialized
INFO - 2026-05-06 04:33:27 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:33:27 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:33:27 --> Final output sent to browser
DEBUG - 2026-05-06 04:33:27 --> Total execution time: 0.1005
INFO - 2026-05-06 04:35:24 --> Config Class Initialized
INFO - 2026-05-06 04:35:24 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:35:24 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:35:24 --> Utf8 Class Initialized
INFO - 2026-05-06 04:35:24 --> URI Class Initialized
INFO - 2026-05-06 04:35:24 --> Router Class Initialized
INFO - 2026-05-06 04:35:24 --> Output Class Initialized
INFO - 2026-05-06 04:35:24 --> Security Class Initialized
DEBUG - 2026-05-06 04:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:35:24 --> Input Class Initialized
INFO - 2026-05-06 04:35:24 --> Language Class Initialized
INFO - 2026-05-06 04:35:24 --> Loader Class Initialized
INFO - 2026-05-06 04:35:25 --> Helper loaded: url_helper
INFO - 2026-05-06 04:35:25 --> Helper loaded: file_helper
INFO - 2026-05-06 04:35:25 --> Helper loaded: form_helper
INFO - 2026-05-06 04:35:25 --> Helper loaded: security_helper
INFO - 2026-05-06 04:35:25 --> Database Driver Class Initialized
INFO - 2026-05-06 04:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:35:25 --> Upload Class Initialized
INFO - 2026-05-06 04:35:25 --> Form Validation Class Initialized
INFO - 2026-05-06 04:35:25 --> Model "M_product" initialized
INFO - 2026-05-06 04:35:25 --> Model "M_settings" initialized
INFO - 2026-05-06 04:35:25 --> Controller Class Initialized
INFO - 2026-05-06 04:35:25 --> User Agent Class Initialized
INFO - 2026-05-06 04:35:25 --> Database Forge Class Initialized
INFO - 2026-05-06 04:35:25 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:35:25 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:35:25 --> Final output sent to browser
DEBUG - 2026-05-06 04:35:25 --> Total execution time: 0.0916
INFO - 2026-05-06 04:39:46 --> Config Class Initialized
INFO - 2026-05-06 04:39:46 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:39:46 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:39:46 --> Utf8 Class Initialized
INFO - 2026-05-06 04:39:46 --> URI Class Initialized
INFO - 2026-05-06 04:39:46 --> Router Class Initialized
INFO - 2026-05-06 04:39:46 --> Output Class Initialized
INFO - 2026-05-06 04:39:46 --> Security Class Initialized
DEBUG - 2026-05-06 04:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:39:46 --> Input Class Initialized
INFO - 2026-05-06 04:39:46 --> Language Class Initialized
INFO - 2026-05-06 04:39:46 --> Loader Class Initialized
INFO - 2026-05-06 04:39:46 --> Helper loaded: url_helper
INFO - 2026-05-06 04:39:46 --> Helper loaded: file_helper
INFO - 2026-05-06 04:39:46 --> Helper loaded: form_helper
INFO - 2026-05-06 04:39:46 --> Helper loaded: security_helper
INFO - 2026-05-06 04:39:46 --> Database Driver Class Initialized
INFO - 2026-05-06 04:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:39:47 --> Upload Class Initialized
INFO - 2026-05-06 04:39:47 --> Form Validation Class Initialized
INFO - 2026-05-06 04:39:47 --> Model "M_product" initialized
INFO - 2026-05-06 04:39:47 --> Model "M_settings" initialized
INFO - 2026-05-06 04:39:47 --> Controller Class Initialized
INFO - 2026-05-06 04:39:47 --> User Agent Class Initialized
INFO - 2026-05-06 04:39:47 --> Database Forge Class Initialized
INFO - 2026-05-06 04:39:47 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:39:47 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:39:47 --> Final output sent to browser
DEBUG - 2026-05-06 04:39:47 --> Total execution time: 0.1189
INFO - 2026-05-06 04:39:51 --> Config Class Initialized
INFO - 2026-05-06 04:39:51 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:39:51 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:39:51 --> Utf8 Class Initialized
INFO - 2026-05-06 04:39:51 --> URI Class Initialized
INFO - 2026-05-06 04:39:51 --> Router Class Initialized
INFO - 2026-05-06 04:39:51 --> Output Class Initialized
INFO - 2026-05-06 04:39:51 --> Security Class Initialized
DEBUG - 2026-05-06 04:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:39:51 --> Input Class Initialized
INFO - 2026-05-06 04:39:51 --> Language Class Initialized
INFO - 2026-05-06 04:39:51 --> Loader Class Initialized
INFO - 2026-05-06 04:39:51 --> Helper loaded: url_helper
INFO - 2026-05-06 04:39:51 --> Helper loaded: file_helper
INFO - 2026-05-06 04:39:51 --> Helper loaded: form_helper
INFO - 2026-05-06 04:39:51 --> Helper loaded: security_helper
INFO - 2026-05-06 04:39:51 --> Database Driver Class Initialized
INFO - 2026-05-06 04:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:39:51 --> Upload Class Initialized
INFO - 2026-05-06 04:39:51 --> Form Validation Class Initialized
INFO - 2026-05-06 04:39:51 --> Model "M_product" initialized
INFO - 2026-05-06 04:39:51 --> Model "M_settings" initialized
INFO - 2026-05-06 04:39:51 --> Controller Class Initialized
INFO - 2026-05-06 04:39:51 --> User Agent Class Initialized
INFO - 2026-05-06 04:39:51 --> Database Forge Class Initialized
INFO - 2026-05-06 04:39:51 --> Final output sent to browser
DEBUG - 2026-05-06 04:39:51 --> Total execution time: 0.0876
INFO - 2026-05-06 04:40:11 --> Config Class Initialized
INFO - 2026-05-06 04:40:11 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:40:11 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:40:11 --> Utf8 Class Initialized
INFO - 2026-05-06 04:40:11 --> URI Class Initialized
INFO - 2026-05-06 04:40:11 --> Router Class Initialized
INFO - 2026-05-06 04:40:11 --> Output Class Initialized
INFO - 2026-05-06 04:40:11 --> Security Class Initialized
DEBUG - 2026-05-06 04:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:40:11 --> Input Class Initialized
INFO - 2026-05-06 04:40:11 --> Language Class Initialized
INFO - 2026-05-06 04:40:11 --> Loader Class Initialized
INFO - 2026-05-06 04:40:11 --> Helper loaded: url_helper
INFO - 2026-05-06 04:40:11 --> Helper loaded: file_helper
INFO - 2026-05-06 04:40:11 --> Helper loaded: form_helper
INFO - 2026-05-06 04:40:11 --> Helper loaded: security_helper
INFO - 2026-05-06 04:40:11 --> Database Driver Class Initialized
INFO - 2026-05-06 04:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:40:11 --> Upload Class Initialized
INFO - 2026-05-06 04:40:11 --> Form Validation Class Initialized
INFO - 2026-05-06 04:40:11 --> Model "M_product" initialized
INFO - 2026-05-06 04:40:11 --> Model "M_settings" initialized
INFO - 2026-05-06 04:40:11 --> Controller Class Initialized
INFO - 2026-05-06 04:40:11 --> User Agent Class Initialized
INFO - 2026-05-06 04:40:11 --> Database Forge Class Initialized
INFO - 2026-05-06 04:40:11 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:40:11 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:40:11 --> Final output sent to browser
DEBUG - 2026-05-06 04:40:11 --> Total execution time: 0.0989
INFO - 2026-05-06 04:40:16 --> Config Class Initialized
INFO - 2026-05-06 04:40:16 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:40:16 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:40:16 --> Utf8 Class Initialized
INFO - 2026-05-06 04:40:16 --> URI Class Initialized
DEBUG - 2026-05-06 04:40:16 --> No URI present. Default controller set.
INFO - 2026-05-06 04:40:16 --> Router Class Initialized
INFO - 2026-05-06 04:40:16 --> Output Class Initialized
INFO - 2026-05-06 04:40:16 --> Security Class Initialized
DEBUG - 2026-05-06 04:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:40:16 --> Input Class Initialized
INFO - 2026-05-06 04:40:16 --> Language Class Initialized
INFO - 2026-05-06 04:40:16 --> Loader Class Initialized
INFO - 2026-05-06 04:40:16 --> Helper loaded: url_helper
INFO - 2026-05-06 04:40:16 --> Helper loaded: file_helper
INFO - 2026-05-06 04:40:16 --> Helper loaded: form_helper
INFO - 2026-05-06 04:40:16 --> Helper loaded: security_helper
INFO - 2026-05-06 04:40:16 --> Database Driver Class Initialized
INFO - 2026-05-06 04:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:40:16 --> Upload Class Initialized
INFO - 2026-05-06 04:40:16 --> Form Validation Class Initialized
INFO - 2026-05-06 04:40:16 --> Model "M_product" initialized
INFO - 2026-05-06 04:40:16 --> Model "M_settings" initialized
INFO - 2026-05-06 04:40:16 --> Controller Class Initialized
INFO - 2026-05-06 04:40:16 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 04:40:16 --> Final output sent to browser
DEBUG - 2026-05-06 04:40:16 --> Total execution time: 0.0826
INFO - 2026-05-06 04:40:21 --> Config Class Initialized
INFO - 2026-05-06 04:40:21 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:40:21 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:40:21 --> Utf8 Class Initialized
INFO - 2026-05-06 04:40:21 --> URI Class Initialized
INFO - 2026-05-06 04:40:21 --> Router Class Initialized
INFO - 2026-05-06 04:40:21 --> Output Class Initialized
INFO - 2026-05-06 04:40:21 --> Security Class Initialized
DEBUG - 2026-05-06 04:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:40:21 --> Input Class Initialized
INFO - 2026-05-06 04:40:21 --> Language Class Initialized
INFO - 2026-05-06 04:40:21 --> Loader Class Initialized
INFO - 2026-05-06 04:40:21 --> Helper loaded: url_helper
INFO - 2026-05-06 04:40:21 --> Helper loaded: file_helper
INFO - 2026-05-06 04:40:21 --> Helper loaded: form_helper
INFO - 2026-05-06 04:40:21 --> Helper loaded: security_helper
INFO - 2026-05-06 04:40:21 --> Database Driver Class Initialized
INFO - 2026-05-06 04:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:40:21 --> Upload Class Initialized
INFO - 2026-05-06 04:40:21 --> Form Validation Class Initialized
INFO - 2026-05-06 04:40:21 --> Model "M_product" initialized
INFO - 2026-05-06 04:40:21 --> Model "M_settings" initialized
INFO - 2026-05-06 04:40:21 --> Controller Class Initialized
INFO - 2026-05-06 04:40:21 --> User Agent Class Initialized
INFO - 2026-05-06 04:40:21 --> Database Forge Class Initialized
INFO - 2026-05-06 04:40:21 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:40:21 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:40:21 --> Final output sent to browser
DEBUG - 2026-05-06 04:40:21 --> Total execution time: 0.0935
INFO - 2026-05-06 04:43:36 --> Config Class Initialized
INFO - 2026-05-06 04:43:36 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:43:36 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:43:36 --> Utf8 Class Initialized
INFO - 2026-05-06 04:43:36 --> URI Class Initialized
INFO - 2026-05-06 04:43:36 --> Router Class Initialized
INFO - 2026-05-06 04:43:36 --> Output Class Initialized
INFO - 2026-05-06 04:43:36 --> Security Class Initialized
DEBUG - 2026-05-06 04:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:43:36 --> Input Class Initialized
INFO - 2026-05-06 04:43:36 --> Language Class Initialized
INFO - 2026-05-06 04:43:36 --> Loader Class Initialized
INFO - 2026-05-06 04:43:36 --> Helper loaded: url_helper
INFO - 2026-05-06 04:43:36 --> Helper loaded: file_helper
INFO - 2026-05-06 04:43:36 --> Helper loaded: form_helper
INFO - 2026-05-06 04:43:36 --> Helper loaded: security_helper
INFO - 2026-05-06 04:43:36 --> Database Driver Class Initialized
INFO - 2026-05-06 04:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:43:36 --> Upload Class Initialized
INFO - 2026-05-06 04:43:36 --> Form Validation Class Initialized
INFO - 2026-05-06 04:43:36 --> Model "M_product" initialized
INFO - 2026-05-06 04:43:36 --> Model "M_settings" initialized
INFO - 2026-05-06 04:43:36 --> Controller Class Initialized
INFO - 2026-05-06 04:43:36 --> User Agent Class Initialized
INFO - 2026-05-06 04:43:36 --> Database Forge Class Initialized
INFO - 2026-05-06 04:43:36 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:43:36 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:43:36 --> Final output sent to browser
DEBUG - 2026-05-06 04:43:36 --> Total execution time: 0.0990
INFO - 2026-05-06 04:43:39 --> Config Class Initialized
INFO - 2026-05-06 04:43:39 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:43:39 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:43:39 --> Utf8 Class Initialized
INFO - 2026-05-06 04:43:39 --> URI Class Initialized
INFO - 2026-05-06 04:43:39 --> Router Class Initialized
INFO - 2026-05-06 04:43:39 --> Output Class Initialized
INFO - 2026-05-06 04:43:39 --> Security Class Initialized
DEBUG - 2026-05-06 04:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:43:39 --> Input Class Initialized
INFO - 2026-05-06 04:43:39 --> Language Class Initialized
INFO - 2026-05-06 04:43:39 --> Loader Class Initialized
INFO - 2026-05-06 04:43:39 --> Helper loaded: url_helper
INFO - 2026-05-06 04:43:39 --> Helper loaded: file_helper
INFO - 2026-05-06 04:43:39 --> Helper loaded: form_helper
INFO - 2026-05-06 04:43:39 --> Helper loaded: security_helper
INFO - 2026-05-06 04:43:39 --> Database Driver Class Initialized
INFO - 2026-05-06 04:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:43:40 --> Upload Class Initialized
INFO - 2026-05-06 04:43:40 --> Form Validation Class Initialized
INFO - 2026-05-06 04:43:40 --> Model "M_product" initialized
INFO - 2026-05-06 04:43:40 --> Model "M_settings" initialized
INFO - 2026-05-06 04:43:40 --> Controller Class Initialized
INFO - 2026-05-06 04:43:40 --> User Agent Class Initialized
INFO - 2026-05-06 04:43:40 --> Database Forge Class Initialized
INFO - 2026-05-06 04:43:40 --> Final output sent to browser
DEBUG - 2026-05-06 04:43:40 --> Total execution time: 0.0975
INFO - 2026-05-06 04:43:46 --> Config Class Initialized
INFO - 2026-05-06 04:43:46 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:43:46 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:43:46 --> Utf8 Class Initialized
INFO - 2026-05-06 04:43:46 --> URI Class Initialized
INFO - 2026-05-06 04:43:46 --> Router Class Initialized
INFO - 2026-05-06 04:43:46 --> Output Class Initialized
INFO - 2026-05-06 04:43:46 --> Security Class Initialized
DEBUG - 2026-05-06 04:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:43:46 --> Input Class Initialized
INFO - 2026-05-06 04:43:46 --> Language Class Initialized
INFO - 2026-05-06 04:43:46 --> Loader Class Initialized
INFO - 2026-05-06 04:43:46 --> Helper loaded: url_helper
INFO - 2026-05-06 04:43:46 --> Helper loaded: file_helper
INFO - 2026-05-06 04:43:46 --> Helper loaded: form_helper
INFO - 2026-05-06 04:43:46 --> Helper loaded: security_helper
INFO - 2026-05-06 04:43:46 --> Database Driver Class Initialized
INFO - 2026-05-06 04:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:43:46 --> Upload Class Initialized
INFO - 2026-05-06 04:43:46 --> Form Validation Class Initialized
INFO - 2026-05-06 04:43:46 --> Model "M_product" initialized
INFO - 2026-05-06 04:43:46 --> Model "M_settings" initialized
INFO - 2026-05-06 04:43:46 --> Controller Class Initialized
INFO - 2026-05-06 04:43:46 --> User Agent Class Initialized
INFO - 2026-05-06 04:43:47 --> Database Forge Class Initialized
INFO - 2026-05-06 04:43:47 --> Final output sent to browser
DEBUG - 2026-05-06 04:43:47 --> Total execution time: 0.0896
INFO - 2026-05-06 04:43:52 --> Config Class Initialized
INFO - 2026-05-06 04:43:52 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:43:52 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:43:52 --> Utf8 Class Initialized
INFO - 2026-05-06 04:43:52 --> URI Class Initialized
INFO - 2026-05-06 04:43:52 --> Router Class Initialized
INFO - 2026-05-06 04:43:52 --> Output Class Initialized
INFO - 2026-05-06 04:43:52 --> Security Class Initialized
DEBUG - 2026-05-06 04:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:43:52 --> Input Class Initialized
INFO - 2026-05-06 04:43:52 --> Language Class Initialized
INFO - 2026-05-06 04:43:52 --> Loader Class Initialized
INFO - 2026-05-06 04:43:52 --> Helper loaded: url_helper
INFO - 2026-05-06 04:43:52 --> Helper loaded: file_helper
INFO - 2026-05-06 04:43:52 --> Helper loaded: form_helper
INFO - 2026-05-06 04:43:52 --> Helper loaded: security_helper
INFO - 2026-05-06 04:43:52 --> Database Driver Class Initialized
INFO - 2026-05-06 04:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:43:52 --> Upload Class Initialized
INFO - 2026-05-06 04:43:52 --> Form Validation Class Initialized
INFO - 2026-05-06 04:43:52 --> Model "M_product" initialized
INFO - 2026-05-06 04:43:52 --> Model "M_settings" initialized
INFO - 2026-05-06 04:43:52 --> Controller Class Initialized
INFO - 2026-05-06 04:43:52 --> User Agent Class Initialized
INFO - 2026-05-06 04:43:52 --> Database Forge Class Initialized
INFO - 2026-05-06 04:43:52 --> Final output sent to browser
DEBUG - 2026-05-06 04:43:52 --> Total execution time: 0.0892
INFO - 2026-05-06 04:44:56 --> Config Class Initialized
INFO - 2026-05-06 04:44:56 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:44:56 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:44:56 --> Utf8 Class Initialized
INFO - 2026-05-06 04:44:56 --> URI Class Initialized
INFO - 2026-05-06 04:44:56 --> Router Class Initialized
INFO - 2026-05-06 04:44:56 --> Output Class Initialized
INFO - 2026-05-06 04:44:56 --> Security Class Initialized
DEBUG - 2026-05-06 04:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:44:56 --> Input Class Initialized
INFO - 2026-05-06 04:44:56 --> Language Class Initialized
INFO - 2026-05-06 04:44:56 --> Loader Class Initialized
INFO - 2026-05-06 04:44:56 --> Helper loaded: url_helper
INFO - 2026-05-06 04:44:56 --> Helper loaded: file_helper
INFO - 2026-05-06 04:44:56 --> Helper loaded: form_helper
INFO - 2026-05-06 04:44:56 --> Helper loaded: security_helper
INFO - 2026-05-06 04:44:56 --> Database Driver Class Initialized
INFO - 2026-05-06 04:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:44:56 --> Upload Class Initialized
INFO - 2026-05-06 04:44:56 --> Form Validation Class Initialized
INFO - 2026-05-06 04:44:56 --> Model "M_product" initialized
INFO - 2026-05-06 04:44:56 --> Model "M_settings" initialized
INFO - 2026-05-06 04:44:56 --> Controller Class Initialized
INFO - 2026-05-06 04:44:56 --> Model "M_sales" initialized
INFO - 2026-05-06 04:44:56 --> File loaded: C:\laragon\www\macha\application\views\user/profile.php
INFO - 2026-05-06 04:44:56 --> Final output sent to browser
DEBUG - 2026-05-06 04:44:56 --> Total execution time: 0.0834
INFO - 2026-05-06 04:53:35 --> Config Class Initialized
INFO - 2026-05-06 04:53:35 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:53:35 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:53:35 --> Utf8 Class Initialized
INFO - 2026-05-06 04:53:35 --> URI Class Initialized
INFO - 2026-05-06 04:53:35 --> Router Class Initialized
INFO - 2026-05-06 04:53:35 --> Output Class Initialized
INFO - 2026-05-06 04:53:35 --> Security Class Initialized
DEBUG - 2026-05-06 04:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:53:35 --> Input Class Initialized
INFO - 2026-05-06 04:53:35 --> Language Class Initialized
INFO - 2026-05-06 04:53:35 --> Loader Class Initialized
INFO - 2026-05-06 04:53:35 --> Helper loaded: url_helper
INFO - 2026-05-06 04:53:35 --> Helper loaded: file_helper
INFO - 2026-05-06 04:53:35 --> Helper loaded: form_helper
INFO - 2026-05-06 04:53:35 --> Helper loaded: security_helper
INFO - 2026-05-06 04:53:35 --> Database Driver Class Initialized
INFO - 2026-05-06 04:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:53:35 --> Upload Class Initialized
INFO - 2026-05-06 04:53:35 --> Form Validation Class Initialized
INFO - 2026-05-06 04:53:35 --> Model "M_product" initialized
INFO - 2026-05-06 04:53:35 --> Model "M_settings" initialized
INFO - 2026-05-06 04:53:35 --> Controller Class Initialized
INFO - 2026-05-06 04:53:35 --> Model "M_sales" initialized
INFO - 2026-05-06 04:53:35 --> File loaded: C:\laragon\www\macha\application\views\user/profile.php
INFO - 2026-05-06 04:53:35 --> Final output sent to browser
DEBUG - 2026-05-06 04:53:35 --> Total execution time: 0.0786
INFO - 2026-05-06 04:53:41 --> Config Class Initialized
INFO - 2026-05-06 04:53:41 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:53:41 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:53:41 --> Utf8 Class Initialized
INFO - 2026-05-06 04:53:41 --> URI Class Initialized
INFO - 2026-05-06 04:53:41 --> Router Class Initialized
INFO - 2026-05-06 04:53:41 --> Output Class Initialized
INFO - 2026-05-06 04:53:41 --> Security Class Initialized
DEBUG - 2026-05-06 04:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:53:41 --> Input Class Initialized
INFO - 2026-05-06 04:53:41 --> Language Class Initialized
INFO - 2026-05-06 04:53:41 --> Loader Class Initialized
INFO - 2026-05-06 04:53:41 --> Helper loaded: url_helper
INFO - 2026-05-06 04:53:41 --> Helper loaded: file_helper
INFO - 2026-05-06 04:53:41 --> Helper loaded: form_helper
INFO - 2026-05-06 04:53:41 --> Helper loaded: security_helper
INFO - 2026-05-06 04:53:41 --> Database Driver Class Initialized
INFO - 2026-05-06 04:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:53:41 --> Upload Class Initialized
INFO - 2026-05-06 04:53:41 --> Form Validation Class Initialized
INFO - 2026-05-06 04:53:41 --> Model "M_product" initialized
INFO - 2026-05-06 04:53:41 --> Model "M_settings" initialized
INFO - 2026-05-06 04:53:41 --> Controller Class Initialized
INFO - 2026-05-06 04:53:41 --> Model "M_sales" initialized
INFO - 2026-05-06 04:53:41 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:53:41 --> File loaded: C:\laragon\www\macha\application\views\user/order_history.php
INFO - 2026-05-06 04:53:41 --> Final output sent to browser
DEBUG - 2026-05-06 04:53:41 --> Total execution time: 0.0992
INFO - 2026-05-06 04:53:45 --> Config Class Initialized
INFO - 2026-05-06 04:53:45 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:53:45 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:53:45 --> Utf8 Class Initialized
INFO - 2026-05-06 04:53:45 --> URI Class Initialized
DEBUG - 2026-05-06 04:53:45 --> No URI present. Default controller set.
INFO - 2026-05-06 04:53:45 --> Router Class Initialized
INFO - 2026-05-06 04:53:45 --> Output Class Initialized
INFO - 2026-05-06 04:53:45 --> Security Class Initialized
DEBUG - 2026-05-06 04:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:53:45 --> Input Class Initialized
INFO - 2026-05-06 04:53:45 --> Language Class Initialized
INFO - 2026-05-06 04:53:45 --> Loader Class Initialized
INFO - 2026-05-06 04:53:45 --> Helper loaded: url_helper
INFO - 2026-05-06 04:53:45 --> Helper loaded: file_helper
INFO - 2026-05-06 04:53:45 --> Helper loaded: form_helper
INFO - 2026-05-06 04:53:45 --> Helper loaded: security_helper
INFO - 2026-05-06 04:53:45 --> Database Driver Class Initialized
INFO - 2026-05-06 04:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:53:45 --> Upload Class Initialized
INFO - 2026-05-06 04:53:45 --> Form Validation Class Initialized
INFO - 2026-05-06 04:53:45 --> Model "M_product" initialized
INFO - 2026-05-06 04:53:45 --> Model "M_settings" initialized
INFO - 2026-05-06 04:53:45 --> Controller Class Initialized
INFO - 2026-05-06 04:53:45 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 04:53:45 --> Final output sent to browser
DEBUG - 2026-05-06 04:53:45 --> Total execution time: 0.0876
INFO - 2026-05-06 04:57:41 --> Config Class Initialized
INFO - 2026-05-06 04:57:41 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:57:41 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:57:41 --> Utf8 Class Initialized
INFO - 2026-05-06 04:57:41 --> URI Class Initialized
DEBUG - 2026-05-06 04:57:41 --> No URI present. Default controller set.
INFO - 2026-05-06 04:57:41 --> Router Class Initialized
INFO - 2026-05-06 04:57:41 --> Output Class Initialized
INFO - 2026-05-06 04:57:41 --> Security Class Initialized
DEBUG - 2026-05-06 04:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:57:41 --> Input Class Initialized
INFO - 2026-05-06 04:57:41 --> Language Class Initialized
INFO - 2026-05-06 04:57:41 --> Loader Class Initialized
INFO - 2026-05-06 04:57:41 --> Helper loaded: url_helper
INFO - 2026-05-06 04:57:41 --> Helper loaded: file_helper
INFO - 2026-05-06 04:57:41 --> Helper loaded: form_helper
INFO - 2026-05-06 04:57:41 --> Helper loaded: security_helper
INFO - 2026-05-06 04:57:41 --> Database Driver Class Initialized
INFO - 2026-05-06 04:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:57:41 --> Upload Class Initialized
INFO - 2026-05-06 04:57:41 --> Form Validation Class Initialized
INFO - 2026-05-06 04:57:41 --> Model "M_product" initialized
INFO - 2026-05-06 04:57:41 --> Model "M_settings" initialized
INFO - 2026-05-06 04:57:41 --> Controller Class Initialized
INFO - 2026-05-06 04:57:41 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 04:57:41 --> Final output sent to browser
DEBUG - 2026-05-06 04:57:41 --> Total execution time: 0.0824
INFO - 2026-05-06 04:59:37 --> Config Class Initialized
INFO - 2026-05-06 04:59:37 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:59:37 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:59:37 --> Utf8 Class Initialized
INFO - 2026-05-06 04:59:37 --> URI Class Initialized
DEBUG - 2026-05-06 04:59:37 --> No URI present. Default controller set.
INFO - 2026-05-06 04:59:37 --> Router Class Initialized
INFO - 2026-05-06 04:59:37 --> Output Class Initialized
INFO - 2026-05-06 04:59:37 --> Security Class Initialized
DEBUG - 2026-05-06 04:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:59:37 --> Input Class Initialized
INFO - 2026-05-06 04:59:37 --> Language Class Initialized
INFO - 2026-05-06 04:59:37 --> Loader Class Initialized
INFO - 2026-05-06 04:59:37 --> Helper loaded: url_helper
INFO - 2026-05-06 04:59:37 --> Helper loaded: file_helper
INFO - 2026-05-06 04:59:37 --> Helper loaded: form_helper
INFO - 2026-05-06 04:59:37 --> Helper loaded: security_helper
INFO - 2026-05-06 04:59:37 --> Database Driver Class Initialized
INFO - 2026-05-06 04:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:59:37 --> Upload Class Initialized
INFO - 2026-05-06 04:59:37 --> Form Validation Class Initialized
INFO - 2026-05-06 04:59:37 --> Model "M_product" initialized
INFO - 2026-05-06 04:59:37 --> Model "M_settings" initialized
INFO - 2026-05-06 04:59:37 --> Controller Class Initialized
INFO - 2026-05-06 04:59:37 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 04:59:37 --> Final output sent to browser
DEBUG - 2026-05-06 04:59:37 --> Total execution time: 0.1085
INFO - 2026-05-06 04:59:44 --> Config Class Initialized
INFO - 2026-05-06 04:59:44 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:59:44 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:59:44 --> Utf8 Class Initialized
INFO - 2026-05-06 04:59:44 --> URI Class Initialized
INFO - 2026-05-06 04:59:44 --> Router Class Initialized
INFO - 2026-05-06 04:59:44 --> Output Class Initialized
INFO - 2026-05-06 04:59:44 --> Security Class Initialized
DEBUG - 2026-05-06 04:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:59:44 --> Input Class Initialized
INFO - 2026-05-06 04:59:44 --> Language Class Initialized
INFO - 2026-05-06 04:59:44 --> Loader Class Initialized
INFO - 2026-05-06 04:59:44 --> Helper loaded: url_helper
INFO - 2026-05-06 04:59:44 --> Helper loaded: file_helper
INFO - 2026-05-06 04:59:44 --> Helper loaded: form_helper
INFO - 2026-05-06 04:59:44 --> Helper loaded: security_helper
INFO - 2026-05-06 04:59:44 --> Database Driver Class Initialized
INFO - 2026-05-06 04:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:59:44 --> Upload Class Initialized
INFO - 2026-05-06 04:59:44 --> Form Validation Class Initialized
INFO - 2026-05-06 04:59:44 --> Model "M_product" initialized
INFO - 2026-05-06 04:59:44 --> Model "M_settings" initialized
INFO - 2026-05-06 04:59:44 --> Controller Class Initialized
INFO - 2026-05-06 04:59:44 --> User Agent Class Initialized
INFO - 2026-05-06 04:59:44 --> Database Forge Class Initialized
INFO - 2026-05-06 04:59:44 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-05-06 04:59:44 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-05-06 04:59:44 --> Final output sent to browser
DEBUG - 2026-05-06 04:59:44 --> Total execution time: 0.0923
INFO - 2026-05-06 04:59:48 --> Config Class Initialized
INFO - 2026-05-06 04:59:48 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:59:48 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:59:48 --> Utf8 Class Initialized
INFO - 2026-05-06 04:59:48 --> URI Class Initialized
INFO - 2026-05-06 04:59:48 --> Router Class Initialized
INFO - 2026-05-06 04:59:48 --> Output Class Initialized
INFO - 2026-05-06 04:59:48 --> Security Class Initialized
DEBUG - 2026-05-06 04:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:59:48 --> Input Class Initialized
INFO - 2026-05-06 04:59:48 --> Language Class Initialized
INFO - 2026-05-06 04:59:48 --> Loader Class Initialized
INFO - 2026-05-06 04:59:48 --> Helper loaded: url_helper
INFO - 2026-05-06 04:59:48 --> Helper loaded: file_helper
INFO - 2026-05-06 04:59:48 --> Helper loaded: form_helper
INFO - 2026-05-06 04:59:48 --> Helper loaded: security_helper
INFO - 2026-05-06 04:59:48 --> Database Driver Class Initialized
INFO - 2026-05-06 04:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:59:48 --> Upload Class Initialized
INFO - 2026-05-06 04:59:48 --> Form Validation Class Initialized
INFO - 2026-05-06 04:59:48 --> Model "M_product" initialized
INFO - 2026-05-06 04:59:48 --> Model "M_settings" initialized
INFO - 2026-05-06 04:59:48 --> Controller Class Initialized
INFO - 2026-05-06 04:59:48 --> User Agent Class Initialized
INFO - 2026-05-06 04:59:48 --> Database Forge Class Initialized
INFO - 2026-05-06 04:59:48 --> Final output sent to browser
DEBUG - 2026-05-06 04:59:48 --> Total execution time: 0.0905
INFO - 2026-05-06 04:59:55 --> Config Class Initialized
INFO - 2026-05-06 04:59:55 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:59:55 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:59:55 --> Utf8 Class Initialized
INFO - 2026-05-06 04:59:55 --> URI Class Initialized
INFO - 2026-05-06 04:59:55 --> Router Class Initialized
INFO - 2026-05-06 04:59:55 --> Output Class Initialized
INFO - 2026-05-06 04:59:55 --> Security Class Initialized
DEBUG - 2026-05-06 04:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:59:55 --> Input Class Initialized
INFO - 2026-05-06 04:59:55 --> Language Class Initialized
INFO - 2026-05-06 04:59:55 --> Loader Class Initialized
INFO - 2026-05-06 04:59:55 --> Helper loaded: url_helper
INFO - 2026-05-06 04:59:55 --> Helper loaded: file_helper
INFO - 2026-05-06 04:59:55 --> Helper loaded: form_helper
INFO - 2026-05-06 04:59:55 --> Helper loaded: security_helper
INFO - 2026-05-06 04:59:55 --> Database Driver Class Initialized
INFO - 2026-05-06 04:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:59:55 --> Upload Class Initialized
INFO - 2026-05-06 04:59:55 --> Form Validation Class Initialized
INFO - 2026-05-06 04:59:55 --> Model "M_product" initialized
INFO - 2026-05-06 04:59:55 --> Model "M_settings" initialized
INFO - 2026-05-06 04:59:55 --> Controller Class Initialized
INFO - 2026-05-06 04:59:55 --> User Agent Class Initialized
INFO - 2026-05-06 04:59:55 --> Database Forge Class Initialized
INFO - 2026-05-06 04:59:55 --> Final output sent to browser
DEBUG - 2026-05-06 04:59:55 --> Total execution time: 0.1129
INFO - 2026-05-06 04:59:56 --> Config Class Initialized
INFO - 2026-05-06 04:59:56 --> Hooks Class Initialized
DEBUG - 2026-05-06 04:59:56 --> UTF-8 Support Enabled
INFO - 2026-05-06 04:59:56 --> Utf8 Class Initialized
INFO - 2026-05-06 04:59:56 --> URI Class Initialized
INFO - 2026-05-06 04:59:56 --> Router Class Initialized
INFO - 2026-05-06 04:59:56 --> Output Class Initialized
INFO - 2026-05-06 04:59:56 --> Security Class Initialized
DEBUG - 2026-05-06 04:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 04:59:56 --> Input Class Initialized
INFO - 2026-05-06 04:59:56 --> Language Class Initialized
INFO - 2026-05-06 04:59:56 --> Loader Class Initialized
INFO - 2026-05-06 04:59:56 --> Helper loaded: url_helper
INFO - 2026-05-06 04:59:56 --> Helper loaded: file_helper
INFO - 2026-05-06 04:59:56 --> Helper loaded: form_helper
INFO - 2026-05-06 04:59:56 --> Helper loaded: security_helper
INFO - 2026-05-06 04:59:56 --> Database Driver Class Initialized
INFO - 2026-05-06 04:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 04:59:56 --> Upload Class Initialized
INFO - 2026-05-06 04:59:56 --> Form Validation Class Initialized
INFO - 2026-05-06 04:59:56 --> Model "M_product" initialized
INFO - 2026-05-06 04:59:56 --> Model "M_settings" initialized
INFO - 2026-05-06 04:59:56 --> Controller Class Initialized
INFO - 2026-05-06 04:59:56 --> User Agent Class Initialized
INFO - 2026-05-06 04:59:56 --> Database Forge Class Initialized
INFO - 2026-05-06 04:59:56 --> Final output sent to browser
DEBUG - 2026-05-06 04:59:56 --> Total execution time: 0.0781
INFO - 2026-05-06 05:00:02 --> Config Class Initialized
INFO - 2026-05-06 05:00:02 --> Hooks Class Initialized
DEBUG - 2026-05-06 05:00:02 --> UTF-8 Support Enabled
INFO - 2026-05-06 05:00:02 --> Utf8 Class Initialized
INFO - 2026-05-06 05:00:02 --> URI Class Initialized
DEBUG - 2026-05-06 05:00:02 --> No URI present. Default controller set.
INFO - 2026-05-06 05:00:02 --> Router Class Initialized
INFO - 2026-05-06 05:00:02 --> Output Class Initialized
INFO - 2026-05-06 05:00:02 --> Security Class Initialized
DEBUG - 2026-05-06 05:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-05-06 05:00:02 --> Input Class Initialized
INFO - 2026-05-06 05:00:02 --> Language Class Initialized
INFO - 2026-05-06 05:00:02 --> Loader Class Initialized
INFO - 2026-05-06 05:00:02 --> Helper loaded: url_helper
INFO - 2026-05-06 05:00:02 --> Helper loaded: file_helper
INFO - 2026-05-06 05:00:02 --> Helper loaded: form_helper
INFO - 2026-05-06 05:00:02 --> Helper loaded: security_helper
INFO - 2026-05-06 05:00:02 --> Database Driver Class Initialized
INFO - 2026-05-06 05:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-05-06 05:00:02 --> Upload Class Initialized
INFO - 2026-05-06 05:00:02 --> Form Validation Class Initialized
INFO - 2026-05-06 05:00:02 --> Model "M_product" initialized
INFO - 2026-05-06 05:00:02 --> Model "M_settings" initialized
INFO - 2026-05-06 05:00:02 --> Controller Class Initialized
INFO - 2026-05-06 05:00:02 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-05-06 05:00:02 --> Final output sent to browser
DEBUG - 2026-05-06 05:00:02 --> Total execution time: 0.0796
