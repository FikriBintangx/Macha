<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-04-30 02:52:14 --> Config Class Initialized
INFO - 2026-04-30 02:52:14 --> Hooks Class Initialized
DEBUG - 2026-04-30 02:52:14 --> UTF-8 Support Enabled
INFO - 2026-04-30 02:52:14 --> Utf8 Class Initialized
INFO - 2026-04-30 02:52:14 --> URI Class Initialized
DEBUG - 2026-04-30 02:52:14 --> No URI present. Default controller set.
INFO - 2026-04-30 02:52:14 --> Router Class Initialized
INFO - 2026-04-30 02:52:14 --> Output Class Initialized
INFO - 2026-04-30 02:52:14 --> Security Class Initialized
DEBUG - 2026-04-30 02:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 02:52:14 --> Input Class Initialized
INFO - 2026-04-30 02:52:14 --> Language Class Initialized
INFO - 2026-04-30 02:52:14 --> Loader Class Initialized
INFO - 2026-04-30 02:52:14 --> Helper loaded: url_helper
INFO - 2026-04-30 02:52:14 --> Helper loaded: file_helper
INFO - 2026-04-30 02:52:14 --> Helper loaded: form_helper
INFO - 2026-04-30 02:52:14 --> Helper loaded: security_helper
INFO - 2026-04-30 02:52:14 --> Database Driver Class Initialized
INFO - 2026-04-30 02:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 02:52:17 --> Upload Class Initialized
INFO - 2026-04-30 02:52:17 --> Form Validation Class Initialized
INFO - 2026-04-30 02:52:17 --> Model "M_product" initialized
INFO - 2026-04-30 02:52:17 --> Model "M_settings" initialized
INFO - 2026-04-30 02:52:17 --> Controller Class Initialized
INFO - 2026-04-30 02:52:18 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 02:52:18 --> Final output sent to browser
DEBUG - 2026-04-30 02:52:18 --> Total execution time: 3.2097
INFO - 2026-04-30 02:52:23 --> Config Class Initialized
INFO - 2026-04-30 02:52:23 --> Hooks Class Initialized
DEBUG - 2026-04-30 02:52:23 --> UTF-8 Support Enabled
INFO - 2026-04-30 02:52:23 --> Utf8 Class Initialized
INFO - 2026-04-30 02:52:23 --> URI Class Initialized
INFO - 2026-04-30 02:52:23 --> Router Class Initialized
INFO - 2026-04-30 02:52:23 --> Output Class Initialized
INFO - 2026-04-30 02:52:23 --> Security Class Initialized
DEBUG - 2026-04-30 02:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 02:52:23 --> Input Class Initialized
INFO - 2026-04-30 02:52:23 --> Language Class Initialized
INFO - 2026-04-30 02:52:23 --> Loader Class Initialized
INFO - 2026-04-30 02:52:23 --> Helper loaded: url_helper
INFO - 2026-04-30 02:52:23 --> Helper loaded: file_helper
INFO - 2026-04-30 02:52:23 --> Helper loaded: form_helper
INFO - 2026-04-30 02:52:23 --> Helper loaded: security_helper
INFO - 2026-04-30 02:52:23 --> Database Driver Class Initialized
INFO - 2026-04-30 02:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 02:52:23 --> Upload Class Initialized
INFO - 2026-04-30 02:52:23 --> Form Validation Class Initialized
INFO - 2026-04-30 02:52:23 --> Model "M_product" initialized
INFO - 2026-04-30 02:52:23 --> Model "M_settings" initialized
INFO - 2026-04-30 02:52:23 --> Controller Class Initialized
DEBUG - 2026-04-30 02:52:23 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-30 02:52:23 --> File loaded: C:\laragon\www\macha\application\views\auth/login.php
INFO - 2026-04-30 02:52:23 --> Final output sent to browser
DEBUG - 2026-04-30 02:52:23 --> Total execution time: 0.1185
INFO - 2026-04-30 02:52:25 --> Config Class Initialized
INFO - 2026-04-30 02:52:25 --> Hooks Class Initialized
DEBUG - 2026-04-30 02:52:25 --> UTF-8 Support Enabled
INFO - 2026-04-30 02:52:25 --> Utf8 Class Initialized
INFO - 2026-04-30 02:52:25 --> URI Class Initialized
INFO - 2026-04-30 02:52:25 --> Router Class Initialized
INFO - 2026-04-30 02:52:25 --> Output Class Initialized
INFO - 2026-04-30 02:52:25 --> Security Class Initialized
DEBUG - 2026-04-30 02:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 02:52:25 --> Input Class Initialized
INFO - 2026-04-30 02:52:25 --> Language Class Initialized
INFO - 2026-04-30 02:52:25 --> Loader Class Initialized
INFO - 2026-04-30 02:52:25 --> Helper loaded: url_helper
INFO - 2026-04-30 02:52:25 --> Helper loaded: file_helper
INFO - 2026-04-30 02:52:25 --> Helper loaded: form_helper
INFO - 2026-04-30 02:52:25 --> Helper loaded: security_helper
INFO - 2026-04-30 02:52:25 --> Database Driver Class Initialized
INFO - 2026-04-30 02:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 02:52:25 --> Upload Class Initialized
INFO - 2026-04-30 02:52:25 --> Form Validation Class Initialized
INFO - 2026-04-30 02:52:25 --> Model "M_product" initialized
INFO - 2026-04-30 02:52:25 --> Model "M_settings" initialized
INFO - 2026-04-30 02:52:25 --> Controller Class Initialized
DEBUG - 2026-04-30 02:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-30 02:52:25 --> Config Class Initialized
INFO - 2026-04-30 02:52:25 --> Hooks Class Initialized
DEBUG - 2026-04-30 02:52:25 --> UTF-8 Support Enabled
INFO - 2026-04-30 02:52:25 --> Utf8 Class Initialized
INFO - 2026-04-30 02:52:25 --> URI Class Initialized
INFO - 2026-04-30 02:52:25 --> Router Class Initialized
INFO - 2026-04-30 02:52:25 --> Output Class Initialized
INFO - 2026-04-30 02:52:25 --> Security Class Initialized
DEBUG - 2026-04-30 02:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 02:52:25 --> Input Class Initialized
INFO - 2026-04-30 02:52:25 --> Language Class Initialized
INFO - 2026-04-30 02:52:25 --> Loader Class Initialized
INFO - 2026-04-30 02:52:25 --> Helper loaded: url_helper
INFO - 2026-04-30 02:52:25 --> Helper loaded: file_helper
INFO - 2026-04-30 02:52:25 --> Helper loaded: form_helper
INFO - 2026-04-30 02:52:25 --> Helper loaded: security_helper
INFO - 2026-04-30 02:52:25 --> Database Driver Class Initialized
INFO - 2026-04-30 02:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 02:52:25 --> Upload Class Initialized
INFO - 2026-04-30 02:52:25 --> Form Validation Class Initialized
INFO - 2026-04-30 02:52:25 --> Model "M_product" initialized
INFO - 2026-04-30 02:52:25 --> Model "M_settings" initialized
INFO - 2026-04-30 02:52:25 --> Controller Class Initialized
INFO - 2026-04-30 02:52:25 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 02:52:25 --> Final output sent to browser
DEBUG - 2026-04-30 02:52:25 --> Total execution time: 0.0944
INFO - 2026-04-30 02:52:30 --> Config Class Initialized
INFO - 2026-04-30 02:52:30 --> Hooks Class Initialized
DEBUG - 2026-04-30 02:52:30 --> UTF-8 Support Enabled
INFO - 2026-04-30 02:52:30 --> Utf8 Class Initialized
INFO - 2026-04-30 02:52:30 --> URI Class Initialized
INFO - 2026-04-30 02:52:30 --> Router Class Initialized
INFO - 2026-04-30 02:52:30 --> Output Class Initialized
INFO - 2026-04-30 02:52:30 --> Security Class Initialized
DEBUG - 2026-04-30 02:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 02:52:30 --> Input Class Initialized
INFO - 2026-04-30 02:52:30 --> Language Class Initialized
INFO - 2026-04-30 02:52:30 --> Loader Class Initialized
INFO - 2026-04-30 02:52:30 --> Helper loaded: url_helper
INFO - 2026-04-30 02:52:30 --> Helper loaded: file_helper
INFO - 2026-04-30 02:52:30 --> Helper loaded: form_helper
INFO - 2026-04-30 02:52:30 --> Helper loaded: security_helper
INFO - 2026-04-30 02:52:30 --> Database Driver Class Initialized
INFO - 2026-04-30 02:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 02:52:30 --> Upload Class Initialized
INFO - 2026-04-30 02:52:30 --> Form Validation Class Initialized
INFO - 2026-04-30 02:52:30 --> Model "M_product" initialized
INFO - 2026-04-30 02:52:30 --> Model "M_settings" initialized
INFO - 2026-04-30 02:52:30 --> Controller Class Initialized
INFO - 2026-04-30 02:52:30 --> User Agent Class Initialized
INFO - 2026-04-30 02:52:30 --> Database Forge Class Initialized
INFO - 2026-04-30 02:52:30 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 02:52:30 --> File loaded: C:\laragon\www\macha\application\views\guest/cart.php
INFO - 2026-04-30 02:52:30 --> Final output sent to browser
DEBUG - 2026-04-30 02:52:30 --> Total execution time: 0.1036
INFO - 2026-04-30 02:52:33 --> Config Class Initialized
INFO - 2026-04-30 02:52:33 --> Hooks Class Initialized
DEBUG - 2026-04-30 02:52:33 --> UTF-8 Support Enabled
INFO - 2026-04-30 02:52:33 --> Utf8 Class Initialized
INFO - 2026-04-30 02:52:33 --> URI Class Initialized
INFO - 2026-04-30 02:52:33 --> Router Class Initialized
INFO - 2026-04-30 02:52:33 --> Output Class Initialized
INFO - 2026-04-30 02:52:33 --> Security Class Initialized
DEBUG - 2026-04-30 02:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 02:52:33 --> Input Class Initialized
INFO - 2026-04-30 02:52:33 --> Language Class Initialized
INFO - 2026-04-30 02:52:33 --> Loader Class Initialized
INFO - 2026-04-30 02:52:33 --> Helper loaded: url_helper
INFO - 2026-04-30 02:52:33 --> Helper loaded: file_helper
INFO - 2026-04-30 02:52:33 --> Helper loaded: form_helper
INFO - 2026-04-30 02:52:33 --> Helper loaded: security_helper
INFO - 2026-04-30 02:52:33 --> Database Driver Class Initialized
INFO - 2026-04-30 02:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 02:52:33 --> Upload Class Initialized
INFO - 2026-04-30 02:52:33 --> Form Validation Class Initialized
INFO - 2026-04-30 02:52:33 --> Model "M_product" initialized
INFO - 2026-04-30 02:52:33 --> Model "M_settings" initialized
INFO - 2026-04-30 02:52:33 --> Controller Class Initialized
INFO - 2026-04-30 02:52:33 --> Model "M_sales" initialized
INFO - 2026-04-30 02:52:33 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 02:52:33 --> File loaded: C:\laragon\www\macha\application\views\user/order_history.php
INFO - 2026-04-30 02:52:33 --> Final output sent to browser
DEBUG - 2026-04-30 02:52:33 --> Total execution time: 0.0961
INFO - 2026-04-30 02:53:40 --> Config Class Initialized
INFO - 2026-04-30 02:53:40 --> Hooks Class Initialized
DEBUG - 2026-04-30 02:53:40 --> UTF-8 Support Enabled
INFO - 2026-04-30 02:53:40 --> Utf8 Class Initialized
INFO - 2026-04-30 02:53:40 --> URI Class Initialized
INFO - 2026-04-30 02:53:40 --> Router Class Initialized
INFO - 2026-04-30 02:53:40 --> Output Class Initialized
INFO - 2026-04-30 02:53:40 --> Security Class Initialized
DEBUG - 2026-04-30 02:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 02:53:40 --> Input Class Initialized
INFO - 2026-04-30 02:53:40 --> Language Class Initialized
INFO - 2026-04-30 02:53:40 --> Loader Class Initialized
INFO - 2026-04-30 02:53:40 --> Helper loaded: url_helper
INFO - 2026-04-30 02:53:40 --> Helper loaded: file_helper
INFO - 2026-04-30 02:53:40 --> Helper loaded: form_helper
INFO - 2026-04-30 02:53:40 --> Helper loaded: security_helper
INFO - 2026-04-30 02:53:40 --> Database Driver Class Initialized
INFO - 2026-04-30 02:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 02:53:40 --> Upload Class Initialized
INFO - 2026-04-30 02:53:40 --> Form Validation Class Initialized
INFO - 2026-04-30 02:53:40 --> Model "M_product" initialized
INFO - 2026-04-30 02:53:40 --> Model "M_settings" initialized
INFO - 2026-04-30 02:53:40 --> Controller Class Initialized
INFO - 2026-04-30 02:53:40 --> Model "M_sales" initialized
INFO - 2026-04-30 02:53:40 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 02:53:40 --> File loaded: C:\laragon\www\macha\application\views\user/order_history.php
INFO - 2026-04-30 02:53:40 --> Final output sent to browser
DEBUG - 2026-04-30 02:53:40 --> Total execution time: 0.1128
INFO - 2026-04-30 02:54:12 --> Config Class Initialized
INFO - 2026-04-30 02:54:12 --> Hooks Class Initialized
DEBUG - 2026-04-30 02:54:12 --> UTF-8 Support Enabled
INFO - 2026-04-30 02:54:12 --> Utf8 Class Initialized
INFO - 2026-04-30 02:54:12 --> URI Class Initialized
INFO - 2026-04-30 02:54:12 --> Router Class Initialized
INFO - 2026-04-30 02:54:12 --> Output Class Initialized
INFO - 2026-04-30 02:54:12 --> Security Class Initialized
DEBUG - 2026-04-30 02:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 02:54:12 --> Input Class Initialized
INFO - 2026-04-30 02:54:12 --> Language Class Initialized
INFO - 2026-04-30 02:54:12 --> Loader Class Initialized
INFO - 2026-04-30 02:54:12 --> Helper loaded: url_helper
INFO - 2026-04-30 02:54:12 --> Helper loaded: file_helper
INFO - 2026-04-30 02:54:12 --> Helper loaded: form_helper
INFO - 2026-04-30 02:54:12 --> Helper loaded: security_helper
INFO - 2026-04-30 02:54:12 --> Database Driver Class Initialized
INFO - 2026-04-30 02:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 02:54:12 --> Upload Class Initialized
INFO - 2026-04-30 02:54:12 --> Form Validation Class Initialized
INFO - 2026-04-30 02:54:12 --> Model "M_product" initialized
INFO - 2026-04-30 02:54:12 --> Model "M_settings" initialized
INFO - 2026-04-30 02:54:12 --> Controller Class Initialized
INFO - 2026-04-30 02:54:12 --> Model "M_sales" initialized
INFO - 2026-04-30 02:54:12 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 02:54:12 --> File loaded: C:\laragon\www\macha\application\views\user/order_history.php
INFO - 2026-04-30 02:54:12 --> Final output sent to browser
DEBUG - 2026-04-30 02:54:12 --> Total execution time: 0.1037
INFO - 2026-04-30 02:54:15 --> Config Class Initialized
INFO - 2026-04-30 02:54:15 --> Hooks Class Initialized
DEBUG - 2026-04-30 02:54:15 --> UTF-8 Support Enabled
INFO - 2026-04-30 02:54:15 --> Utf8 Class Initialized
INFO - 2026-04-30 02:54:15 --> URI Class Initialized
DEBUG - 2026-04-30 02:54:15 --> No URI present. Default controller set.
INFO - 2026-04-30 02:54:15 --> Router Class Initialized
INFO - 2026-04-30 02:54:15 --> Output Class Initialized
INFO - 2026-04-30 02:54:15 --> Security Class Initialized
DEBUG - 2026-04-30 02:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 02:54:15 --> Input Class Initialized
INFO - 2026-04-30 02:54:15 --> Language Class Initialized
INFO - 2026-04-30 02:54:15 --> Loader Class Initialized
INFO - 2026-04-30 02:54:15 --> Helper loaded: url_helper
INFO - 2026-04-30 02:54:15 --> Helper loaded: file_helper
INFO - 2026-04-30 02:54:15 --> Helper loaded: form_helper
INFO - 2026-04-30 02:54:15 --> Helper loaded: security_helper
INFO - 2026-04-30 02:54:15 --> Database Driver Class Initialized
INFO - 2026-04-30 02:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 02:54:15 --> Upload Class Initialized
INFO - 2026-04-30 02:54:15 --> Form Validation Class Initialized
INFO - 2026-04-30 02:54:15 --> Model "M_product" initialized
INFO - 2026-04-30 02:54:15 --> Model "M_settings" initialized
INFO - 2026-04-30 02:54:15 --> Controller Class Initialized
INFO - 2026-04-30 02:54:15 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 02:54:15 --> Final output sent to browser
DEBUG - 2026-04-30 02:54:15 --> Total execution time: 0.0918
INFO - 2026-04-30 03:11:22 --> Config Class Initialized
INFO - 2026-04-30 03:11:22 --> Hooks Class Initialized
DEBUG - 2026-04-30 03:11:22 --> UTF-8 Support Enabled
INFO - 2026-04-30 03:11:22 --> Utf8 Class Initialized
INFO - 2026-04-30 03:11:22 --> URI Class Initialized
DEBUG - 2026-04-30 03:11:22 --> No URI present. Default controller set.
INFO - 2026-04-30 03:11:22 --> Router Class Initialized
INFO - 2026-04-30 03:11:22 --> Output Class Initialized
INFO - 2026-04-30 03:11:22 --> Security Class Initialized
DEBUG - 2026-04-30 03:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 03:11:22 --> Input Class Initialized
INFO - 2026-04-30 03:11:22 --> Language Class Initialized
INFO - 2026-04-30 03:11:22 --> Loader Class Initialized
INFO - 2026-04-30 03:11:22 --> Helper loaded: url_helper
INFO - 2026-04-30 03:11:22 --> Helper loaded: file_helper
INFO - 2026-04-30 03:11:22 --> Helper loaded: form_helper
INFO - 2026-04-30 03:11:22 --> Helper loaded: security_helper
INFO - 2026-04-30 03:11:22 --> Database Driver Class Initialized
INFO - 2026-04-30 03:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 03:11:22 --> Upload Class Initialized
INFO - 2026-04-30 03:11:22 --> Form Validation Class Initialized
INFO - 2026-04-30 03:11:22 --> Model "M_product" initialized
INFO - 2026-04-30 03:11:22 --> Model "M_settings" initialized
INFO - 2026-04-30 03:11:22 --> Controller Class Initialized
INFO - 2026-04-30 03:11:22 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 03:11:22 --> Final output sent to browser
DEBUG - 2026-04-30 03:11:22 --> Total execution time: 0.1004
INFO - 2026-04-30 03:11:26 --> Config Class Initialized
INFO - 2026-04-30 03:11:26 --> Hooks Class Initialized
DEBUG - 2026-04-30 03:11:26 --> UTF-8 Support Enabled
INFO - 2026-04-30 03:11:26 --> Utf8 Class Initialized
INFO - 2026-04-30 03:11:26 --> URI Class Initialized
INFO - 2026-04-30 03:11:26 --> Router Class Initialized
INFO - 2026-04-30 03:11:26 --> Output Class Initialized
INFO - 2026-04-30 03:11:26 --> Security Class Initialized
DEBUG - 2026-04-30 03:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 03:11:26 --> Input Class Initialized
INFO - 2026-04-30 03:11:26 --> Language Class Initialized
INFO - 2026-04-30 03:11:26 --> Loader Class Initialized
INFO - 2026-04-30 03:11:26 --> Helper loaded: url_helper
INFO - 2026-04-30 03:11:26 --> Helper loaded: file_helper
INFO - 2026-04-30 03:11:26 --> Helper loaded: form_helper
INFO - 2026-04-30 03:11:26 --> Helper loaded: security_helper
INFO - 2026-04-30 03:11:26 --> Database Driver Class Initialized
INFO - 2026-04-30 03:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 03:11:26 --> Upload Class Initialized
INFO - 2026-04-30 03:11:26 --> Form Validation Class Initialized
INFO - 2026-04-30 03:11:26 --> Model "M_product" initialized
INFO - 2026-04-30 03:11:26 --> Model "M_settings" initialized
INFO - 2026-04-30 03:11:26 --> Controller Class Initialized
INFO - 2026-04-30 03:11:26 --> Model "M_sales" initialized
INFO - 2026-04-30 03:11:26 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 03:11:26 --> File loaded: C:\laragon\www\macha\application\views\user/order_history.php
INFO - 2026-04-30 03:11:26 --> Final output sent to browser
DEBUG - 2026-04-30 03:11:26 --> Total execution time: 0.0888
INFO - 2026-04-30 03:11:43 --> Config Class Initialized
INFO - 2026-04-30 03:11:43 --> Hooks Class Initialized
DEBUG - 2026-04-30 03:11:43 --> UTF-8 Support Enabled
INFO - 2026-04-30 03:11:43 --> Utf8 Class Initialized
INFO - 2026-04-30 03:11:43 --> URI Class Initialized
INFO - 2026-04-30 03:11:43 --> Router Class Initialized
INFO - 2026-04-30 03:11:43 --> Output Class Initialized
INFO - 2026-04-30 03:11:43 --> Security Class Initialized
DEBUG - 2026-04-30 03:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 03:11:43 --> Input Class Initialized
INFO - 2026-04-30 03:11:43 --> Language Class Initialized
INFO - 2026-04-30 03:11:43 --> Loader Class Initialized
INFO - 2026-04-30 03:11:43 --> Helper loaded: url_helper
INFO - 2026-04-30 03:11:43 --> Helper loaded: file_helper
INFO - 2026-04-30 03:11:43 --> Helper loaded: form_helper
INFO - 2026-04-30 03:11:43 --> Helper loaded: security_helper
INFO - 2026-04-30 03:11:43 --> Database Driver Class Initialized
INFO - 2026-04-30 03:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 03:11:43 --> Upload Class Initialized
INFO - 2026-04-30 03:11:43 --> Form Validation Class Initialized
INFO - 2026-04-30 03:11:43 --> Model "M_product" initialized
INFO - 2026-04-30 03:11:43 --> Model "M_settings" initialized
INFO - 2026-04-30 03:11:43 --> Controller Class Initialized
INFO - 2026-04-30 03:11:43 --> Model "M_sales" initialized
INFO - 2026-04-30 03:11:43 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 03:11:43 --> File loaded: C:\laragon\www\macha\application\views\user/order_history.php
INFO - 2026-04-30 03:11:43 --> Final output sent to browser
DEBUG - 2026-04-30 03:11:43 --> Total execution time: 0.0862
INFO - 2026-04-30 04:12:42 --> Config Class Initialized
INFO - 2026-04-30 04:12:42 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:12:43 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:12:43 --> Utf8 Class Initialized
INFO - 2026-04-30 04:12:43 --> URI Class Initialized
DEBUG - 2026-04-30 04:12:43 --> No URI present. Default controller set.
INFO - 2026-04-30 04:12:43 --> Router Class Initialized
INFO - 2026-04-30 04:12:43 --> Output Class Initialized
INFO - 2026-04-30 04:12:43 --> Security Class Initialized
DEBUG - 2026-04-30 04:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:12:43 --> Input Class Initialized
INFO - 2026-04-30 04:12:43 --> Language Class Initialized
INFO - 2026-04-30 04:12:43 --> Loader Class Initialized
INFO - 2026-04-30 04:12:43 --> Helper loaded: url_helper
INFO - 2026-04-30 04:12:43 --> Helper loaded: file_helper
INFO - 2026-04-30 04:12:43 --> Helper loaded: form_helper
INFO - 2026-04-30 04:12:43 --> Helper loaded: security_helper
INFO - 2026-04-30 04:12:44 --> Database Driver Class Initialized
INFO - 2026-04-30 04:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:12:44 --> Upload Class Initialized
INFO - 2026-04-30 04:12:44 --> Form Validation Class Initialized
INFO - 2026-04-30 04:12:44 --> Model "M_product" initialized
INFO - 2026-04-30 04:12:44 --> Model "M_settings" initialized
INFO - 2026-04-30 04:12:44 --> Controller Class Initialized
INFO - 2026-04-30 04:12:45 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:12:45 --> Final output sent to browser
DEBUG - 2026-04-30 04:12:45 --> Total execution time: 2.3636
INFO - 2026-04-30 04:12:56 --> Config Class Initialized
INFO - 2026-04-30 04:12:56 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:12:56 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:12:56 --> Utf8 Class Initialized
INFO - 2026-04-30 04:12:56 --> URI Class Initialized
DEBUG - 2026-04-30 04:12:56 --> No URI present. Default controller set.
INFO - 2026-04-30 04:12:56 --> Router Class Initialized
INFO - 2026-04-30 04:12:56 --> Output Class Initialized
INFO - 2026-04-30 04:12:56 --> Security Class Initialized
DEBUG - 2026-04-30 04:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:12:56 --> Input Class Initialized
INFO - 2026-04-30 04:12:56 --> Language Class Initialized
INFO - 2026-04-30 04:12:56 --> Loader Class Initialized
INFO - 2026-04-30 04:12:56 --> Helper loaded: url_helper
INFO - 2026-04-30 04:12:56 --> Helper loaded: file_helper
INFO - 2026-04-30 04:12:56 --> Helper loaded: form_helper
INFO - 2026-04-30 04:12:56 --> Helper loaded: security_helper
INFO - 2026-04-30 04:12:56 --> Database Driver Class Initialized
INFO - 2026-04-30 04:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:12:56 --> Upload Class Initialized
INFO - 2026-04-30 04:12:56 --> Form Validation Class Initialized
INFO - 2026-04-30 04:12:56 --> Model "M_product" initialized
INFO - 2026-04-30 04:12:56 --> Model "M_settings" initialized
INFO - 2026-04-30 04:12:56 --> Controller Class Initialized
INFO - 2026-04-30 04:12:56 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:12:56 --> Final output sent to browser
DEBUG - 2026-04-30 04:12:56 --> Total execution time: 0.1044
INFO - 2026-04-30 04:17:06 --> Config Class Initialized
INFO - 2026-04-30 04:17:06 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:17:06 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:17:06 --> Utf8 Class Initialized
INFO - 2026-04-30 04:17:06 --> URI Class Initialized
DEBUG - 2026-04-30 04:17:06 --> No URI present. Default controller set.
INFO - 2026-04-30 04:17:06 --> Router Class Initialized
INFO - 2026-04-30 04:17:06 --> Output Class Initialized
INFO - 2026-04-30 04:17:06 --> Security Class Initialized
DEBUG - 2026-04-30 04:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:17:06 --> Input Class Initialized
INFO - 2026-04-30 04:17:06 --> Language Class Initialized
INFO - 2026-04-30 04:17:06 --> Loader Class Initialized
INFO - 2026-04-30 04:17:06 --> Helper loaded: url_helper
INFO - 2026-04-30 04:17:06 --> Helper loaded: file_helper
INFO - 2026-04-30 04:17:06 --> Helper loaded: form_helper
INFO - 2026-04-30 04:17:06 --> Helper loaded: security_helper
INFO - 2026-04-30 04:17:06 --> Database Driver Class Initialized
INFO - 2026-04-30 04:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:17:06 --> Upload Class Initialized
INFO - 2026-04-30 04:17:06 --> Form Validation Class Initialized
INFO - 2026-04-30 04:17:06 --> Model "M_product" initialized
INFO - 2026-04-30 04:17:06 --> Model "M_settings" initialized
INFO - 2026-04-30 04:17:06 --> Controller Class Initialized
INFO - 2026-04-30 04:17:06 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:17:06 --> Final output sent to browser
DEBUG - 2026-04-30 04:17:06 --> Total execution time: 0.1071
INFO - 2026-04-30 04:23:12 --> Config Class Initialized
INFO - 2026-04-30 04:23:12 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:23:12 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:23:12 --> Utf8 Class Initialized
INFO - 2026-04-30 04:23:12 --> URI Class Initialized
DEBUG - 2026-04-30 04:23:12 --> No URI present. Default controller set.
INFO - 2026-04-30 04:23:12 --> Router Class Initialized
INFO - 2026-04-30 04:23:12 --> Output Class Initialized
INFO - 2026-04-30 04:23:12 --> Security Class Initialized
DEBUG - 2026-04-30 04:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:23:12 --> Input Class Initialized
INFO - 2026-04-30 04:23:12 --> Language Class Initialized
INFO - 2026-04-30 04:23:12 --> Loader Class Initialized
INFO - 2026-04-30 04:23:12 --> Helper loaded: url_helper
INFO - 2026-04-30 04:23:12 --> Helper loaded: file_helper
INFO - 2026-04-30 04:23:12 --> Helper loaded: form_helper
INFO - 2026-04-30 04:23:12 --> Helper loaded: security_helper
INFO - 2026-04-30 04:23:12 --> Database Driver Class Initialized
INFO - 2026-04-30 04:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:23:12 --> Upload Class Initialized
INFO - 2026-04-30 04:23:12 --> Form Validation Class Initialized
INFO - 2026-04-30 04:23:12 --> Model "M_product" initialized
INFO - 2026-04-30 04:23:12 --> Model "M_settings" initialized
INFO - 2026-04-30 04:23:12 --> Controller Class Initialized
INFO - 2026-04-30 04:23:12 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:23:12 --> Final output sent to browser
DEBUG - 2026-04-30 04:23:12 --> Total execution time: 0.1117
INFO - 2026-04-30 04:23:12 --> Config Class Initialized
INFO - 2026-04-30 04:23:12 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:23:12 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:23:12 --> Utf8 Class Initialized
INFO - 2026-04-30 04:23:12 --> URI Class Initialized
INFO - 2026-04-30 04:23:12 --> Router Class Initialized
INFO - 2026-04-30 04:23:12 --> Output Class Initialized
INFO - 2026-04-30 04:23:12 --> Security Class Initialized
DEBUG - 2026-04-30 04:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:23:12 --> Input Class Initialized
INFO - 2026-04-30 04:23:12 --> Language Class Initialized
ERROR - 2026-04-30 04:23:12 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:23:31 --> Config Class Initialized
INFO - 2026-04-30 04:23:31 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:23:31 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:23:31 --> Utf8 Class Initialized
INFO - 2026-04-30 04:23:31 --> URI Class Initialized
DEBUG - 2026-04-30 04:23:31 --> No URI present. Default controller set.
INFO - 2026-04-30 04:23:31 --> Router Class Initialized
INFO - 2026-04-30 04:23:31 --> Output Class Initialized
INFO - 2026-04-30 04:23:31 --> Security Class Initialized
DEBUG - 2026-04-30 04:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:23:31 --> Input Class Initialized
INFO - 2026-04-30 04:23:31 --> Language Class Initialized
INFO - 2026-04-30 04:23:31 --> Loader Class Initialized
INFO - 2026-04-30 04:23:31 --> Helper loaded: url_helper
INFO - 2026-04-30 04:23:31 --> Helper loaded: file_helper
INFO - 2026-04-30 04:23:31 --> Helper loaded: form_helper
INFO - 2026-04-30 04:23:31 --> Helper loaded: security_helper
INFO - 2026-04-30 04:23:31 --> Database Driver Class Initialized
INFO - 2026-04-30 04:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:23:31 --> Upload Class Initialized
INFO - 2026-04-30 04:23:31 --> Form Validation Class Initialized
INFO - 2026-04-30 04:23:31 --> Model "M_product" initialized
INFO - 2026-04-30 04:23:31 --> Model "M_settings" initialized
INFO - 2026-04-30 04:23:31 --> Controller Class Initialized
INFO - 2026-04-30 04:23:31 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:23:31 --> Final output sent to browser
DEBUG - 2026-04-30 04:23:31 --> Total execution time: 0.0952
INFO - 2026-04-30 04:23:31 --> Config Class Initialized
INFO - 2026-04-30 04:23:31 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:23:31 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:23:31 --> Utf8 Class Initialized
INFO - 2026-04-30 04:23:31 --> URI Class Initialized
INFO - 2026-04-30 04:23:31 --> Router Class Initialized
INFO - 2026-04-30 04:23:31 --> Output Class Initialized
INFO - 2026-04-30 04:23:31 --> Security Class Initialized
DEBUG - 2026-04-30 04:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:23:31 --> Input Class Initialized
INFO - 2026-04-30 04:23:31 --> Language Class Initialized
ERROR - 2026-04-30 04:23:31 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:25:24 --> Config Class Initialized
INFO - 2026-04-30 04:25:24 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:25:24 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:25:24 --> Utf8 Class Initialized
INFO - 2026-04-30 04:25:24 --> URI Class Initialized
INFO - 2026-04-30 04:25:24 --> Router Class Initialized
INFO - 2026-04-30 04:25:24 --> Output Class Initialized
INFO - 2026-04-30 04:25:24 --> Security Class Initialized
DEBUG - 2026-04-30 04:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:25:24 --> Input Class Initialized
INFO - 2026-04-30 04:25:24 --> Language Class Initialized
INFO - 2026-04-30 04:25:24 --> Loader Class Initialized
INFO - 2026-04-30 04:25:24 --> Helper loaded: url_helper
INFO - 2026-04-30 04:25:24 --> Helper loaded: file_helper
INFO - 2026-04-30 04:25:24 --> Helper loaded: form_helper
INFO - 2026-04-30 04:25:24 --> Helper loaded: security_helper
INFO - 2026-04-30 04:25:24 --> Database Driver Class Initialized
INFO - 2026-04-30 04:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:25:24 --> Upload Class Initialized
INFO - 2026-04-30 04:25:24 --> Form Validation Class Initialized
INFO - 2026-04-30 04:25:24 --> Model "M_product" initialized
INFO - 2026-04-30 04:25:24 --> Model "M_settings" initialized
INFO - 2026-04-30 04:25:24 --> Controller Class Initialized
INFO - 2026-04-30 04:25:24 --> Model "M_sales" initialized
INFO - 2026-04-30 04:25:24 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 04:25:24 --> File loaded: C:\laragon\www\macha\application\views\user/order_history.php
INFO - 2026-04-30 04:25:24 --> Final output sent to browser
DEBUG - 2026-04-30 04:25:24 --> Total execution time: 0.3782
INFO - 2026-04-30 04:25:32 --> Config Class Initialized
INFO - 2026-04-30 04:25:32 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:25:32 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:25:32 --> Utf8 Class Initialized
INFO - 2026-04-30 04:25:32 --> URI Class Initialized
INFO - 2026-04-30 04:25:32 --> Router Class Initialized
INFO - 2026-04-30 04:25:32 --> Output Class Initialized
INFO - 2026-04-30 04:25:32 --> Security Class Initialized
DEBUG - 2026-04-30 04:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:25:32 --> Input Class Initialized
INFO - 2026-04-30 04:25:32 --> Language Class Initialized
INFO - 2026-04-30 04:25:32 --> Loader Class Initialized
INFO - 2026-04-30 04:25:32 --> Helper loaded: url_helper
INFO - 2026-04-30 04:25:32 --> Helper loaded: file_helper
INFO - 2026-04-30 04:25:32 --> Helper loaded: form_helper
INFO - 2026-04-30 04:25:32 --> Helper loaded: security_helper
INFO - 2026-04-30 04:25:32 --> Database Driver Class Initialized
INFO - 2026-04-30 04:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:25:32 --> Upload Class Initialized
INFO - 2026-04-30 04:25:32 --> Form Validation Class Initialized
INFO - 2026-04-30 04:25:32 --> Model "M_product" initialized
INFO - 2026-04-30 04:25:32 --> Model "M_settings" initialized
INFO - 2026-04-30 04:25:32 --> Controller Class Initialized
DEBUG - 2026-04-30 04:25:32 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-30 04:25:32 --> Config Class Initialized
INFO - 2026-04-30 04:25:32 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:25:32 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:25:32 --> Utf8 Class Initialized
INFO - 2026-04-30 04:25:32 --> URI Class Initialized
INFO - 2026-04-30 04:25:32 --> Router Class Initialized
INFO - 2026-04-30 04:25:32 --> Output Class Initialized
INFO - 2026-04-30 04:25:32 --> Security Class Initialized
DEBUG - 2026-04-30 04:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:25:32 --> Input Class Initialized
INFO - 2026-04-30 04:25:32 --> Language Class Initialized
INFO - 2026-04-30 04:25:32 --> Loader Class Initialized
INFO - 2026-04-30 04:25:32 --> Helper loaded: url_helper
INFO - 2026-04-30 04:25:32 --> Helper loaded: file_helper
INFO - 2026-04-30 04:25:32 --> Helper loaded: form_helper
INFO - 2026-04-30 04:25:32 --> Helper loaded: security_helper
INFO - 2026-04-30 04:25:32 --> Database Driver Class Initialized
INFO - 2026-04-30 04:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:25:32 --> Upload Class Initialized
INFO - 2026-04-30 04:25:32 --> Form Validation Class Initialized
INFO - 2026-04-30 04:25:32 --> Model "M_product" initialized
INFO - 2026-04-30 04:25:32 --> Model "M_settings" initialized
INFO - 2026-04-30 04:25:32 --> Controller Class Initialized
DEBUG - 2026-04-30 04:25:32 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-30 04:25:32 --> File loaded: C:\laragon\www\macha\application\views\auth/login.php
INFO - 2026-04-30 04:25:32 --> Final output sent to browser
DEBUG - 2026-04-30 04:25:32 --> Total execution time: 0.1447
INFO - 2026-04-30 04:25:33 --> Config Class Initialized
INFO - 2026-04-30 04:25:33 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:25:33 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:25:33 --> Utf8 Class Initialized
INFO - 2026-04-30 04:25:33 --> URI Class Initialized
INFO - 2026-04-30 04:25:33 --> Router Class Initialized
INFO - 2026-04-30 04:25:34 --> Output Class Initialized
INFO - 2026-04-30 04:25:34 --> Security Class Initialized
DEBUG - 2026-04-30 04:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:25:34 --> Input Class Initialized
INFO - 2026-04-30 04:25:34 --> Language Class Initialized
INFO - 2026-04-30 04:25:34 --> Loader Class Initialized
INFO - 2026-04-30 04:25:34 --> Helper loaded: url_helper
INFO - 2026-04-30 04:25:34 --> Helper loaded: file_helper
INFO - 2026-04-30 04:25:34 --> Helper loaded: form_helper
INFO - 2026-04-30 04:25:34 --> Helper loaded: security_helper
INFO - 2026-04-30 04:25:34 --> Database Driver Class Initialized
INFO - 2026-04-30 04:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:25:34 --> Upload Class Initialized
INFO - 2026-04-30 04:25:34 --> Form Validation Class Initialized
INFO - 2026-04-30 04:25:34 --> Model "M_product" initialized
INFO - 2026-04-30 04:25:34 --> Model "M_settings" initialized
INFO - 2026-04-30 04:25:34 --> Controller Class Initialized
DEBUG - 2026-04-30 04:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-30 04:25:34 --> Config Class Initialized
INFO - 2026-04-30 04:25:34 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:25:34 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:25:34 --> Utf8 Class Initialized
INFO - 2026-04-30 04:25:34 --> URI Class Initialized
INFO - 2026-04-30 04:25:34 --> Router Class Initialized
INFO - 2026-04-30 04:25:34 --> Output Class Initialized
INFO - 2026-04-30 04:25:34 --> Security Class Initialized
DEBUG - 2026-04-30 04:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:25:34 --> Input Class Initialized
INFO - 2026-04-30 04:25:34 --> Language Class Initialized
INFO - 2026-04-30 04:25:34 --> Loader Class Initialized
INFO - 2026-04-30 04:25:34 --> Helper loaded: url_helper
INFO - 2026-04-30 04:25:34 --> Helper loaded: file_helper
INFO - 2026-04-30 04:25:34 --> Helper loaded: form_helper
INFO - 2026-04-30 04:25:34 --> Helper loaded: security_helper
INFO - 2026-04-30 04:25:34 --> Database Driver Class Initialized
INFO - 2026-04-30 04:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:25:34 --> Upload Class Initialized
INFO - 2026-04-30 04:25:34 --> Form Validation Class Initialized
INFO - 2026-04-30 04:25:34 --> Model "M_product" initialized
INFO - 2026-04-30 04:25:34 --> Model "M_settings" initialized
INFO - 2026-04-30 04:25:34 --> Controller Class Initialized
INFO - 2026-04-30 04:25:34 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:25:34 --> Final output sent to browser
DEBUG - 2026-04-30 04:25:34 --> Total execution time: 0.0937
INFO - 2026-04-30 04:25:34 --> Config Class Initialized
INFO - 2026-04-30 04:25:34 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:25:34 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:25:34 --> Utf8 Class Initialized
INFO - 2026-04-30 04:25:34 --> URI Class Initialized
INFO - 2026-04-30 04:25:34 --> Router Class Initialized
INFO - 2026-04-30 04:25:34 --> Output Class Initialized
INFO - 2026-04-30 04:25:34 --> Security Class Initialized
DEBUG - 2026-04-30 04:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:25:34 --> Input Class Initialized
INFO - 2026-04-30 04:25:34 --> Language Class Initialized
ERROR - 2026-04-30 04:25:34 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:27:38 --> Config Class Initialized
INFO - 2026-04-30 04:27:38 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:27:38 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:27:38 --> Utf8 Class Initialized
INFO - 2026-04-30 04:27:38 --> URI Class Initialized
INFO - 2026-04-30 04:27:38 --> Router Class Initialized
INFO - 2026-04-30 04:27:38 --> Output Class Initialized
INFO - 2026-04-30 04:27:38 --> Security Class Initialized
DEBUG - 2026-04-30 04:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:27:38 --> Input Class Initialized
INFO - 2026-04-30 04:27:38 --> Language Class Initialized
INFO - 2026-04-30 04:27:38 --> Loader Class Initialized
INFO - 2026-04-30 04:27:38 --> Helper loaded: url_helper
INFO - 2026-04-30 04:27:38 --> Helper loaded: file_helper
INFO - 2026-04-30 04:27:38 --> Helper loaded: form_helper
INFO - 2026-04-30 04:27:38 --> Helper loaded: security_helper
INFO - 2026-04-30 04:27:38 --> Database Driver Class Initialized
INFO - 2026-04-30 04:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:27:38 --> Upload Class Initialized
INFO - 2026-04-30 04:27:38 --> Form Validation Class Initialized
INFO - 2026-04-30 04:27:38 --> Model "M_product" initialized
INFO - 2026-04-30 04:27:38 --> Model "M_settings" initialized
INFO - 2026-04-30 04:27:38 --> Controller Class Initialized
INFO - 2026-04-30 04:27:38 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:27:38 --> Final output sent to browser
DEBUG - 2026-04-30 04:27:38 --> Total execution time: 0.0895
INFO - 2026-04-30 04:27:38 --> Config Class Initialized
INFO - 2026-04-30 04:27:38 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:27:38 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:27:38 --> Utf8 Class Initialized
INFO - 2026-04-30 04:27:38 --> URI Class Initialized
INFO - 2026-04-30 04:27:38 --> Router Class Initialized
INFO - 2026-04-30 04:27:38 --> Output Class Initialized
INFO - 2026-04-30 04:27:38 --> Security Class Initialized
DEBUG - 2026-04-30 04:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:27:38 --> Input Class Initialized
INFO - 2026-04-30 04:27:38 --> Language Class Initialized
ERROR - 2026-04-30 04:27:38 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:28:27 --> Config Class Initialized
INFO - 2026-04-30 04:28:27 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:27 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:27 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:27 --> URI Class Initialized
INFO - 2026-04-30 04:28:27 --> Router Class Initialized
INFO - 2026-04-30 04:28:27 --> Output Class Initialized
INFO - 2026-04-30 04:28:27 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:27 --> Input Class Initialized
INFO - 2026-04-30 04:28:27 --> Language Class Initialized
INFO - 2026-04-30 04:28:27 --> Loader Class Initialized
INFO - 2026-04-30 04:28:27 --> Helper loaded: url_helper
INFO - 2026-04-30 04:28:27 --> Helper loaded: file_helper
INFO - 2026-04-30 04:28:28 --> Helper loaded: form_helper
INFO - 2026-04-30 04:28:28 --> Helper loaded: security_helper
INFO - 2026-04-30 04:28:28 --> Database Driver Class Initialized
INFO - 2026-04-30 04:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:28:28 --> Upload Class Initialized
INFO - 2026-04-30 04:28:28 --> Form Validation Class Initialized
INFO - 2026-04-30 04:28:28 --> Model "M_product" initialized
INFO - 2026-04-30 04:28:28 --> Model "M_settings" initialized
INFO - 2026-04-30 04:28:28 --> Controller Class Initialized
INFO - 2026-04-30 04:28:28 --> User Agent Class Initialized
INFO - 2026-04-30 04:28:28 --> Database Forge Class Initialized
INFO - 2026-04-30 04:28:28 --> Config Class Initialized
INFO - 2026-04-30 04:28:28 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:28 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:28 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:28 --> URI Class Initialized
INFO - 2026-04-30 04:28:28 --> Router Class Initialized
INFO - 2026-04-30 04:28:28 --> Output Class Initialized
INFO - 2026-04-30 04:28:28 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:28 --> Input Class Initialized
INFO - 2026-04-30 04:28:28 --> Language Class Initialized
INFO - 2026-04-30 04:28:28 --> Loader Class Initialized
INFO - 2026-04-30 04:28:28 --> Helper loaded: url_helper
INFO - 2026-04-30 04:28:28 --> Helper loaded: file_helper
INFO - 2026-04-30 04:28:28 --> Helper loaded: form_helper
INFO - 2026-04-30 04:28:28 --> Helper loaded: security_helper
INFO - 2026-04-30 04:28:28 --> Database Driver Class Initialized
INFO - 2026-04-30 04:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:28:28 --> Upload Class Initialized
INFO - 2026-04-30 04:28:28 --> Form Validation Class Initialized
INFO - 2026-04-30 04:28:28 --> Model "M_product" initialized
INFO - 2026-04-30 04:28:28 --> Model "M_settings" initialized
INFO - 2026-04-30 04:28:28 --> Controller Class Initialized
INFO - 2026-04-30 04:28:28 --> User Agent Class Initialized
INFO - 2026-04-30 04:28:28 --> Database Forge Class Initialized
INFO - 2026-04-30 04:28:28 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 04:28:28 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-04-30 04:28:28 --> Final output sent to browser
DEBUG - 2026-04-30 04:28:28 --> Total execution time: 0.1910
INFO - 2026-04-30 04:28:31 --> Config Class Initialized
INFO - 2026-04-30 04:28:31 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:31 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:31 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:31 --> URI Class Initialized
INFO - 2026-04-30 04:28:31 --> Router Class Initialized
INFO - 2026-04-30 04:28:31 --> Output Class Initialized
INFO - 2026-04-30 04:28:31 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:31 --> Input Class Initialized
INFO - 2026-04-30 04:28:31 --> Language Class Initialized
INFO - 2026-04-30 04:28:31 --> Loader Class Initialized
INFO - 2026-04-30 04:28:31 --> Helper loaded: url_helper
INFO - 2026-04-30 04:28:31 --> Helper loaded: file_helper
INFO - 2026-04-30 04:28:31 --> Helper loaded: form_helper
INFO - 2026-04-30 04:28:31 --> Helper loaded: security_helper
INFO - 2026-04-30 04:28:31 --> Database Driver Class Initialized
INFO - 2026-04-30 04:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:28:31 --> Upload Class Initialized
INFO - 2026-04-30 04:28:31 --> Form Validation Class Initialized
INFO - 2026-04-30 04:28:31 --> Model "M_product" initialized
INFO - 2026-04-30 04:28:31 --> Model "M_settings" initialized
INFO - 2026-04-30 04:28:31 --> Controller Class Initialized
INFO - 2026-04-30 04:28:31 --> User Agent Class Initialized
INFO - 2026-04-30 04:28:31 --> Database Forge Class Initialized
INFO - 2026-04-30 04:28:31 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 04:28:31 --> File loaded: C:\laragon\www\macha\application\views\guest/cart.php
INFO - 2026-04-30 04:28:31 --> Final output sent to browser
DEBUG - 2026-04-30 04:28:31 --> Total execution time: 0.1755
INFO - 2026-04-30 04:28:33 --> Config Class Initialized
INFO - 2026-04-30 04:28:33 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:33 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:33 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:33 --> URI Class Initialized
INFO - 2026-04-30 04:28:33 --> Router Class Initialized
INFO - 2026-04-30 04:28:33 --> Output Class Initialized
INFO - 2026-04-30 04:28:33 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:33 --> Input Class Initialized
INFO - 2026-04-30 04:28:33 --> Language Class Initialized
INFO - 2026-04-30 04:28:33 --> Loader Class Initialized
INFO - 2026-04-30 04:28:33 --> Helper loaded: url_helper
INFO - 2026-04-30 04:28:33 --> Helper loaded: file_helper
INFO - 2026-04-30 04:28:33 --> Helper loaded: form_helper
INFO - 2026-04-30 04:28:33 --> Helper loaded: security_helper
INFO - 2026-04-30 04:28:33 --> Database Driver Class Initialized
INFO - 2026-04-30 04:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:28:33 --> Upload Class Initialized
INFO - 2026-04-30 04:28:33 --> Form Validation Class Initialized
INFO - 2026-04-30 04:28:33 --> Model "M_product" initialized
INFO - 2026-04-30 04:28:33 --> Model "M_settings" initialized
INFO - 2026-04-30 04:28:33 --> Controller Class Initialized
INFO - 2026-04-30 04:28:33 --> User Agent Class Initialized
INFO - 2026-04-30 04:28:33 --> Database Forge Class Initialized
INFO - 2026-04-30 04:28:33 --> Final output sent to browser
DEBUG - 2026-04-30 04:28:33 --> Total execution time: 0.1032
INFO - 2026-04-30 04:28:33 --> Config Class Initialized
INFO - 2026-04-30 04:28:33 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:33 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:33 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:33 --> URI Class Initialized
INFO - 2026-04-30 04:28:33 --> Router Class Initialized
INFO - 2026-04-30 04:28:33 --> Output Class Initialized
INFO - 2026-04-30 04:28:33 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:33 --> Input Class Initialized
INFO - 2026-04-30 04:28:33 --> Language Class Initialized
INFO - 2026-04-30 04:28:33 --> Loader Class Initialized
INFO - 2026-04-30 04:28:33 --> Helper loaded: url_helper
INFO - 2026-04-30 04:28:33 --> Helper loaded: file_helper
INFO - 2026-04-30 04:28:33 --> Helper loaded: form_helper
INFO - 2026-04-30 04:28:33 --> Helper loaded: security_helper
INFO - 2026-04-30 04:28:33 --> Database Driver Class Initialized
INFO - 2026-04-30 04:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:28:34 --> Upload Class Initialized
INFO - 2026-04-30 04:28:34 --> Form Validation Class Initialized
INFO - 2026-04-30 04:28:34 --> Model "M_product" initialized
INFO - 2026-04-30 04:28:34 --> Model "M_settings" initialized
INFO - 2026-04-30 04:28:34 --> Controller Class Initialized
INFO - 2026-04-30 04:28:34 --> User Agent Class Initialized
INFO - 2026-04-30 04:28:34 --> Database Forge Class Initialized
INFO - 2026-04-30 04:28:34 --> File loaded: C:\laragon\www\macha\application\views\guest/checkout.php
INFO - 2026-04-30 04:28:34 --> Final output sent to browser
DEBUG - 2026-04-30 04:28:34 --> Total execution time: 0.2295
INFO - 2026-04-30 04:28:36 --> Config Class Initialized
INFO - 2026-04-30 04:28:36 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:36 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:36 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:36 --> URI Class Initialized
DEBUG - 2026-04-30 04:28:36 --> No URI present. Default controller set.
INFO - 2026-04-30 04:28:36 --> Router Class Initialized
INFO - 2026-04-30 04:28:36 --> Output Class Initialized
INFO - 2026-04-30 04:28:36 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:36 --> Input Class Initialized
INFO - 2026-04-30 04:28:36 --> Language Class Initialized
INFO - 2026-04-30 04:28:36 --> Loader Class Initialized
INFO - 2026-04-30 04:28:36 --> Helper loaded: url_helper
INFO - 2026-04-30 04:28:36 --> Helper loaded: file_helper
INFO - 2026-04-30 04:28:36 --> Helper loaded: form_helper
INFO - 2026-04-30 04:28:36 --> Helper loaded: security_helper
INFO - 2026-04-30 04:28:36 --> Database Driver Class Initialized
INFO - 2026-04-30 04:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:28:36 --> Upload Class Initialized
INFO - 2026-04-30 04:28:36 --> Form Validation Class Initialized
INFO - 2026-04-30 04:28:36 --> Model "M_product" initialized
INFO - 2026-04-30 04:28:36 --> Model "M_settings" initialized
INFO - 2026-04-30 04:28:36 --> Controller Class Initialized
INFO - 2026-04-30 04:28:36 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:28:36 --> Final output sent to browser
DEBUG - 2026-04-30 04:28:36 --> Total execution time: 0.0859
INFO - 2026-04-30 04:28:36 --> Config Class Initialized
INFO - 2026-04-30 04:28:36 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:36 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:36 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:36 --> URI Class Initialized
INFO - 2026-04-30 04:28:36 --> Router Class Initialized
INFO - 2026-04-30 04:28:36 --> Output Class Initialized
INFO - 2026-04-30 04:28:36 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:36 --> Input Class Initialized
INFO - 2026-04-30 04:28:36 --> Language Class Initialized
ERROR - 2026-04-30 04:28:36 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:28:42 --> Config Class Initialized
INFO - 2026-04-30 04:28:42 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:42 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:42 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:42 --> URI Class Initialized
DEBUG - 2026-04-30 04:28:42 --> No URI present. Default controller set.
INFO - 2026-04-30 04:28:42 --> Router Class Initialized
INFO - 2026-04-30 04:28:42 --> Output Class Initialized
INFO - 2026-04-30 04:28:42 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:42 --> Input Class Initialized
INFO - 2026-04-30 04:28:42 --> Language Class Initialized
INFO - 2026-04-30 04:28:42 --> Loader Class Initialized
INFO - 2026-04-30 04:28:42 --> Helper loaded: url_helper
INFO - 2026-04-30 04:28:42 --> Helper loaded: file_helper
INFO - 2026-04-30 04:28:42 --> Helper loaded: form_helper
INFO - 2026-04-30 04:28:42 --> Helper loaded: security_helper
INFO - 2026-04-30 04:28:42 --> Database Driver Class Initialized
INFO - 2026-04-30 04:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:28:42 --> Upload Class Initialized
INFO - 2026-04-30 04:28:42 --> Form Validation Class Initialized
INFO - 2026-04-30 04:28:42 --> Model "M_product" initialized
INFO - 2026-04-30 04:28:42 --> Model "M_settings" initialized
INFO - 2026-04-30 04:28:42 --> Controller Class Initialized
INFO - 2026-04-30 04:28:42 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:28:42 --> Final output sent to browser
DEBUG - 2026-04-30 04:28:42 --> Total execution time: 0.0893
INFO - 2026-04-30 04:28:42 --> Config Class Initialized
INFO - 2026-04-30 04:28:42 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:42 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:42 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:42 --> URI Class Initialized
INFO - 2026-04-30 04:28:42 --> Router Class Initialized
INFO - 2026-04-30 04:28:42 --> Output Class Initialized
INFO - 2026-04-30 04:28:42 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:42 --> Input Class Initialized
INFO - 2026-04-30 04:28:42 --> Language Class Initialized
ERROR - 2026-04-30 04:28:42 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:28:49 --> Config Class Initialized
INFO - 2026-04-30 04:28:49 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:49 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:49 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:49 --> URI Class Initialized
DEBUG - 2026-04-30 04:28:49 --> No URI present. Default controller set.
INFO - 2026-04-30 04:28:49 --> Router Class Initialized
INFO - 2026-04-30 04:28:49 --> Output Class Initialized
INFO - 2026-04-30 04:28:49 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:49 --> Input Class Initialized
INFO - 2026-04-30 04:28:49 --> Language Class Initialized
INFO - 2026-04-30 04:28:49 --> Loader Class Initialized
INFO - 2026-04-30 04:28:49 --> Helper loaded: url_helper
INFO - 2026-04-30 04:28:49 --> Helper loaded: file_helper
INFO - 2026-04-30 04:28:49 --> Helper loaded: form_helper
INFO - 2026-04-30 04:28:49 --> Helper loaded: security_helper
INFO - 2026-04-30 04:28:49 --> Database Driver Class Initialized
INFO - 2026-04-30 04:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:28:49 --> Upload Class Initialized
INFO - 2026-04-30 04:28:49 --> Form Validation Class Initialized
INFO - 2026-04-30 04:28:49 --> Model "M_product" initialized
INFO - 2026-04-30 04:28:49 --> Model "M_settings" initialized
INFO - 2026-04-30 04:28:49 --> Controller Class Initialized
INFO - 2026-04-30 04:28:49 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:28:49 --> Final output sent to browser
DEBUG - 2026-04-30 04:28:49 --> Total execution time: 0.0835
INFO - 2026-04-30 04:28:49 --> Config Class Initialized
INFO - 2026-04-30 04:28:49 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:49 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:49 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:49 --> URI Class Initialized
INFO - 2026-04-30 04:28:49 --> Router Class Initialized
INFO - 2026-04-30 04:28:49 --> Output Class Initialized
INFO - 2026-04-30 04:28:49 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:49 --> Input Class Initialized
INFO - 2026-04-30 04:28:49 --> Language Class Initialized
ERROR - 2026-04-30 04:28:49 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:28:49 --> Config Class Initialized
INFO - 2026-04-30 04:28:49 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:49 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:49 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:49 --> URI Class Initialized
DEBUG - 2026-04-30 04:28:49 --> No URI present. Default controller set.
INFO - 2026-04-30 04:28:49 --> Router Class Initialized
INFO - 2026-04-30 04:28:49 --> Output Class Initialized
INFO - 2026-04-30 04:28:49 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:50 --> Input Class Initialized
INFO - 2026-04-30 04:28:50 --> Language Class Initialized
INFO - 2026-04-30 04:28:50 --> Loader Class Initialized
INFO - 2026-04-30 04:28:50 --> Helper loaded: url_helper
INFO - 2026-04-30 04:28:50 --> Helper loaded: file_helper
INFO - 2026-04-30 04:28:50 --> Helper loaded: form_helper
INFO - 2026-04-30 04:28:50 --> Helper loaded: security_helper
INFO - 2026-04-30 04:28:50 --> Database Driver Class Initialized
INFO - 2026-04-30 04:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:28:50 --> Upload Class Initialized
INFO - 2026-04-30 04:28:50 --> Form Validation Class Initialized
INFO - 2026-04-30 04:28:50 --> Model "M_product" initialized
INFO - 2026-04-30 04:28:50 --> Model "M_settings" initialized
INFO - 2026-04-30 04:28:50 --> Controller Class Initialized
INFO - 2026-04-30 04:28:50 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:28:50 --> Final output sent to browser
DEBUG - 2026-04-30 04:28:50 --> Total execution time: 0.0878
INFO - 2026-04-30 04:28:50 --> Config Class Initialized
INFO - 2026-04-30 04:28:50 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:50 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:50 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:50 --> URI Class Initialized
INFO - 2026-04-30 04:28:50 --> Router Class Initialized
INFO - 2026-04-30 04:28:50 --> Output Class Initialized
INFO - 2026-04-30 04:28:50 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:50 --> Input Class Initialized
INFO - 2026-04-30 04:28:50 --> Language Class Initialized
ERROR - 2026-04-30 04:28:50 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:28:50 --> Config Class Initialized
INFO - 2026-04-30 04:28:50 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:50 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:50 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:50 --> URI Class Initialized
DEBUG - 2026-04-30 04:28:50 --> No URI present. Default controller set.
INFO - 2026-04-30 04:28:50 --> Router Class Initialized
INFO - 2026-04-30 04:28:50 --> Output Class Initialized
INFO - 2026-04-30 04:28:50 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:50 --> Input Class Initialized
INFO - 2026-04-30 04:28:50 --> Language Class Initialized
INFO - 2026-04-30 04:28:50 --> Loader Class Initialized
INFO - 2026-04-30 04:28:50 --> Helper loaded: url_helper
INFO - 2026-04-30 04:28:50 --> Helper loaded: file_helper
INFO - 2026-04-30 04:28:50 --> Helper loaded: form_helper
INFO - 2026-04-30 04:28:50 --> Helper loaded: security_helper
INFO - 2026-04-30 04:28:50 --> Database Driver Class Initialized
INFO - 2026-04-30 04:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:28:50 --> Upload Class Initialized
INFO - 2026-04-30 04:28:50 --> Form Validation Class Initialized
INFO - 2026-04-30 04:28:50 --> Model "M_product" initialized
INFO - 2026-04-30 04:28:50 --> Model "M_settings" initialized
INFO - 2026-04-30 04:28:50 --> Controller Class Initialized
INFO - 2026-04-30 04:28:50 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:28:50 --> Final output sent to browser
DEBUG - 2026-04-30 04:28:50 --> Total execution time: 0.0900
INFO - 2026-04-30 04:28:50 --> Config Class Initialized
INFO - 2026-04-30 04:28:50 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:50 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:50 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:50 --> URI Class Initialized
INFO - 2026-04-30 04:28:50 --> Router Class Initialized
INFO - 2026-04-30 04:28:50 --> Output Class Initialized
INFO - 2026-04-30 04:28:50 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:50 --> Input Class Initialized
INFO - 2026-04-30 04:28:50 --> Language Class Initialized
ERROR - 2026-04-30 04:28:50 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:28:58 --> Config Class Initialized
INFO - 2026-04-30 04:28:58 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:58 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:58 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:58 --> URI Class Initialized
DEBUG - 2026-04-30 04:28:58 --> No URI present. Default controller set.
INFO - 2026-04-30 04:28:58 --> Router Class Initialized
INFO - 2026-04-30 04:28:58 --> Output Class Initialized
INFO - 2026-04-30 04:28:58 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:58 --> Input Class Initialized
INFO - 2026-04-30 04:28:58 --> Language Class Initialized
INFO - 2026-04-30 04:28:58 --> Loader Class Initialized
INFO - 2026-04-30 04:28:58 --> Helper loaded: url_helper
INFO - 2026-04-30 04:28:58 --> Helper loaded: file_helper
INFO - 2026-04-30 04:28:58 --> Helper loaded: form_helper
INFO - 2026-04-30 04:28:58 --> Helper loaded: security_helper
INFO - 2026-04-30 04:28:58 --> Database Driver Class Initialized
INFO - 2026-04-30 04:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:28:58 --> Upload Class Initialized
INFO - 2026-04-30 04:28:58 --> Form Validation Class Initialized
INFO - 2026-04-30 04:28:58 --> Model "M_product" initialized
INFO - 2026-04-30 04:28:58 --> Model "M_settings" initialized
INFO - 2026-04-30 04:28:58 --> Controller Class Initialized
INFO - 2026-04-30 04:28:58 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:28:58 --> Final output sent to browser
DEBUG - 2026-04-30 04:28:58 --> Total execution time: 0.1027
INFO - 2026-04-30 04:28:58 --> Config Class Initialized
INFO - 2026-04-30 04:28:58 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:28:58 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:28:58 --> Utf8 Class Initialized
INFO - 2026-04-30 04:28:58 --> URI Class Initialized
INFO - 2026-04-30 04:28:58 --> Router Class Initialized
INFO - 2026-04-30 04:28:58 --> Output Class Initialized
INFO - 2026-04-30 04:28:58 --> Security Class Initialized
DEBUG - 2026-04-30 04:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:28:58 --> Input Class Initialized
INFO - 2026-04-30 04:28:58 --> Language Class Initialized
ERROR - 2026-04-30 04:28:58 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:29:26 --> Config Class Initialized
INFO - 2026-04-30 04:29:26 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:26 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:26 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:26 --> URI Class Initialized
DEBUG - 2026-04-30 04:29:26 --> No URI present. Default controller set.
INFO - 2026-04-30 04:29:26 --> Router Class Initialized
INFO - 2026-04-30 04:29:26 --> Output Class Initialized
INFO - 2026-04-30 04:29:26 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:26 --> Input Class Initialized
INFO - 2026-04-30 04:29:26 --> Language Class Initialized
INFO - 2026-04-30 04:29:26 --> Loader Class Initialized
INFO - 2026-04-30 04:29:26 --> Helper loaded: url_helper
INFO - 2026-04-30 04:29:26 --> Helper loaded: file_helper
INFO - 2026-04-30 04:29:26 --> Helper loaded: form_helper
INFO - 2026-04-30 04:29:26 --> Helper loaded: security_helper
INFO - 2026-04-30 04:29:26 --> Database Driver Class Initialized
INFO - 2026-04-30 04:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:29:26 --> Upload Class Initialized
INFO - 2026-04-30 04:29:26 --> Form Validation Class Initialized
INFO - 2026-04-30 04:29:26 --> Model "M_product" initialized
INFO - 2026-04-30 04:29:26 --> Model "M_settings" initialized
INFO - 2026-04-30 04:29:26 --> Controller Class Initialized
INFO - 2026-04-30 04:29:26 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:29:26 --> Final output sent to browser
DEBUG - 2026-04-30 04:29:26 --> Total execution time: 0.0922
INFO - 2026-04-30 04:29:26 --> Config Class Initialized
INFO - 2026-04-30 04:29:26 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:26 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:26 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:26 --> URI Class Initialized
INFO - 2026-04-30 04:29:26 --> Router Class Initialized
INFO - 2026-04-30 04:29:26 --> Output Class Initialized
INFO - 2026-04-30 04:29:26 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:26 --> Input Class Initialized
INFO - 2026-04-30 04:29:26 --> Language Class Initialized
ERROR - 2026-04-30 04:29:26 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:29:27 --> Config Class Initialized
INFO - 2026-04-30 04:29:27 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:27 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:27 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:27 --> URI Class Initialized
DEBUG - 2026-04-30 04:29:27 --> No URI present. Default controller set.
INFO - 2026-04-30 04:29:27 --> Router Class Initialized
INFO - 2026-04-30 04:29:27 --> Output Class Initialized
INFO - 2026-04-30 04:29:27 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:27 --> Input Class Initialized
INFO - 2026-04-30 04:29:27 --> Language Class Initialized
INFO - 2026-04-30 04:29:27 --> Loader Class Initialized
INFO - 2026-04-30 04:29:27 --> Helper loaded: url_helper
INFO - 2026-04-30 04:29:27 --> Helper loaded: file_helper
INFO - 2026-04-30 04:29:27 --> Helper loaded: form_helper
INFO - 2026-04-30 04:29:27 --> Helper loaded: security_helper
INFO - 2026-04-30 04:29:27 --> Database Driver Class Initialized
INFO - 2026-04-30 04:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:29:27 --> Upload Class Initialized
INFO - 2026-04-30 04:29:27 --> Form Validation Class Initialized
INFO - 2026-04-30 04:29:27 --> Model "M_product" initialized
INFO - 2026-04-30 04:29:27 --> Model "M_settings" initialized
INFO - 2026-04-30 04:29:27 --> Controller Class Initialized
INFO - 2026-04-30 04:29:27 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:29:27 --> Final output sent to browser
DEBUG - 2026-04-30 04:29:27 --> Total execution time: 0.0933
INFO - 2026-04-30 04:29:27 --> Config Class Initialized
INFO - 2026-04-30 04:29:27 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:27 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:27 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:27 --> URI Class Initialized
INFO - 2026-04-30 04:29:27 --> Router Class Initialized
INFO - 2026-04-30 04:29:27 --> Output Class Initialized
INFO - 2026-04-30 04:29:27 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:27 --> Input Class Initialized
INFO - 2026-04-30 04:29:27 --> Language Class Initialized
ERROR - 2026-04-30 04:29:27 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:29:27 --> Config Class Initialized
INFO - 2026-04-30 04:29:27 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:27 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:27 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:27 --> URI Class Initialized
DEBUG - 2026-04-30 04:29:27 --> No URI present. Default controller set.
INFO - 2026-04-30 04:29:27 --> Router Class Initialized
INFO - 2026-04-30 04:29:27 --> Output Class Initialized
INFO - 2026-04-30 04:29:27 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:27 --> Input Class Initialized
INFO - 2026-04-30 04:29:27 --> Language Class Initialized
INFO - 2026-04-30 04:29:27 --> Loader Class Initialized
INFO - 2026-04-30 04:29:27 --> Helper loaded: url_helper
INFO - 2026-04-30 04:29:27 --> Helper loaded: file_helper
INFO - 2026-04-30 04:29:27 --> Helper loaded: form_helper
INFO - 2026-04-30 04:29:27 --> Helper loaded: security_helper
INFO - 2026-04-30 04:29:27 --> Database Driver Class Initialized
INFO - 2026-04-30 04:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:29:27 --> Upload Class Initialized
INFO - 2026-04-30 04:29:27 --> Form Validation Class Initialized
INFO - 2026-04-30 04:29:27 --> Model "M_product" initialized
INFO - 2026-04-30 04:29:27 --> Model "M_settings" initialized
INFO - 2026-04-30 04:29:27 --> Controller Class Initialized
INFO - 2026-04-30 04:29:27 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:29:27 --> Final output sent to browser
DEBUG - 2026-04-30 04:29:27 --> Total execution time: 0.1258
INFO - 2026-04-30 04:29:27 --> Config Class Initialized
INFO - 2026-04-30 04:29:27 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:27 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:27 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:27 --> URI Class Initialized
INFO - 2026-04-30 04:29:27 --> Config Class Initialized
DEBUG - 2026-04-30 04:29:27 --> No URI present. Default controller set.
INFO - 2026-04-30 04:29:27 --> Hooks Class Initialized
INFO - 2026-04-30 04:29:27 --> Router Class Initialized
INFO - 2026-04-30 04:29:27 --> Output Class Initialized
DEBUG - 2026-04-30 04:29:27 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:27 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:27 --> Security Class Initialized
INFO - 2026-04-30 04:29:27 --> URI Class Initialized
DEBUG - 2026-04-30 04:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:27 --> Input Class Initialized
INFO - 2026-04-30 04:29:27 --> Language Class Initialized
INFO - 2026-04-30 04:29:27 --> Router Class Initialized
INFO - 2026-04-30 04:29:27 --> Output Class Initialized
INFO - 2026-04-30 04:29:27 --> Loader Class Initialized
INFO - 2026-04-30 04:29:27 --> Security Class Initialized
INFO - 2026-04-30 04:29:27 --> Helper loaded: url_helper
DEBUG - 2026-04-30 04:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:27 --> Input Class Initialized
INFO - 2026-04-30 04:29:27 --> Helper loaded: file_helper
INFO - 2026-04-30 04:29:27 --> Language Class Initialized
INFO - 2026-04-30 04:29:27 --> Helper loaded: form_helper
ERROR - 2026-04-30 04:29:27 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:29:27 --> Helper loaded: security_helper
INFO - 2026-04-30 04:29:27 --> Database Driver Class Initialized
INFO - 2026-04-30 04:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:29:27 --> Upload Class Initialized
INFO - 2026-04-30 04:29:27 --> Form Validation Class Initialized
INFO - 2026-04-30 04:29:27 --> Model "M_product" initialized
INFO - 2026-04-30 04:29:27 --> Model "M_settings" initialized
INFO - 2026-04-30 04:29:27 --> Controller Class Initialized
INFO - 2026-04-30 04:29:27 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:29:27 --> Final output sent to browser
DEBUG - 2026-04-30 04:29:27 --> Total execution time: 0.1003
INFO - 2026-04-30 04:29:27 --> Config Class Initialized
INFO - 2026-04-30 04:29:27 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:27 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:27 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:27 --> URI Class Initialized
INFO - 2026-04-30 04:29:27 --> Router Class Initialized
INFO - 2026-04-30 04:29:27 --> Output Class Initialized
INFO - 2026-04-30 04:29:27 --> Security Class Initialized
INFO - 2026-04-30 04:29:27 --> Config Class Initialized
INFO - 2026-04-30 04:29:27 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:27 --> Input Class Initialized
INFO - 2026-04-30 04:29:27 --> Language Class Initialized
DEBUG - 2026-04-30 04:29:27 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:27 --> Utf8 Class Initialized
ERROR - 2026-04-30 04:29:27 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:29:27 --> URI Class Initialized
DEBUG - 2026-04-30 04:29:27 --> No URI present. Default controller set.
INFO - 2026-04-30 04:29:27 --> Router Class Initialized
INFO - 2026-04-30 04:29:27 --> Output Class Initialized
INFO - 2026-04-30 04:29:27 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:27 --> Input Class Initialized
INFO - 2026-04-30 04:29:27 --> Language Class Initialized
INFO - 2026-04-30 04:29:27 --> Loader Class Initialized
INFO - 2026-04-30 04:29:27 --> Helper loaded: url_helper
INFO - 2026-04-30 04:29:27 --> Helper loaded: file_helper
INFO - 2026-04-30 04:29:27 --> Helper loaded: form_helper
INFO - 2026-04-30 04:29:27 --> Helper loaded: security_helper
INFO - 2026-04-30 04:29:27 --> Database Driver Class Initialized
INFO - 2026-04-30 04:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:29:27 --> Upload Class Initialized
INFO - 2026-04-30 04:29:27 --> Form Validation Class Initialized
INFO - 2026-04-30 04:29:27 --> Model "M_product" initialized
INFO - 2026-04-30 04:29:27 --> Model "M_settings" initialized
INFO - 2026-04-30 04:29:27 --> Controller Class Initialized
INFO - 2026-04-30 04:29:27 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:29:27 --> Final output sent to browser
DEBUG - 2026-04-30 04:29:27 --> Total execution time: 0.0950
INFO - 2026-04-30 04:29:28 --> Config Class Initialized
INFO - 2026-04-30 04:29:28 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:28 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:28 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:28 --> URI Class Initialized
INFO - 2026-04-30 04:29:28 --> Router Class Initialized
INFO - 2026-04-30 04:29:28 --> Output Class Initialized
INFO - 2026-04-30 04:29:28 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:28 --> Input Class Initialized
INFO - 2026-04-30 04:29:28 --> Language Class Initialized
ERROR - 2026-04-30 04:29:28 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:29:28 --> Config Class Initialized
INFO - 2026-04-30 04:29:28 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:28 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:28 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:28 --> URI Class Initialized
DEBUG - 2026-04-30 04:29:28 --> No URI present. Default controller set.
INFO - 2026-04-30 04:29:28 --> Router Class Initialized
INFO - 2026-04-30 04:29:28 --> Output Class Initialized
INFO - 2026-04-30 04:29:28 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:28 --> Input Class Initialized
INFO - 2026-04-30 04:29:28 --> Language Class Initialized
INFO - 2026-04-30 04:29:28 --> Loader Class Initialized
INFO - 2026-04-30 04:29:28 --> Helper loaded: url_helper
INFO - 2026-04-30 04:29:28 --> Helper loaded: file_helper
INFO - 2026-04-30 04:29:28 --> Helper loaded: form_helper
INFO - 2026-04-30 04:29:28 --> Helper loaded: security_helper
INFO - 2026-04-30 04:29:28 --> Database Driver Class Initialized
INFO - 2026-04-30 04:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:29:28 --> Upload Class Initialized
INFO - 2026-04-30 04:29:28 --> Form Validation Class Initialized
INFO - 2026-04-30 04:29:28 --> Model "M_product" initialized
INFO - 2026-04-30 04:29:28 --> Model "M_settings" initialized
INFO - 2026-04-30 04:29:28 --> Controller Class Initialized
INFO - 2026-04-30 04:29:28 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:29:28 --> Final output sent to browser
DEBUG - 2026-04-30 04:29:28 --> Total execution time: 0.0953
INFO - 2026-04-30 04:29:28 --> Config Class Initialized
INFO - 2026-04-30 04:29:28 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:28 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:28 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:28 --> URI Class Initialized
INFO - 2026-04-30 04:29:28 --> Router Class Initialized
INFO - 2026-04-30 04:29:28 --> Output Class Initialized
INFO - 2026-04-30 04:29:28 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:28 --> Input Class Initialized
INFO - 2026-04-30 04:29:28 --> Language Class Initialized
ERROR - 2026-04-30 04:29:28 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:29:28 --> Config Class Initialized
INFO - 2026-04-30 04:29:28 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:28 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:28 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:28 --> URI Class Initialized
DEBUG - 2026-04-30 04:29:28 --> No URI present. Default controller set.
INFO - 2026-04-30 04:29:28 --> Router Class Initialized
INFO - 2026-04-30 04:29:28 --> Output Class Initialized
INFO - 2026-04-30 04:29:28 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:28 --> Input Class Initialized
INFO - 2026-04-30 04:29:28 --> Language Class Initialized
INFO - 2026-04-30 04:29:28 --> Loader Class Initialized
INFO - 2026-04-30 04:29:28 --> Helper loaded: url_helper
INFO - 2026-04-30 04:29:28 --> Helper loaded: file_helper
INFO - 2026-04-30 04:29:28 --> Helper loaded: form_helper
INFO - 2026-04-30 04:29:28 --> Helper loaded: security_helper
INFO - 2026-04-30 04:29:28 --> Database Driver Class Initialized
INFO - 2026-04-30 04:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:29:28 --> Upload Class Initialized
INFO - 2026-04-30 04:29:28 --> Form Validation Class Initialized
INFO - 2026-04-30 04:29:28 --> Model "M_product" initialized
INFO - 2026-04-30 04:29:28 --> Model "M_settings" initialized
INFO - 2026-04-30 04:29:28 --> Controller Class Initialized
INFO - 2026-04-30 04:29:28 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:29:28 --> Final output sent to browser
DEBUG - 2026-04-30 04:29:28 --> Total execution time: 0.0976
INFO - 2026-04-30 04:29:28 --> Config Class Initialized
INFO - 2026-04-30 04:29:28 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:28 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:28 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:28 --> URI Class Initialized
INFO - 2026-04-30 04:29:28 --> Router Class Initialized
INFO - 2026-04-30 04:29:28 --> Output Class Initialized
INFO - 2026-04-30 04:29:28 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:28 --> Config Class Initialized
INFO - 2026-04-30 04:29:28 --> Input Class Initialized
INFO - 2026-04-30 04:29:28 --> Hooks Class Initialized
INFO - 2026-04-30 04:29:28 --> Language Class Initialized
ERROR - 2026-04-30 04:29:28 --> 404 Page Not Found: Assets/img
DEBUG - 2026-04-30 04:29:28 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:28 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:28 --> URI Class Initialized
DEBUG - 2026-04-30 04:29:28 --> No URI present. Default controller set.
INFO - 2026-04-30 04:29:28 --> Router Class Initialized
INFO - 2026-04-30 04:29:28 --> Output Class Initialized
INFO - 2026-04-30 04:29:28 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:28 --> Input Class Initialized
INFO - 2026-04-30 04:29:28 --> Language Class Initialized
INFO - 2026-04-30 04:29:28 --> Loader Class Initialized
INFO - 2026-04-30 04:29:28 --> Helper loaded: url_helper
INFO - 2026-04-30 04:29:28 --> Helper loaded: file_helper
INFO - 2026-04-30 04:29:28 --> Helper loaded: form_helper
INFO - 2026-04-30 04:29:28 --> Helper loaded: security_helper
INFO - 2026-04-30 04:29:28 --> Database Driver Class Initialized
INFO - 2026-04-30 04:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:29:28 --> Upload Class Initialized
INFO - 2026-04-30 04:29:28 --> Form Validation Class Initialized
INFO - 2026-04-30 04:29:28 --> Model "M_product" initialized
INFO - 2026-04-30 04:29:28 --> Model "M_settings" initialized
INFO - 2026-04-30 04:29:28 --> Controller Class Initialized
INFO - 2026-04-30 04:29:28 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:29:28 --> Final output sent to browser
DEBUG - 2026-04-30 04:29:28 --> Total execution time: 0.0876
INFO - 2026-04-30 04:29:28 --> Config Class Initialized
INFO - 2026-04-30 04:29:28 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:28 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:28 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:28 --> URI Class Initialized
INFO - 2026-04-30 04:29:28 --> Router Class Initialized
INFO - 2026-04-30 04:29:28 --> Output Class Initialized
INFO - 2026-04-30 04:29:28 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:28 --> Input Class Initialized
INFO - 2026-04-30 04:29:28 --> Language Class Initialized
ERROR - 2026-04-30 04:29:28 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:29:28 --> Config Class Initialized
INFO - 2026-04-30 04:29:28 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:28 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:28 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:28 --> URI Class Initialized
DEBUG - 2026-04-30 04:29:28 --> No URI present. Default controller set.
INFO - 2026-04-30 04:29:28 --> Router Class Initialized
INFO - 2026-04-30 04:29:28 --> Output Class Initialized
INFO - 2026-04-30 04:29:28 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:28 --> Input Class Initialized
INFO - 2026-04-30 04:29:28 --> Language Class Initialized
INFO - 2026-04-30 04:29:28 --> Loader Class Initialized
INFO - 2026-04-30 04:29:28 --> Helper loaded: url_helper
INFO - 2026-04-30 04:29:28 --> Helper loaded: file_helper
INFO - 2026-04-30 04:29:28 --> Helper loaded: form_helper
INFO - 2026-04-30 04:29:28 --> Helper loaded: security_helper
INFO - 2026-04-30 04:29:28 --> Database Driver Class Initialized
INFO - 2026-04-30 04:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:29:28 --> Upload Class Initialized
INFO - 2026-04-30 04:29:28 --> Form Validation Class Initialized
INFO - 2026-04-30 04:29:28 --> Model "M_product" initialized
INFO - 2026-04-30 04:29:28 --> Model "M_settings" initialized
INFO - 2026-04-30 04:29:28 --> Controller Class Initialized
INFO - 2026-04-30 04:29:28 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:29:28 --> Final output sent to browser
DEBUG - 2026-04-30 04:29:28 --> Total execution time: 0.0871
INFO - 2026-04-30 04:29:28 --> Config Class Initialized
INFO - 2026-04-30 04:29:28 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:28 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:28 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:28 --> URI Class Initialized
INFO - 2026-04-30 04:29:28 --> Router Class Initialized
INFO - 2026-04-30 04:29:28 --> Output Class Initialized
INFO - 2026-04-30 04:29:28 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:28 --> Input Class Initialized
INFO - 2026-04-30 04:29:28 --> Language Class Initialized
ERROR - 2026-04-30 04:29:28 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:29:28 --> Config Class Initialized
INFO - 2026-04-30 04:29:28 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:28 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:28 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:28 --> URI Class Initialized
DEBUG - 2026-04-30 04:29:28 --> No URI present. Default controller set.
INFO - 2026-04-30 04:29:28 --> Router Class Initialized
INFO - 2026-04-30 04:29:28 --> Output Class Initialized
INFO - 2026-04-30 04:29:28 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:28 --> Input Class Initialized
INFO - 2026-04-30 04:29:28 --> Language Class Initialized
INFO - 2026-04-30 04:29:28 --> Loader Class Initialized
INFO - 2026-04-30 04:29:28 --> Helper loaded: url_helper
INFO - 2026-04-30 04:29:28 --> Helper loaded: file_helper
INFO - 2026-04-30 04:29:28 --> Helper loaded: form_helper
INFO - 2026-04-30 04:29:28 --> Helper loaded: security_helper
INFO - 2026-04-30 04:29:28 --> Database Driver Class Initialized
INFO - 2026-04-30 04:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:29:28 --> Upload Class Initialized
INFO - 2026-04-30 04:29:28 --> Form Validation Class Initialized
INFO - 2026-04-30 04:29:28 --> Model "M_product" initialized
INFO - 2026-04-30 04:29:28 --> Model "M_settings" initialized
INFO - 2026-04-30 04:29:28 --> Controller Class Initialized
INFO - 2026-04-30 04:29:28 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:29:28 --> Final output sent to browser
DEBUG - 2026-04-30 04:29:28 --> Total execution time: 0.0873
INFO - 2026-04-30 04:29:28 --> Config Class Initialized
INFO - 2026-04-30 04:29:28 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:28 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:28 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:28 --> URI Class Initialized
INFO - 2026-04-30 04:29:28 --> Router Class Initialized
INFO - 2026-04-30 04:29:28 --> Output Class Initialized
INFO - 2026-04-30 04:29:28 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:28 --> Input Class Initialized
INFO - 2026-04-30 04:29:28 --> Language Class Initialized
ERROR - 2026-04-30 04:29:28 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:29:29 --> Config Class Initialized
INFO - 2026-04-30 04:29:29 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:29 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:29 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:29 --> URI Class Initialized
DEBUG - 2026-04-30 04:29:29 --> No URI present. Default controller set.
INFO - 2026-04-30 04:29:29 --> Router Class Initialized
INFO - 2026-04-30 04:29:29 --> Output Class Initialized
INFO - 2026-04-30 04:29:29 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:29 --> Input Class Initialized
INFO - 2026-04-30 04:29:29 --> Language Class Initialized
INFO - 2026-04-30 04:29:29 --> Loader Class Initialized
INFO - 2026-04-30 04:29:29 --> Helper loaded: url_helper
INFO - 2026-04-30 04:29:29 --> Helper loaded: file_helper
INFO - 2026-04-30 04:29:29 --> Helper loaded: form_helper
INFO - 2026-04-30 04:29:29 --> Helper loaded: security_helper
INFO - 2026-04-30 04:29:29 --> Database Driver Class Initialized
INFO - 2026-04-30 04:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:29:29 --> Upload Class Initialized
INFO - 2026-04-30 04:29:29 --> Form Validation Class Initialized
INFO - 2026-04-30 04:29:29 --> Model "M_product" initialized
INFO - 2026-04-30 04:29:29 --> Model "M_settings" initialized
INFO - 2026-04-30 04:29:29 --> Controller Class Initialized
INFO - 2026-04-30 04:29:29 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:29:29 --> Final output sent to browser
DEBUG - 2026-04-30 04:29:29 --> Total execution time: 0.0834
INFO - 2026-04-30 04:29:29 --> Config Class Initialized
INFO - 2026-04-30 04:29:29 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:29:29 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:29:29 --> Utf8 Class Initialized
INFO - 2026-04-30 04:29:29 --> URI Class Initialized
INFO - 2026-04-30 04:29:29 --> Router Class Initialized
INFO - 2026-04-30 04:29:29 --> Output Class Initialized
INFO - 2026-04-30 04:29:29 --> Security Class Initialized
DEBUG - 2026-04-30 04:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:29:29 --> Input Class Initialized
INFO - 2026-04-30 04:29:29 --> Language Class Initialized
ERROR - 2026-04-30 04:29:29 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:31:24 --> Config Class Initialized
INFO - 2026-04-30 04:31:24 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:31:24 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:31:24 --> Utf8 Class Initialized
INFO - 2026-04-30 04:31:24 --> URI Class Initialized
DEBUG - 2026-04-30 04:31:24 --> No URI present. Default controller set.
INFO - 2026-04-30 04:31:24 --> Router Class Initialized
INFO - 2026-04-30 04:31:24 --> Output Class Initialized
INFO - 2026-04-30 04:31:24 --> Security Class Initialized
DEBUG - 2026-04-30 04:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:31:24 --> Input Class Initialized
INFO - 2026-04-30 04:31:24 --> Language Class Initialized
INFO - 2026-04-30 04:31:24 --> Loader Class Initialized
INFO - 2026-04-30 04:31:24 --> Helper loaded: url_helper
INFO - 2026-04-30 04:31:24 --> Helper loaded: file_helper
INFO - 2026-04-30 04:31:24 --> Helper loaded: form_helper
INFO - 2026-04-30 04:31:24 --> Helper loaded: security_helper
INFO - 2026-04-30 04:31:24 --> Database Driver Class Initialized
INFO - 2026-04-30 04:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:31:24 --> Upload Class Initialized
INFO - 2026-04-30 04:31:24 --> Form Validation Class Initialized
INFO - 2026-04-30 04:31:24 --> Model "M_product" initialized
INFO - 2026-04-30 04:31:24 --> Model "M_settings" initialized
INFO - 2026-04-30 04:31:24 --> Controller Class Initialized
INFO - 2026-04-30 04:31:24 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:31:24 --> Final output sent to browser
DEBUG - 2026-04-30 04:31:24 --> Total execution time: 0.0885
INFO - 2026-04-30 04:31:24 --> Config Class Initialized
INFO - 2026-04-30 04:31:24 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:31:24 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:31:24 --> Utf8 Class Initialized
INFO - 2026-04-30 04:31:24 --> URI Class Initialized
INFO - 2026-04-30 04:31:24 --> Router Class Initialized
INFO - 2026-04-30 04:31:24 --> Output Class Initialized
INFO - 2026-04-30 04:31:24 --> Security Class Initialized
DEBUG - 2026-04-30 04:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:31:24 --> Input Class Initialized
INFO - 2026-04-30 04:31:24 --> Language Class Initialized
ERROR - 2026-04-30 04:31:24 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:31:32 --> Config Class Initialized
INFO - 2026-04-30 04:31:32 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:31:32 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:31:32 --> Utf8 Class Initialized
INFO - 2026-04-30 04:31:32 --> URI Class Initialized
DEBUG - 2026-04-30 04:31:32 --> No URI present. Default controller set.
INFO - 2026-04-30 04:31:32 --> Router Class Initialized
INFO - 2026-04-30 04:31:32 --> Output Class Initialized
INFO - 2026-04-30 04:31:32 --> Security Class Initialized
DEBUG - 2026-04-30 04:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:31:32 --> Input Class Initialized
INFO - 2026-04-30 04:31:32 --> Language Class Initialized
INFO - 2026-04-30 04:31:32 --> Loader Class Initialized
INFO - 2026-04-30 04:31:32 --> Helper loaded: url_helper
INFO - 2026-04-30 04:31:32 --> Helper loaded: file_helper
INFO - 2026-04-30 04:31:32 --> Helper loaded: form_helper
INFO - 2026-04-30 04:31:32 --> Helper loaded: security_helper
INFO - 2026-04-30 04:31:32 --> Database Driver Class Initialized
INFO - 2026-04-30 04:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:31:32 --> Upload Class Initialized
INFO - 2026-04-30 04:31:32 --> Form Validation Class Initialized
INFO - 2026-04-30 04:31:32 --> Model "M_product" initialized
INFO - 2026-04-30 04:31:32 --> Model "M_settings" initialized
INFO - 2026-04-30 04:31:32 --> Controller Class Initialized
INFO - 2026-04-30 04:31:32 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:31:32 --> Final output sent to browser
DEBUG - 2026-04-30 04:31:32 --> Total execution time: 0.0841
INFO - 2026-04-30 04:31:32 --> Config Class Initialized
INFO - 2026-04-30 04:31:32 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:31:32 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:31:32 --> Utf8 Class Initialized
INFO - 2026-04-30 04:31:32 --> URI Class Initialized
INFO - 2026-04-30 04:31:32 --> Router Class Initialized
INFO - 2026-04-30 04:31:32 --> Output Class Initialized
INFO - 2026-04-30 04:31:32 --> Security Class Initialized
DEBUG - 2026-04-30 04:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:31:32 --> Input Class Initialized
INFO - 2026-04-30 04:31:32 --> Language Class Initialized
ERROR - 2026-04-30 04:31:32 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:31:35 --> Config Class Initialized
INFO - 2026-04-30 04:31:35 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:31:35 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:31:35 --> Utf8 Class Initialized
INFO - 2026-04-30 04:31:35 --> URI Class Initialized
DEBUG - 2026-04-30 04:31:35 --> No URI present. Default controller set.
INFO - 2026-04-30 04:31:35 --> Router Class Initialized
INFO - 2026-04-30 04:31:35 --> Output Class Initialized
INFO - 2026-04-30 04:31:35 --> Security Class Initialized
DEBUG - 2026-04-30 04:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:31:35 --> Input Class Initialized
INFO - 2026-04-30 04:31:35 --> Language Class Initialized
INFO - 2026-04-30 04:31:35 --> Loader Class Initialized
INFO - 2026-04-30 04:31:35 --> Helper loaded: url_helper
INFO - 2026-04-30 04:31:35 --> Helper loaded: file_helper
INFO - 2026-04-30 04:31:35 --> Helper loaded: form_helper
INFO - 2026-04-30 04:31:35 --> Helper loaded: security_helper
INFO - 2026-04-30 04:31:35 --> Database Driver Class Initialized
INFO - 2026-04-30 04:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:31:35 --> Upload Class Initialized
INFO - 2026-04-30 04:31:35 --> Form Validation Class Initialized
INFO - 2026-04-30 04:31:35 --> Model "M_product" initialized
INFO - 2026-04-30 04:31:35 --> Model "M_settings" initialized
INFO - 2026-04-30 04:31:35 --> Controller Class Initialized
INFO - 2026-04-30 04:31:35 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:31:35 --> Final output sent to browser
DEBUG - 2026-04-30 04:31:35 --> Total execution time: 0.0930
INFO - 2026-04-30 04:31:35 --> Config Class Initialized
INFO - 2026-04-30 04:31:35 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:31:35 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:31:35 --> Utf8 Class Initialized
INFO - 2026-04-30 04:31:35 --> URI Class Initialized
INFO - 2026-04-30 04:31:35 --> Router Class Initialized
INFO - 2026-04-30 04:31:35 --> Output Class Initialized
INFO - 2026-04-30 04:31:35 --> Security Class Initialized
DEBUG - 2026-04-30 04:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:31:35 --> Input Class Initialized
INFO - 2026-04-30 04:31:35 --> Language Class Initialized
ERROR - 2026-04-30 04:31:35 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:32:13 --> Config Class Initialized
INFO - 2026-04-30 04:32:13 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:32:13 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:32:13 --> Utf8 Class Initialized
INFO - 2026-04-30 04:32:13 --> URI Class Initialized
DEBUG - 2026-04-30 04:32:13 --> No URI present. Default controller set.
INFO - 2026-04-30 04:32:13 --> Router Class Initialized
INFO - 2026-04-30 04:32:13 --> Output Class Initialized
INFO - 2026-04-30 04:32:13 --> Security Class Initialized
DEBUG - 2026-04-30 04:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:32:13 --> Input Class Initialized
INFO - 2026-04-30 04:32:13 --> Language Class Initialized
INFO - 2026-04-30 04:32:13 --> Loader Class Initialized
INFO - 2026-04-30 04:32:13 --> Helper loaded: url_helper
INFO - 2026-04-30 04:32:13 --> Helper loaded: file_helper
INFO - 2026-04-30 04:32:13 --> Helper loaded: form_helper
INFO - 2026-04-30 04:32:13 --> Helper loaded: security_helper
INFO - 2026-04-30 04:32:13 --> Database Driver Class Initialized
INFO - 2026-04-30 04:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:32:13 --> Upload Class Initialized
INFO - 2026-04-30 04:32:13 --> Form Validation Class Initialized
INFO - 2026-04-30 04:32:13 --> Model "M_product" initialized
INFO - 2026-04-30 04:32:13 --> Model "M_settings" initialized
INFO - 2026-04-30 04:32:13 --> Controller Class Initialized
INFO - 2026-04-30 04:32:13 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:32:13 --> Final output sent to browser
DEBUG - 2026-04-30 04:32:13 --> Total execution time: 0.0892
INFO - 2026-04-30 04:32:13 --> Config Class Initialized
INFO - 2026-04-30 04:32:13 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:32:13 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:32:13 --> Utf8 Class Initialized
INFO - 2026-04-30 04:32:13 --> URI Class Initialized
INFO - 2026-04-30 04:32:13 --> Router Class Initialized
INFO - 2026-04-30 04:32:14 --> Output Class Initialized
INFO - 2026-04-30 04:32:14 --> Security Class Initialized
DEBUG - 2026-04-30 04:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:32:14 --> Input Class Initialized
INFO - 2026-04-30 04:32:14 --> Language Class Initialized
ERROR - 2026-04-30 04:32:14 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:32:31 --> Config Class Initialized
INFO - 2026-04-30 04:32:31 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:32:32 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:32:32 --> Utf8 Class Initialized
INFO - 2026-04-30 04:32:32 --> URI Class Initialized
DEBUG - 2026-04-30 04:32:32 --> No URI present. Default controller set.
INFO - 2026-04-30 04:32:32 --> Router Class Initialized
INFO - 2026-04-30 04:32:32 --> Output Class Initialized
INFO - 2026-04-30 04:32:32 --> Security Class Initialized
DEBUG - 2026-04-30 04:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:32:32 --> Input Class Initialized
INFO - 2026-04-30 04:32:32 --> Language Class Initialized
INFO - 2026-04-30 04:32:32 --> Loader Class Initialized
INFO - 2026-04-30 04:32:32 --> Helper loaded: url_helper
INFO - 2026-04-30 04:32:32 --> Helper loaded: file_helper
INFO - 2026-04-30 04:32:32 --> Helper loaded: form_helper
INFO - 2026-04-30 04:32:32 --> Helper loaded: security_helper
INFO - 2026-04-30 04:32:32 --> Database Driver Class Initialized
INFO - 2026-04-30 04:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:32:32 --> Upload Class Initialized
INFO - 2026-04-30 04:32:32 --> Form Validation Class Initialized
INFO - 2026-04-30 04:32:32 --> Model "M_product" initialized
INFO - 2026-04-30 04:32:32 --> Model "M_settings" initialized
INFO - 2026-04-30 04:32:32 --> Controller Class Initialized
INFO - 2026-04-30 04:32:32 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:32:32 --> Final output sent to browser
DEBUG - 2026-04-30 04:32:32 --> Total execution time: 0.1067
INFO - 2026-04-30 04:32:32 --> Config Class Initialized
INFO - 2026-04-30 04:32:32 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:32:32 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:32:32 --> Utf8 Class Initialized
INFO - 2026-04-30 04:32:32 --> URI Class Initialized
INFO - 2026-04-30 04:32:32 --> Router Class Initialized
INFO - 2026-04-30 04:32:32 --> Output Class Initialized
INFO - 2026-04-30 04:32:32 --> Security Class Initialized
DEBUG - 2026-04-30 04:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:32:32 --> Input Class Initialized
INFO - 2026-04-30 04:32:32 --> Language Class Initialized
ERROR - 2026-04-30 04:32:32 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:32:32 --> Config Class Initialized
INFO - 2026-04-30 04:32:32 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:32:32 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:32:32 --> Utf8 Class Initialized
INFO - 2026-04-30 04:32:32 --> URI Class Initialized
DEBUG - 2026-04-30 04:32:32 --> No URI present. Default controller set.
INFO - 2026-04-30 04:32:32 --> Router Class Initialized
INFO - 2026-04-30 04:32:32 --> Output Class Initialized
INFO - 2026-04-30 04:32:32 --> Security Class Initialized
DEBUG - 2026-04-30 04:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:32:32 --> Input Class Initialized
INFO - 2026-04-30 04:32:32 --> Language Class Initialized
INFO - 2026-04-30 04:32:32 --> Loader Class Initialized
INFO - 2026-04-30 04:32:32 --> Helper loaded: url_helper
INFO - 2026-04-30 04:32:32 --> Helper loaded: file_helper
INFO - 2026-04-30 04:32:32 --> Helper loaded: form_helper
INFO - 2026-04-30 04:32:32 --> Helper loaded: security_helper
INFO - 2026-04-30 04:32:32 --> Database Driver Class Initialized
INFO - 2026-04-30 04:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:32:32 --> Upload Class Initialized
INFO - 2026-04-30 04:32:32 --> Form Validation Class Initialized
INFO - 2026-04-30 04:32:32 --> Model "M_product" initialized
INFO - 2026-04-30 04:32:32 --> Model "M_settings" initialized
INFO - 2026-04-30 04:32:32 --> Controller Class Initialized
INFO - 2026-04-30 04:32:32 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:32:32 --> Final output sent to browser
DEBUG - 2026-04-30 04:32:32 --> Total execution time: 0.0934
INFO - 2026-04-30 04:32:32 --> Config Class Initialized
INFO - 2026-04-30 04:32:32 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:32:32 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:32:32 --> Utf8 Class Initialized
INFO - 2026-04-30 04:32:32 --> URI Class Initialized
INFO - 2026-04-30 04:32:32 --> Router Class Initialized
INFO - 2026-04-30 04:32:32 --> Output Class Initialized
INFO - 2026-04-30 04:32:32 --> Security Class Initialized
DEBUG - 2026-04-30 04:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:32:32 --> Input Class Initialized
INFO - 2026-04-30 04:32:32 --> Language Class Initialized
ERROR - 2026-04-30 04:32:32 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:32:32 --> Config Class Initialized
INFO - 2026-04-30 04:32:32 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:32:32 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:32:32 --> Utf8 Class Initialized
INFO - 2026-04-30 04:32:32 --> URI Class Initialized
DEBUG - 2026-04-30 04:32:32 --> No URI present. Default controller set.
INFO - 2026-04-30 04:32:32 --> Router Class Initialized
INFO - 2026-04-30 04:32:32 --> Output Class Initialized
INFO - 2026-04-30 04:32:32 --> Security Class Initialized
DEBUG - 2026-04-30 04:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:32:32 --> Input Class Initialized
INFO - 2026-04-30 04:32:32 --> Language Class Initialized
INFO - 2026-04-30 04:32:32 --> Loader Class Initialized
INFO - 2026-04-30 04:32:32 --> Helper loaded: url_helper
INFO - 2026-04-30 04:32:32 --> Helper loaded: file_helper
INFO - 2026-04-30 04:32:32 --> Helper loaded: form_helper
INFO - 2026-04-30 04:32:32 --> Helper loaded: security_helper
INFO - 2026-04-30 04:32:32 --> Database Driver Class Initialized
INFO - 2026-04-30 04:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:32:32 --> Upload Class Initialized
INFO - 2026-04-30 04:32:32 --> Form Validation Class Initialized
INFO - 2026-04-30 04:32:32 --> Model "M_product" initialized
INFO - 2026-04-30 04:32:32 --> Model "M_settings" initialized
INFO - 2026-04-30 04:32:32 --> Controller Class Initialized
INFO - 2026-04-30 04:32:32 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:32:32 --> Final output sent to browser
DEBUG - 2026-04-30 04:32:32 --> Total execution time: 0.1016
INFO - 2026-04-30 04:32:33 --> Config Class Initialized
INFO - 2026-04-30 04:32:33 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:32:33 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:32:33 --> Utf8 Class Initialized
INFO - 2026-04-30 04:32:33 --> URI Class Initialized
INFO - 2026-04-30 04:32:33 --> Router Class Initialized
INFO - 2026-04-30 04:32:33 --> Output Class Initialized
INFO - 2026-04-30 04:32:33 --> Security Class Initialized
DEBUG - 2026-04-30 04:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:32:33 --> Input Class Initialized
INFO - 2026-04-30 04:32:33 --> Language Class Initialized
ERROR - 2026-04-30 04:32:33 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:32:33 --> Config Class Initialized
INFO - 2026-04-30 04:32:33 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:32:33 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:32:33 --> Utf8 Class Initialized
INFO - 2026-04-30 04:32:33 --> URI Class Initialized
DEBUG - 2026-04-30 04:32:33 --> No URI present. Default controller set.
INFO - 2026-04-30 04:32:33 --> Router Class Initialized
INFO - 2026-04-30 04:32:33 --> Output Class Initialized
INFO - 2026-04-30 04:32:33 --> Security Class Initialized
DEBUG - 2026-04-30 04:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:32:33 --> Input Class Initialized
INFO - 2026-04-30 04:32:33 --> Language Class Initialized
INFO - 2026-04-30 04:32:33 --> Loader Class Initialized
INFO - 2026-04-30 04:32:33 --> Helper loaded: url_helper
INFO - 2026-04-30 04:32:33 --> Helper loaded: file_helper
INFO - 2026-04-30 04:32:33 --> Helper loaded: form_helper
INFO - 2026-04-30 04:32:33 --> Helper loaded: security_helper
INFO - 2026-04-30 04:32:33 --> Database Driver Class Initialized
INFO - 2026-04-30 04:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:32:33 --> Upload Class Initialized
INFO - 2026-04-30 04:32:33 --> Form Validation Class Initialized
INFO - 2026-04-30 04:32:33 --> Model "M_product" initialized
INFO - 2026-04-30 04:32:33 --> Model "M_settings" initialized
INFO - 2026-04-30 04:32:33 --> Controller Class Initialized
INFO - 2026-04-30 04:32:33 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:32:33 --> Final output sent to browser
DEBUG - 2026-04-30 04:32:33 --> Total execution time: 0.0957
INFO - 2026-04-30 04:32:33 --> Config Class Initialized
INFO - 2026-04-30 04:32:33 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:32:33 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:32:33 --> Utf8 Class Initialized
INFO - 2026-04-30 04:32:33 --> URI Class Initialized
INFO - 2026-04-30 04:32:33 --> Router Class Initialized
INFO - 2026-04-30 04:32:33 --> Output Class Initialized
INFO - 2026-04-30 04:32:33 --> Security Class Initialized
DEBUG - 2026-04-30 04:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:32:33 --> Input Class Initialized
INFO - 2026-04-30 04:32:33 --> Language Class Initialized
ERROR - 2026-04-30 04:32:33 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:32:33 --> Config Class Initialized
INFO - 2026-04-30 04:32:33 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:32:33 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:32:33 --> Utf8 Class Initialized
INFO - 2026-04-30 04:32:33 --> URI Class Initialized
DEBUG - 2026-04-30 04:32:33 --> No URI present. Default controller set.
INFO - 2026-04-30 04:32:33 --> Router Class Initialized
INFO - 2026-04-30 04:32:33 --> Output Class Initialized
INFO - 2026-04-30 04:32:33 --> Security Class Initialized
DEBUG - 2026-04-30 04:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:32:33 --> Input Class Initialized
INFO - 2026-04-30 04:32:33 --> Language Class Initialized
INFO - 2026-04-30 04:32:33 --> Loader Class Initialized
INFO - 2026-04-30 04:32:33 --> Helper loaded: url_helper
INFO - 2026-04-30 04:32:33 --> Helper loaded: file_helper
INFO - 2026-04-30 04:32:33 --> Helper loaded: form_helper
INFO - 2026-04-30 04:32:33 --> Helper loaded: security_helper
INFO - 2026-04-30 04:32:33 --> Database Driver Class Initialized
INFO - 2026-04-30 04:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:32:33 --> Upload Class Initialized
INFO - 2026-04-30 04:32:33 --> Form Validation Class Initialized
INFO - 2026-04-30 04:32:33 --> Model "M_product" initialized
INFO - 2026-04-30 04:32:33 --> Model "M_settings" initialized
INFO - 2026-04-30 04:32:33 --> Controller Class Initialized
INFO - 2026-04-30 04:32:33 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:32:33 --> Final output sent to browser
DEBUG - 2026-04-30 04:32:33 --> Total execution time: 0.0963
INFO - 2026-04-30 04:32:33 --> Config Class Initialized
INFO - 2026-04-30 04:32:33 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:32:33 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:32:33 --> Utf8 Class Initialized
INFO - 2026-04-30 04:32:33 --> URI Class Initialized
INFO - 2026-04-30 04:32:33 --> Router Class Initialized
INFO - 2026-04-30 04:32:33 --> Output Class Initialized
INFO - 2026-04-30 04:32:33 --> Security Class Initialized
DEBUG - 2026-04-30 04:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:32:33 --> Input Class Initialized
INFO - 2026-04-30 04:32:33 --> Language Class Initialized
ERROR - 2026-04-30 04:32:33 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:34:11 --> Config Class Initialized
INFO - 2026-04-30 04:34:11 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:34:11 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:34:11 --> Utf8 Class Initialized
INFO - 2026-04-30 04:34:11 --> URI Class Initialized
DEBUG - 2026-04-30 04:34:11 --> No URI present. Default controller set.
INFO - 2026-04-30 04:34:11 --> Router Class Initialized
INFO - 2026-04-30 04:34:11 --> Output Class Initialized
INFO - 2026-04-30 04:34:11 --> Security Class Initialized
DEBUG - 2026-04-30 04:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:34:11 --> Input Class Initialized
INFO - 2026-04-30 04:34:11 --> Language Class Initialized
INFO - 2026-04-30 04:34:11 --> Loader Class Initialized
INFO - 2026-04-30 04:34:11 --> Helper loaded: url_helper
INFO - 2026-04-30 04:34:11 --> Helper loaded: file_helper
INFO - 2026-04-30 04:34:11 --> Helper loaded: form_helper
INFO - 2026-04-30 04:34:11 --> Helper loaded: security_helper
INFO - 2026-04-30 04:34:11 --> Database Driver Class Initialized
INFO - 2026-04-30 04:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:34:11 --> Upload Class Initialized
INFO - 2026-04-30 04:34:11 --> Form Validation Class Initialized
INFO - 2026-04-30 04:34:11 --> Model "M_product" initialized
INFO - 2026-04-30 04:34:11 --> Model "M_settings" initialized
INFO - 2026-04-30 04:34:11 --> Controller Class Initialized
INFO - 2026-04-30 04:34:11 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:34:11 --> Final output sent to browser
DEBUG - 2026-04-30 04:34:11 --> Total execution time: 0.1091
INFO - 2026-04-30 04:34:11 --> Config Class Initialized
INFO - 2026-04-30 04:34:11 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:34:11 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:34:11 --> Utf8 Class Initialized
INFO - 2026-04-30 04:34:11 --> URI Class Initialized
INFO - 2026-04-30 04:34:11 --> Router Class Initialized
INFO - 2026-04-30 04:34:11 --> Output Class Initialized
INFO - 2026-04-30 04:34:11 --> Security Class Initialized
DEBUG - 2026-04-30 04:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:34:11 --> Input Class Initialized
INFO - 2026-04-30 04:34:11 --> Language Class Initialized
ERROR - 2026-04-30 04:34:11 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:34:40 --> Config Class Initialized
INFO - 2026-04-30 04:34:40 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:34:40 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:34:40 --> Utf8 Class Initialized
INFO - 2026-04-30 04:34:40 --> URI Class Initialized
INFO - 2026-04-30 04:34:40 --> Router Class Initialized
INFO - 2026-04-30 04:34:40 --> Output Class Initialized
INFO - 2026-04-30 04:34:40 --> Security Class Initialized
DEBUG - 2026-04-30 04:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:34:40 --> Input Class Initialized
INFO - 2026-04-30 04:34:40 --> Language Class Initialized
INFO - 2026-04-30 04:34:40 --> Loader Class Initialized
INFO - 2026-04-30 04:34:40 --> Helper loaded: url_helper
INFO - 2026-04-30 04:34:40 --> Helper loaded: file_helper
INFO - 2026-04-30 04:34:40 --> Helper loaded: form_helper
INFO - 2026-04-30 04:34:40 --> Helper loaded: security_helper
INFO - 2026-04-30 04:34:40 --> Database Driver Class Initialized
INFO - 2026-04-30 04:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:34:40 --> Upload Class Initialized
INFO - 2026-04-30 04:34:40 --> Form Validation Class Initialized
INFO - 2026-04-30 04:34:40 --> Model "M_product" initialized
INFO - 2026-04-30 04:34:40 --> Model "M_settings" initialized
INFO - 2026-04-30 04:34:40 --> Controller Class Initialized
INFO - 2026-04-30 04:34:40 --> User Agent Class Initialized
INFO - 2026-04-30 04:34:40 --> Database Forge Class Initialized
INFO - 2026-04-30 04:34:40 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 04:34:40 --> File loaded: C:\laragon\www\macha\application\views\guest/cart.php
INFO - 2026-04-30 04:34:40 --> Final output sent to browser
DEBUG - 2026-04-30 04:34:40 --> Total execution time: 0.1018
INFO - 2026-04-30 04:34:44 --> Config Class Initialized
INFO - 2026-04-30 04:34:44 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:34:44 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:34:44 --> Utf8 Class Initialized
INFO - 2026-04-30 04:34:44 --> URI Class Initialized
DEBUG - 2026-04-30 04:34:44 --> No URI present. Default controller set.
INFO - 2026-04-30 04:34:44 --> Router Class Initialized
INFO - 2026-04-30 04:34:44 --> Output Class Initialized
INFO - 2026-04-30 04:34:44 --> Security Class Initialized
DEBUG - 2026-04-30 04:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:34:44 --> Input Class Initialized
INFO - 2026-04-30 04:34:44 --> Language Class Initialized
INFO - 2026-04-30 04:34:44 --> Loader Class Initialized
INFO - 2026-04-30 04:34:44 --> Helper loaded: url_helper
INFO - 2026-04-30 04:34:44 --> Helper loaded: file_helper
INFO - 2026-04-30 04:34:44 --> Helper loaded: form_helper
INFO - 2026-04-30 04:34:44 --> Helper loaded: security_helper
INFO - 2026-04-30 04:34:44 --> Database Driver Class Initialized
INFO - 2026-04-30 04:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:34:44 --> Upload Class Initialized
INFO - 2026-04-30 04:34:44 --> Form Validation Class Initialized
INFO - 2026-04-30 04:34:44 --> Model "M_product" initialized
INFO - 2026-04-30 04:34:44 --> Model "M_settings" initialized
INFO - 2026-04-30 04:34:44 --> Controller Class Initialized
INFO - 2026-04-30 04:34:44 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:34:44 --> Final output sent to browser
DEBUG - 2026-04-30 04:34:44 --> Total execution time: 0.0878
INFO - 2026-04-30 04:34:44 --> Config Class Initialized
INFO - 2026-04-30 04:34:44 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:34:44 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:34:44 --> Utf8 Class Initialized
INFO - 2026-04-30 04:34:44 --> URI Class Initialized
INFO - 2026-04-30 04:34:44 --> Router Class Initialized
INFO - 2026-04-30 04:34:44 --> Output Class Initialized
INFO - 2026-04-30 04:34:44 --> Security Class Initialized
DEBUG - 2026-04-30 04:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:34:44 --> Input Class Initialized
INFO - 2026-04-30 04:34:44 --> Language Class Initialized
ERROR - 2026-04-30 04:34:44 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:35:55 --> Config Class Initialized
INFO - 2026-04-30 04:35:55 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:35:55 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:35:55 --> Utf8 Class Initialized
INFO - 2026-04-30 04:35:55 --> URI Class Initialized
DEBUG - 2026-04-30 04:35:55 --> No URI present. Default controller set.
INFO - 2026-04-30 04:35:55 --> Router Class Initialized
INFO - 2026-04-30 04:35:55 --> Output Class Initialized
INFO - 2026-04-30 04:35:55 --> Security Class Initialized
DEBUG - 2026-04-30 04:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:35:55 --> Input Class Initialized
INFO - 2026-04-30 04:35:55 --> Language Class Initialized
INFO - 2026-04-30 04:35:55 --> Loader Class Initialized
INFO - 2026-04-30 04:35:55 --> Helper loaded: url_helper
INFO - 2026-04-30 04:35:55 --> Helper loaded: file_helper
INFO - 2026-04-30 04:35:55 --> Helper loaded: form_helper
INFO - 2026-04-30 04:35:55 --> Helper loaded: security_helper
INFO - 2026-04-30 04:35:55 --> Database Driver Class Initialized
INFO - 2026-04-30 04:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:35:55 --> Upload Class Initialized
INFO - 2026-04-30 04:35:55 --> Form Validation Class Initialized
INFO - 2026-04-30 04:35:55 --> Model "M_product" initialized
INFO - 2026-04-30 04:35:55 --> Model "M_settings" initialized
INFO - 2026-04-30 04:35:55 --> Controller Class Initialized
INFO - 2026-04-30 04:35:55 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:35:55 --> Final output sent to browser
DEBUG - 2026-04-30 04:35:55 --> Total execution time: 0.0939
INFO - 2026-04-30 04:35:55 --> Config Class Initialized
INFO - 2026-04-30 04:35:55 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:35:55 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:35:55 --> Utf8 Class Initialized
INFO - 2026-04-30 04:35:55 --> URI Class Initialized
INFO - 2026-04-30 04:35:55 --> Router Class Initialized
INFO - 2026-04-30 04:35:55 --> Output Class Initialized
INFO - 2026-04-30 04:35:55 --> Security Class Initialized
DEBUG - 2026-04-30 04:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:35:55 --> Input Class Initialized
INFO - 2026-04-30 04:35:55 --> Language Class Initialized
ERROR - 2026-04-30 04:35:55 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:36:00 --> Config Class Initialized
INFO - 2026-04-30 04:36:00 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:36:00 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:36:00 --> Utf8 Class Initialized
INFO - 2026-04-30 04:36:00 --> URI Class Initialized
INFO - 2026-04-30 04:36:00 --> Router Class Initialized
INFO - 2026-04-30 04:36:00 --> Output Class Initialized
INFO - 2026-04-30 04:36:00 --> Security Class Initialized
DEBUG - 2026-04-30 04:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:36:00 --> Input Class Initialized
INFO - 2026-04-30 04:36:00 --> Language Class Initialized
INFO - 2026-04-30 04:36:00 --> Loader Class Initialized
INFO - 2026-04-30 04:36:00 --> Helper loaded: url_helper
INFO - 2026-04-30 04:36:00 --> Helper loaded: file_helper
INFO - 2026-04-30 04:36:00 --> Helper loaded: form_helper
INFO - 2026-04-30 04:36:00 --> Helper loaded: security_helper
INFO - 2026-04-30 04:36:00 --> Database Driver Class Initialized
INFO - 2026-04-30 04:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:36:00 --> Upload Class Initialized
INFO - 2026-04-30 04:36:00 --> Form Validation Class Initialized
INFO - 2026-04-30 04:36:00 --> Model "M_product" initialized
INFO - 2026-04-30 04:36:00 --> Model "M_settings" initialized
INFO - 2026-04-30 04:36:00 --> Controller Class Initialized
INFO - 2026-04-30 04:36:00 --> User Agent Class Initialized
INFO - 2026-04-30 04:36:00 --> Database Forge Class Initialized
INFO - 2026-04-30 04:36:00 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 04:36:00 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-04-30 04:36:00 --> Final output sent to browser
DEBUG - 2026-04-30 04:36:00 --> Total execution time: 0.1007
INFO - 2026-04-30 04:36:03 --> Config Class Initialized
INFO - 2026-04-30 04:36:03 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:36:04 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:36:04 --> Utf8 Class Initialized
INFO - 2026-04-30 04:36:04 --> URI Class Initialized
DEBUG - 2026-04-30 04:36:04 --> No URI present. Default controller set.
INFO - 2026-04-30 04:36:04 --> Router Class Initialized
INFO - 2026-04-30 04:36:04 --> Output Class Initialized
INFO - 2026-04-30 04:36:04 --> Security Class Initialized
DEBUG - 2026-04-30 04:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:36:04 --> Input Class Initialized
INFO - 2026-04-30 04:36:04 --> Language Class Initialized
INFO - 2026-04-30 04:36:04 --> Loader Class Initialized
INFO - 2026-04-30 04:36:04 --> Helper loaded: url_helper
INFO - 2026-04-30 04:36:04 --> Helper loaded: file_helper
INFO - 2026-04-30 04:36:04 --> Helper loaded: form_helper
INFO - 2026-04-30 04:36:04 --> Helper loaded: security_helper
INFO - 2026-04-30 04:36:04 --> Database Driver Class Initialized
INFO - 2026-04-30 04:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:36:04 --> Upload Class Initialized
INFO - 2026-04-30 04:36:04 --> Form Validation Class Initialized
INFO - 2026-04-30 04:36:04 --> Model "M_product" initialized
INFO - 2026-04-30 04:36:04 --> Model "M_settings" initialized
INFO - 2026-04-30 04:36:04 --> Controller Class Initialized
INFO - 2026-04-30 04:36:04 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:36:04 --> Final output sent to browser
DEBUG - 2026-04-30 04:36:04 --> Total execution time: 0.0854
INFO - 2026-04-30 04:36:04 --> Config Class Initialized
INFO - 2026-04-30 04:36:04 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:36:04 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:36:04 --> Utf8 Class Initialized
INFO - 2026-04-30 04:36:04 --> URI Class Initialized
INFO - 2026-04-30 04:36:04 --> Router Class Initialized
INFO - 2026-04-30 04:36:04 --> Output Class Initialized
INFO - 2026-04-30 04:36:04 --> Security Class Initialized
DEBUG - 2026-04-30 04:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:36:04 --> Input Class Initialized
INFO - 2026-04-30 04:36:04 --> Language Class Initialized
ERROR - 2026-04-30 04:36:04 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:37:40 --> Config Class Initialized
INFO - 2026-04-30 04:37:40 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:37:40 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:37:40 --> Utf8 Class Initialized
INFO - 2026-04-30 04:37:40 --> URI Class Initialized
DEBUG - 2026-04-30 04:37:40 --> No URI present. Default controller set.
INFO - 2026-04-30 04:37:40 --> Router Class Initialized
INFO - 2026-04-30 04:37:40 --> Output Class Initialized
INFO - 2026-04-30 04:37:40 --> Security Class Initialized
DEBUG - 2026-04-30 04:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:37:40 --> Input Class Initialized
INFO - 2026-04-30 04:37:40 --> Language Class Initialized
INFO - 2026-04-30 04:37:40 --> Loader Class Initialized
INFO - 2026-04-30 04:37:40 --> Helper loaded: url_helper
INFO - 2026-04-30 04:37:40 --> Helper loaded: file_helper
INFO - 2026-04-30 04:37:40 --> Helper loaded: form_helper
INFO - 2026-04-30 04:37:40 --> Helper loaded: security_helper
INFO - 2026-04-30 04:37:40 --> Database Driver Class Initialized
INFO - 2026-04-30 04:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:37:41 --> Upload Class Initialized
INFO - 2026-04-30 04:37:41 --> Form Validation Class Initialized
INFO - 2026-04-30 04:37:41 --> Model "M_product" initialized
INFO - 2026-04-30 04:37:41 --> Model "M_settings" initialized
INFO - 2026-04-30 04:37:41 --> Controller Class Initialized
INFO - 2026-04-30 04:37:41 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:37:41 --> Final output sent to browser
DEBUG - 2026-04-30 04:37:41 --> Total execution time: 0.1212
INFO - 2026-04-30 04:37:41 --> Config Class Initialized
INFO - 2026-04-30 04:37:41 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:37:41 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:37:41 --> Utf8 Class Initialized
INFO - 2026-04-30 04:37:41 --> URI Class Initialized
INFO - 2026-04-30 04:37:41 --> Router Class Initialized
INFO - 2026-04-30 04:37:41 --> Output Class Initialized
INFO - 2026-04-30 04:37:41 --> Security Class Initialized
DEBUG - 2026-04-30 04:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:37:41 --> Input Class Initialized
INFO - 2026-04-30 04:37:41 --> Language Class Initialized
ERROR - 2026-04-30 04:37:41 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:37:52 --> Config Class Initialized
INFO - 2026-04-30 04:37:52 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:37:52 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:37:52 --> Utf8 Class Initialized
INFO - 2026-04-30 04:37:52 --> URI Class Initialized
INFO - 2026-04-30 04:37:52 --> Router Class Initialized
INFO - 2026-04-30 04:37:52 --> Output Class Initialized
INFO - 2026-04-30 04:37:52 --> Security Class Initialized
DEBUG - 2026-04-30 04:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:37:52 --> Input Class Initialized
INFO - 2026-04-30 04:37:52 --> Language Class Initialized
INFO - 2026-04-30 04:37:52 --> Loader Class Initialized
INFO - 2026-04-30 04:37:52 --> Helper loaded: url_helper
INFO - 2026-04-30 04:37:52 --> Helper loaded: file_helper
INFO - 2026-04-30 04:37:52 --> Helper loaded: form_helper
INFO - 2026-04-30 04:37:52 --> Helper loaded: security_helper
INFO - 2026-04-30 04:37:52 --> Database Driver Class Initialized
INFO - 2026-04-30 04:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:37:52 --> Upload Class Initialized
INFO - 2026-04-30 04:37:52 --> Form Validation Class Initialized
INFO - 2026-04-30 04:37:52 --> Model "M_product" initialized
INFO - 2026-04-30 04:37:52 --> Model "M_settings" initialized
INFO - 2026-04-30 04:37:52 --> Controller Class Initialized
INFO - 2026-04-30 04:37:52 --> User Agent Class Initialized
INFO - 2026-04-30 04:37:52 --> Database Forge Class Initialized
INFO - 2026-04-30 04:37:52 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 04:37:52 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-04-30 04:37:52 --> Final output sent to browser
DEBUG - 2026-04-30 04:37:52 --> Total execution time: 0.1056
INFO - 2026-04-30 04:37:58 --> Config Class Initialized
INFO - 2026-04-30 04:37:58 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:37:58 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:37:58 --> Utf8 Class Initialized
INFO - 2026-04-30 04:37:58 --> URI Class Initialized
DEBUG - 2026-04-30 04:37:58 --> No URI present. Default controller set.
INFO - 2026-04-30 04:37:58 --> Router Class Initialized
INFO - 2026-04-30 04:37:58 --> Output Class Initialized
INFO - 2026-04-30 04:37:58 --> Security Class Initialized
DEBUG - 2026-04-30 04:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:37:58 --> Input Class Initialized
INFO - 2026-04-30 04:37:58 --> Language Class Initialized
INFO - 2026-04-30 04:37:58 --> Loader Class Initialized
INFO - 2026-04-30 04:37:58 --> Helper loaded: url_helper
INFO - 2026-04-30 04:37:58 --> Helper loaded: file_helper
INFO - 2026-04-30 04:37:58 --> Helper loaded: form_helper
INFO - 2026-04-30 04:37:58 --> Helper loaded: security_helper
INFO - 2026-04-30 04:37:58 --> Database Driver Class Initialized
INFO - 2026-04-30 04:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:37:58 --> Upload Class Initialized
INFO - 2026-04-30 04:37:58 --> Form Validation Class Initialized
INFO - 2026-04-30 04:37:58 --> Model "M_product" initialized
INFO - 2026-04-30 04:37:58 --> Model "M_settings" initialized
INFO - 2026-04-30 04:37:58 --> Controller Class Initialized
INFO - 2026-04-30 04:37:58 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:37:58 --> Final output sent to browser
DEBUG - 2026-04-30 04:37:58 --> Total execution time: 0.0837
INFO - 2026-04-30 04:37:58 --> Config Class Initialized
INFO - 2026-04-30 04:37:58 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:37:58 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:37:58 --> Utf8 Class Initialized
INFO - 2026-04-30 04:37:58 --> URI Class Initialized
INFO - 2026-04-30 04:37:58 --> Router Class Initialized
INFO - 2026-04-30 04:37:58 --> Output Class Initialized
INFO - 2026-04-30 04:37:58 --> Security Class Initialized
DEBUG - 2026-04-30 04:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:37:58 --> Input Class Initialized
INFO - 2026-04-30 04:37:58 --> Language Class Initialized
ERROR - 2026-04-30 04:37:58 --> 404 Page Not Found: Assets/img
INFO - 2026-04-30 04:40:08 --> Config Class Initialized
INFO - 2026-04-30 04:40:08 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:40:08 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:40:08 --> Utf8 Class Initialized
INFO - 2026-04-30 04:40:08 --> URI Class Initialized
INFO - 2026-04-30 04:40:08 --> Router Class Initialized
INFO - 2026-04-30 04:40:08 --> Output Class Initialized
INFO - 2026-04-30 04:40:08 --> Security Class Initialized
DEBUG - 2026-04-30 04:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:40:08 --> Input Class Initialized
INFO - 2026-04-30 04:40:08 --> Language Class Initialized
INFO - 2026-04-30 04:40:08 --> Loader Class Initialized
INFO - 2026-04-30 04:40:08 --> Helper loaded: url_helper
INFO - 2026-04-30 04:40:08 --> Helper loaded: file_helper
INFO - 2026-04-30 04:40:08 --> Helper loaded: form_helper
INFO - 2026-04-30 04:40:08 --> Helper loaded: security_helper
INFO - 2026-04-30 04:40:08 --> Database Driver Class Initialized
INFO - 2026-04-30 04:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:40:08 --> Upload Class Initialized
INFO - 2026-04-30 04:40:08 --> Form Validation Class Initialized
INFO - 2026-04-30 04:40:08 --> Model "M_product" initialized
INFO - 2026-04-30 04:40:08 --> Model "M_settings" initialized
INFO - 2026-04-30 04:40:08 --> Controller Class Initialized
INFO - 2026-04-30 04:40:08 --> Model "M_sales" initialized
INFO - 2026-04-30 04:40:08 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 04:40:08 --> File loaded: C:\laragon\www\macha\application\views\user/order_history.php
INFO - 2026-04-30 04:40:08 --> Final output sent to browser
DEBUG - 2026-04-30 04:40:08 --> Total execution time: 0.0923
INFO - 2026-04-30 04:40:18 --> Config Class Initialized
INFO - 2026-04-30 04:40:18 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:40:18 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:40:18 --> Utf8 Class Initialized
INFO - 2026-04-30 04:40:18 --> URI Class Initialized
INFO - 2026-04-30 04:40:18 --> Router Class Initialized
INFO - 2026-04-30 04:40:18 --> Output Class Initialized
INFO - 2026-04-30 04:40:18 --> Security Class Initialized
DEBUG - 2026-04-30 04:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:40:18 --> Input Class Initialized
INFO - 2026-04-30 04:40:18 --> Language Class Initialized
INFO - 2026-04-30 04:40:18 --> Loader Class Initialized
INFO - 2026-04-30 04:40:18 --> Helper loaded: url_helper
INFO - 2026-04-30 04:40:18 --> Helper loaded: file_helper
INFO - 2026-04-30 04:40:18 --> Helper loaded: form_helper
INFO - 2026-04-30 04:40:18 --> Helper loaded: security_helper
INFO - 2026-04-30 04:40:18 --> Database Driver Class Initialized
INFO - 2026-04-30 04:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:40:18 --> Upload Class Initialized
INFO - 2026-04-30 04:40:18 --> Form Validation Class Initialized
INFO - 2026-04-30 04:40:18 --> Model "M_product" initialized
INFO - 2026-04-30 04:40:18 --> Model "M_settings" initialized
INFO - 2026-04-30 04:40:18 --> Controller Class Initialized
INFO - 2026-04-30 04:40:18 --> User Agent Class Initialized
INFO - 2026-04-30 04:40:18 --> Database Forge Class Initialized
INFO - 2026-04-30 04:40:18 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 04:40:18 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-04-30 04:40:18 --> Final output sent to browser
DEBUG - 2026-04-30 04:40:18 --> Total execution time: 0.1164
INFO - 2026-04-30 04:40:21 --> Config Class Initialized
INFO - 2026-04-30 04:40:21 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:40:21 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:40:21 --> Utf8 Class Initialized
INFO - 2026-04-30 04:40:21 --> URI Class Initialized
INFO - 2026-04-30 04:40:21 --> Router Class Initialized
INFO - 2026-04-30 04:40:21 --> Output Class Initialized
INFO - 2026-04-30 04:40:21 --> Security Class Initialized
DEBUG - 2026-04-30 04:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:40:21 --> Input Class Initialized
INFO - 2026-04-30 04:40:21 --> Language Class Initialized
INFO - 2026-04-30 04:40:21 --> Loader Class Initialized
INFO - 2026-04-30 04:40:21 --> Helper loaded: url_helper
INFO - 2026-04-30 04:40:21 --> Helper loaded: file_helper
INFO - 2026-04-30 04:40:21 --> Helper loaded: form_helper
INFO - 2026-04-30 04:40:21 --> Helper loaded: security_helper
INFO - 2026-04-30 04:40:21 --> Database Driver Class Initialized
INFO - 2026-04-30 04:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:40:21 --> Upload Class Initialized
INFO - 2026-04-30 04:40:21 --> Form Validation Class Initialized
INFO - 2026-04-30 04:40:21 --> Model "M_product" initialized
INFO - 2026-04-30 04:40:21 --> Model "M_settings" initialized
INFO - 2026-04-30 04:40:21 --> Controller Class Initialized
INFO - 2026-04-30 04:40:21 --> User Agent Class Initialized
INFO - 2026-04-30 04:40:21 --> Database Forge Class Initialized
INFO - 2026-04-30 04:40:21 --> Final output sent to browser
DEBUG - 2026-04-30 04:40:21 --> Total execution time: 0.0943
INFO - 2026-04-30 04:40:47 --> Config Class Initialized
INFO - 2026-04-30 04:40:47 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:40:47 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:40:47 --> Utf8 Class Initialized
INFO - 2026-04-30 04:40:47 --> URI Class Initialized
DEBUG - 2026-04-30 04:40:47 --> No URI present. Default controller set.
INFO - 2026-04-30 04:40:47 --> Router Class Initialized
INFO - 2026-04-30 04:40:47 --> Output Class Initialized
INFO - 2026-04-30 04:40:47 --> Security Class Initialized
DEBUG - 2026-04-30 04:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:40:47 --> Input Class Initialized
INFO - 2026-04-30 04:40:47 --> Language Class Initialized
INFO - 2026-04-30 04:40:47 --> Loader Class Initialized
INFO - 2026-04-30 04:40:47 --> Helper loaded: url_helper
INFO - 2026-04-30 04:40:47 --> Helper loaded: file_helper
INFO - 2026-04-30 04:40:47 --> Helper loaded: form_helper
INFO - 2026-04-30 04:40:47 --> Helper loaded: security_helper
INFO - 2026-04-30 04:40:47 --> Database Driver Class Initialized
INFO - 2026-04-30 04:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:40:47 --> Upload Class Initialized
INFO - 2026-04-30 04:40:47 --> Form Validation Class Initialized
INFO - 2026-04-30 04:40:47 --> Model "M_product" initialized
INFO - 2026-04-30 04:40:47 --> Model "M_settings" initialized
INFO - 2026-04-30 04:40:47 --> Controller Class Initialized
INFO - 2026-04-30 04:40:47 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:40:47 --> Final output sent to browser
DEBUG - 2026-04-30 04:40:47 --> Total execution time: 0.0918
INFO - 2026-04-30 04:40:56 --> Config Class Initialized
INFO - 2026-04-30 04:40:56 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:40:56 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:40:56 --> Utf8 Class Initialized
INFO - 2026-04-30 04:40:56 --> URI Class Initialized
DEBUG - 2026-04-30 04:40:56 --> No URI present. Default controller set.
INFO - 2026-04-30 04:40:56 --> Router Class Initialized
INFO - 2026-04-30 04:40:56 --> Output Class Initialized
INFO - 2026-04-30 04:40:56 --> Security Class Initialized
DEBUG - 2026-04-30 04:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:40:56 --> Input Class Initialized
INFO - 2026-04-30 04:40:56 --> Language Class Initialized
INFO - 2026-04-30 04:40:56 --> Loader Class Initialized
INFO - 2026-04-30 04:40:56 --> Helper loaded: url_helper
INFO - 2026-04-30 04:40:56 --> Helper loaded: file_helper
INFO - 2026-04-30 04:40:56 --> Helper loaded: form_helper
INFO - 2026-04-30 04:40:56 --> Helper loaded: security_helper
INFO - 2026-04-30 04:40:56 --> Database Driver Class Initialized
INFO - 2026-04-30 04:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:40:56 --> Upload Class Initialized
INFO - 2026-04-30 04:40:56 --> Form Validation Class Initialized
INFO - 2026-04-30 04:40:56 --> Model "M_product" initialized
INFO - 2026-04-30 04:40:56 --> Model "M_settings" initialized
INFO - 2026-04-30 04:40:56 --> Controller Class Initialized
INFO - 2026-04-30 04:40:56 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:40:56 --> Final output sent to browser
DEBUG - 2026-04-30 04:40:56 --> Total execution time: 0.0960
INFO - 2026-04-30 04:41:02 --> Config Class Initialized
INFO - 2026-04-30 04:41:02 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:41:02 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:41:02 --> Utf8 Class Initialized
INFO - 2026-04-30 04:41:02 --> URI Class Initialized
INFO - 2026-04-30 04:41:02 --> Router Class Initialized
INFO - 2026-04-30 04:41:02 --> Output Class Initialized
INFO - 2026-04-30 04:41:02 --> Security Class Initialized
DEBUG - 2026-04-30 04:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:41:02 --> Input Class Initialized
INFO - 2026-04-30 04:41:02 --> Language Class Initialized
INFO - 2026-04-30 04:41:02 --> Loader Class Initialized
INFO - 2026-04-30 04:41:02 --> Helper loaded: url_helper
INFO - 2026-04-30 04:41:02 --> Helper loaded: file_helper
INFO - 2026-04-30 04:41:02 --> Helper loaded: form_helper
INFO - 2026-04-30 04:41:02 --> Helper loaded: security_helper
INFO - 2026-04-30 04:41:02 --> Database Driver Class Initialized
INFO - 2026-04-30 04:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:41:02 --> Upload Class Initialized
INFO - 2026-04-30 04:41:02 --> Form Validation Class Initialized
INFO - 2026-04-30 04:41:02 --> Model "M_product" initialized
INFO - 2026-04-30 04:41:02 --> Model "M_settings" initialized
INFO - 2026-04-30 04:41:02 --> Controller Class Initialized
INFO - 2026-04-30 04:41:02 --> User Agent Class Initialized
INFO - 2026-04-30 04:41:02 --> Database Forge Class Initialized
INFO - 2026-04-30 04:41:02 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 04:41:02 --> File loaded: C:\laragon\www\macha\application\views\guest/cart.php
INFO - 2026-04-30 04:41:02 --> Final output sent to browser
DEBUG - 2026-04-30 04:41:02 --> Total execution time: 0.0933
INFO - 2026-04-30 04:41:51 --> Config Class Initialized
INFO - 2026-04-30 04:41:51 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:41:51 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:41:51 --> Utf8 Class Initialized
INFO - 2026-04-30 04:41:51 --> URI Class Initialized
DEBUG - 2026-04-30 04:41:51 --> No URI present. Default controller set.
INFO - 2026-04-30 04:41:51 --> Router Class Initialized
INFO - 2026-04-30 04:41:51 --> Output Class Initialized
INFO - 2026-04-30 04:41:51 --> Security Class Initialized
DEBUG - 2026-04-30 04:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:41:51 --> Input Class Initialized
INFO - 2026-04-30 04:41:51 --> Language Class Initialized
INFO - 2026-04-30 04:41:51 --> Loader Class Initialized
INFO - 2026-04-30 04:41:51 --> Helper loaded: url_helper
INFO - 2026-04-30 04:41:51 --> Helper loaded: file_helper
INFO - 2026-04-30 04:41:51 --> Helper loaded: form_helper
INFO - 2026-04-30 04:41:51 --> Helper loaded: security_helper
INFO - 2026-04-30 04:41:51 --> Database Driver Class Initialized
INFO - 2026-04-30 04:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:41:51 --> Upload Class Initialized
INFO - 2026-04-30 04:41:51 --> Form Validation Class Initialized
INFO - 2026-04-30 04:41:51 --> Model "M_product" initialized
INFO - 2026-04-30 04:41:51 --> Model "M_settings" initialized
INFO - 2026-04-30 04:41:51 --> Controller Class Initialized
INFO - 2026-04-30 04:41:51 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:41:51 --> Final output sent to browser
DEBUG - 2026-04-30 04:41:51 --> Total execution time: 0.0918
INFO - 2026-04-30 04:45:11 --> Config Class Initialized
INFO - 2026-04-30 04:45:11 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:45:11 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:45:11 --> Utf8 Class Initialized
INFO - 2026-04-30 04:45:11 --> URI Class Initialized
INFO - 2026-04-30 04:45:11 --> Router Class Initialized
INFO - 2026-04-30 04:45:11 --> Output Class Initialized
INFO - 2026-04-30 04:45:11 --> Security Class Initialized
DEBUG - 2026-04-30 04:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:45:11 --> Input Class Initialized
INFO - 2026-04-30 04:45:11 --> Language Class Initialized
INFO - 2026-04-30 04:45:11 --> Loader Class Initialized
INFO - 2026-04-30 04:45:11 --> Helper loaded: url_helper
INFO - 2026-04-30 04:45:11 --> Helper loaded: file_helper
INFO - 2026-04-30 04:45:11 --> Helper loaded: form_helper
INFO - 2026-04-30 04:45:11 --> Helper loaded: security_helper
INFO - 2026-04-30 04:45:11 --> Database Driver Class Initialized
INFO - 2026-04-30 04:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:45:11 --> Upload Class Initialized
INFO - 2026-04-30 04:45:11 --> Form Validation Class Initialized
INFO - 2026-04-30 04:45:11 --> Model "M_product" initialized
INFO - 2026-04-30 04:45:11 --> Model "M_settings" initialized
INFO - 2026-04-30 04:45:11 --> Controller Class Initialized
INFO - 2026-04-30 04:45:11 --> User Agent Class Initialized
INFO - 2026-04-30 04:45:11 --> Database Forge Class Initialized
INFO - 2026-04-30 04:45:11 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 04:45:11 --> File loaded: C:\laragon\www\macha\application\views\guest/cart.php
INFO - 2026-04-30 04:45:11 --> Final output sent to browser
DEBUG - 2026-04-30 04:45:11 --> Total execution time: 0.1242
INFO - 2026-04-30 04:45:17 --> Config Class Initialized
INFO - 2026-04-30 04:45:17 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:45:17 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:45:17 --> Utf8 Class Initialized
INFO - 2026-04-30 04:45:17 --> URI Class Initialized
DEBUG - 2026-04-30 04:45:17 --> No URI present. Default controller set.
INFO - 2026-04-30 04:45:17 --> Router Class Initialized
INFO - 2026-04-30 04:45:17 --> Output Class Initialized
INFO - 2026-04-30 04:45:17 --> Security Class Initialized
DEBUG - 2026-04-30 04:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:45:17 --> Input Class Initialized
INFO - 2026-04-30 04:45:17 --> Language Class Initialized
INFO - 2026-04-30 04:45:17 --> Loader Class Initialized
INFO - 2026-04-30 04:45:17 --> Helper loaded: url_helper
INFO - 2026-04-30 04:45:17 --> Helper loaded: file_helper
INFO - 2026-04-30 04:45:17 --> Helper loaded: form_helper
INFO - 2026-04-30 04:45:17 --> Helper loaded: security_helper
INFO - 2026-04-30 04:45:17 --> Database Driver Class Initialized
INFO - 2026-04-30 04:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:45:17 --> Upload Class Initialized
INFO - 2026-04-30 04:45:17 --> Form Validation Class Initialized
INFO - 2026-04-30 04:45:17 --> Model "M_product" initialized
INFO - 2026-04-30 04:45:17 --> Model "M_settings" initialized
INFO - 2026-04-30 04:45:17 --> Controller Class Initialized
INFO - 2026-04-30 04:45:17 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 04:45:17 --> Final output sent to browser
DEBUG - 2026-04-30 04:45:17 --> Total execution time: 0.0972
INFO - 2026-04-30 04:45:27 --> Config Class Initialized
INFO - 2026-04-30 04:45:27 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:45:27 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:45:27 --> Utf8 Class Initialized
INFO - 2026-04-30 04:45:27 --> URI Class Initialized
INFO - 2026-04-30 04:45:27 --> Router Class Initialized
INFO - 2026-04-30 04:45:27 --> Output Class Initialized
INFO - 2026-04-30 04:45:27 --> Security Class Initialized
DEBUG - 2026-04-30 04:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:45:27 --> Input Class Initialized
INFO - 2026-04-30 04:45:27 --> Language Class Initialized
INFO - 2026-04-30 04:45:27 --> Loader Class Initialized
INFO - 2026-04-30 04:45:27 --> Helper loaded: url_helper
INFO - 2026-04-30 04:45:27 --> Helper loaded: file_helper
INFO - 2026-04-30 04:45:27 --> Helper loaded: form_helper
INFO - 2026-04-30 04:45:27 --> Helper loaded: security_helper
INFO - 2026-04-30 04:45:27 --> Database Driver Class Initialized
INFO - 2026-04-30 04:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:45:27 --> Upload Class Initialized
INFO - 2026-04-30 04:45:27 --> Form Validation Class Initialized
INFO - 2026-04-30 04:45:27 --> Model "M_product" initialized
INFO - 2026-04-30 04:45:27 --> Model "M_settings" initialized
INFO - 2026-04-30 04:45:27 --> Controller Class Initialized
INFO - 2026-04-30 04:45:27 --> User Agent Class Initialized
INFO - 2026-04-30 04:45:27 --> Database Forge Class Initialized
INFO - 2026-04-30 04:45:27 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
ERROR - 2026-04-30 04:45:27 --> Severity: Warning --> Undefined property: CI_Loader::$cart C:\laragon\www\macha\application\views\guest\shop.php 900
ERROR - 2026-04-30 04:45:27 --> Severity: error --> Exception: Call to a member function total_items() on null C:\laragon\www\macha\application\views\guest\shop.php 900
INFO - 2026-04-30 04:46:25 --> Config Class Initialized
INFO - 2026-04-30 04:46:25 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:46:25 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:46:25 --> Utf8 Class Initialized
INFO - 2026-04-30 04:46:25 --> URI Class Initialized
INFO - 2026-04-30 04:46:25 --> Router Class Initialized
INFO - 2026-04-30 04:46:25 --> Output Class Initialized
INFO - 2026-04-30 04:46:25 --> Security Class Initialized
DEBUG - 2026-04-30 04:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:46:25 --> Input Class Initialized
INFO - 2026-04-30 04:46:25 --> Language Class Initialized
INFO - 2026-04-30 04:46:25 --> Loader Class Initialized
INFO - 2026-04-30 04:46:25 --> Helper loaded: url_helper
INFO - 2026-04-30 04:46:25 --> Helper loaded: file_helper
INFO - 2026-04-30 04:46:25 --> Helper loaded: form_helper
INFO - 2026-04-30 04:46:25 --> Helper loaded: security_helper
INFO - 2026-04-30 04:46:25 --> Database Driver Class Initialized
INFO - 2026-04-30 04:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:46:25 --> Upload Class Initialized
INFO - 2026-04-30 04:46:25 --> Form Validation Class Initialized
INFO - 2026-04-30 04:46:25 --> Model "M_product" initialized
INFO - 2026-04-30 04:46:25 --> Model "M_settings" initialized
INFO - 2026-04-30 04:46:25 --> Controller Class Initialized
INFO - 2026-04-30 04:46:25 --> User Agent Class Initialized
INFO - 2026-04-30 04:46:25 --> Database Forge Class Initialized
INFO - 2026-04-30 04:46:25 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 04:46:25 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-04-30 04:46:25 --> Final output sent to browser
DEBUG - 2026-04-30 04:46:25 --> Total execution time: 0.1082
INFO - 2026-04-30 04:47:43 --> Config Class Initialized
INFO - 2026-04-30 04:47:43 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:47:43 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:47:43 --> Utf8 Class Initialized
INFO - 2026-04-30 04:47:43 --> URI Class Initialized
INFO - 2026-04-30 04:47:43 --> Router Class Initialized
INFO - 2026-04-30 04:47:43 --> Output Class Initialized
INFO - 2026-04-30 04:47:43 --> Security Class Initialized
DEBUG - 2026-04-30 04:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:47:43 --> Input Class Initialized
INFO - 2026-04-30 04:47:43 --> Language Class Initialized
INFO - 2026-04-30 04:47:43 --> Loader Class Initialized
INFO - 2026-04-30 04:47:43 --> Helper loaded: url_helper
INFO - 2026-04-30 04:47:43 --> Helper loaded: file_helper
INFO - 2026-04-30 04:47:43 --> Helper loaded: form_helper
INFO - 2026-04-30 04:47:43 --> Helper loaded: security_helper
INFO - 2026-04-30 04:47:43 --> Database Driver Class Initialized
INFO - 2026-04-30 04:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:47:43 --> Upload Class Initialized
INFO - 2026-04-30 04:47:43 --> Form Validation Class Initialized
INFO - 2026-04-30 04:47:43 --> Model "M_product" initialized
INFO - 2026-04-30 04:47:43 --> Model "M_settings" initialized
INFO - 2026-04-30 04:47:43 --> Controller Class Initialized
INFO - 2026-04-30 04:47:43 --> User Agent Class Initialized
INFO - 2026-04-30 04:47:43 --> Database Forge Class Initialized
INFO - 2026-04-30 04:47:43 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 04:47:43 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-04-30 04:47:43 --> Final output sent to browser
DEBUG - 2026-04-30 04:47:43 --> Total execution time: 0.0974
INFO - 2026-04-30 04:47:51 --> Config Class Initialized
INFO - 2026-04-30 04:47:51 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:47:51 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:47:51 --> Utf8 Class Initialized
INFO - 2026-04-30 04:47:51 --> URI Class Initialized
INFO - 2026-04-30 04:47:51 --> Router Class Initialized
INFO - 2026-04-30 04:47:51 --> Output Class Initialized
INFO - 2026-04-30 04:47:51 --> Security Class Initialized
DEBUG - 2026-04-30 04:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:47:51 --> Input Class Initialized
INFO - 2026-04-30 04:47:51 --> Language Class Initialized
INFO - 2026-04-30 04:47:51 --> Loader Class Initialized
INFO - 2026-04-30 04:47:51 --> Helper loaded: url_helper
INFO - 2026-04-30 04:47:51 --> Helper loaded: file_helper
INFO - 2026-04-30 04:47:51 --> Helper loaded: form_helper
INFO - 2026-04-30 04:47:51 --> Helper loaded: security_helper
INFO - 2026-04-30 04:47:51 --> Database Driver Class Initialized
INFO - 2026-04-30 04:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:47:51 --> Upload Class Initialized
INFO - 2026-04-30 04:47:51 --> Form Validation Class Initialized
INFO - 2026-04-30 04:47:51 --> Model "M_product" initialized
INFO - 2026-04-30 04:47:51 --> Model "M_settings" initialized
INFO - 2026-04-30 04:47:51 --> Controller Class Initialized
INFO - 2026-04-30 04:47:51 --> User Agent Class Initialized
INFO - 2026-04-30 04:47:51 --> Database Forge Class Initialized
INFO - 2026-04-30 04:47:51 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 04:47:51 --> File loaded: C:\laragon\www\macha\application\views\guest/cart.php
INFO - 2026-04-30 04:47:51 --> Final output sent to browser
DEBUG - 2026-04-30 04:47:51 --> Total execution time: 0.0951
INFO - 2026-04-30 04:47:55 --> Config Class Initialized
INFO - 2026-04-30 04:47:55 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:47:55 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:47:55 --> Utf8 Class Initialized
INFO - 2026-04-30 04:47:55 --> URI Class Initialized
INFO - 2026-04-30 04:47:55 --> Router Class Initialized
INFO - 2026-04-30 04:47:55 --> Output Class Initialized
INFO - 2026-04-30 04:47:55 --> Security Class Initialized
DEBUG - 2026-04-30 04:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:47:55 --> Input Class Initialized
INFO - 2026-04-30 04:47:55 --> Language Class Initialized
INFO - 2026-04-30 04:47:55 --> Loader Class Initialized
INFO - 2026-04-30 04:47:55 --> Helper loaded: url_helper
INFO - 2026-04-30 04:47:55 --> Helper loaded: file_helper
INFO - 2026-04-30 04:47:55 --> Helper loaded: form_helper
INFO - 2026-04-30 04:47:55 --> Helper loaded: security_helper
INFO - 2026-04-30 04:47:55 --> Database Driver Class Initialized
INFO - 2026-04-30 04:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:47:55 --> Upload Class Initialized
INFO - 2026-04-30 04:47:55 --> Form Validation Class Initialized
INFO - 2026-04-30 04:47:55 --> Model "M_product" initialized
INFO - 2026-04-30 04:47:55 --> Model "M_settings" initialized
INFO - 2026-04-30 04:47:55 --> Controller Class Initialized
INFO - 2026-04-30 04:47:55 --> User Agent Class Initialized
INFO - 2026-04-30 04:47:55 --> Database Forge Class Initialized
INFO - 2026-04-30 04:47:55 --> Final output sent to browser
DEBUG - 2026-04-30 04:47:55 --> Total execution time: 0.0882
INFO - 2026-04-30 04:47:56 --> Config Class Initialized
INFO - 2026-04-30 04:47:56 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:47:56 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:47:56 --> Utf8 Class Initialized
INFO - 2026-04-30 04:47:56 --> URI Class Initialized
INFO - 2026-04-30 04:47:56 --> Router Class Initialized
INFO - 2026-04-30 04:47:56 --> Output Class Initialized
INFO - 2026-04-30 04:47:56 --> Security Class Initialized
DEBUG - 2026-04-30 04:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:47:56 --> Input Class Initialized
INFO - 2026-04-30 04:47:56 --> Language Class Initialized
INFO - 2026-04-30 04:47:56 --> Loader Class Initialized
INFO - 2026-04-30 04:47:56 --> Helper loaded: url_helper
INFO - 2026-04-30 04:47:56 --> Helper loaded: file_helper
INFO - 2026-04-30 04:47:56 --> Helper loaded: form_helper
INFO - 2026-04-30 04:47:56 --> Helper loaded: security_helper
INFO - 2026-04-30 04:47:56 --> Database Driver Class Initialized
INFO - 2026-04-30 04:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:47:56 --> Upload Class Initialized
INFO - 2026-04-30 04:47:56 --> Form Validation Class Initialized
INFO - 2026-04-30 04:47:56 --> Model "M_product" initialized
INFO - 2026-04-30 04:47:56 --> Model "M_settings" initialized
INFO - 2026-04-30 04:47:56 --> Controller Class Initialized
INFO - 2026-04-30 04:47:56 --> User Agent Class Initialized
INFO - 2026-04-30 04:47:56 --> Database Forge Class Initialized
INFO - 2026-04-30 04:47:56 --> Final output sent to browser
DEBUG - 2026-04-30 04:47:56 --> Total execution time: 0.1018
INFO - 2026-04-30 04:48:01 --> Config Class Initialized
INFO - 2026-04-30 04:48:01 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:48:01 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:48:01 --> Utf8 Class Initialized
INFO - 2026-04-30 04:48:01 --> URI Class Initialized
INFO - 2026-04-30 04:48:01 --> Router Class Initialized
INFO - 2026-04-30 04:48:01 --> Output Class Initialized
INFO - 2026-04-30 04:48:01 --> Security Class Initialized
DEBUG - 2026-04-30 04:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:48:01 --> Input Class Initialized
INFO - 2026-04-30 04:48:01 --> Language Class Initialized
INFO - 2026-04-30 04:48:01 --> Loader Class Initialized
INFO - 2026-04-30 04:48:01 --> Helper loaded: url_helper
INFO - 2026-04-30 04:48:01 --> Helper loaded: file_helper
INFO - 2026-04-30 04:48:01 --> Helper loaded: form_helper
INFO - 2026-04-30 04:48:01 --> Helper loaded: security_helper
INFO - 2026-04-30 04:48:01 --> Database Driver Class Initialized
INFO - 2026-04-30 04:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:48:01 --> Upload Class Initialized
INFO - 2026-04-30 04:48:01 --> Form Validation Class Initialized
INFO - 2026-04-30 04:48:01 --> Model "M_product" initialized
INFO - 2026-04-30 04:48:01 --> Model "M_settings" initialized
INFO - 2026-04-30 04:48:01 --> Controller Class Initialized
INFO - 2026-04-30 04:48:01 --> User Agent Class Initialized
INFO - 2026-04-30 04:48:01 --> Database Forge Class Initialized
INFO - 2026-04-30 04:48:01 --> Config Class Initialized
INFO - 2026-04-30 04:48:01 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:48:01 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:48:01 --> Utf8 Class Initialized
INFO - 2026-04-30 04:48:01 --> URI Class Initialized
INFO - 2026-04-30 04:48:01 --> Router Class Initialized
INFO - 2026-04-30 04:48:01 --> Output Class Initialized
INFO - 2026-04-30 04:48:01 --> Security Class Initialized
DEBUG - 2026-04-30 04:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:48:01 --> Input Class Initialized
INFO - 2026-04-30 04:48:01 --> Language Class Initialized
INFO - 2026-04-30 04:48:01 --> Loader Class Initialized
INFO - 2026-04-30 04:48:01 --> Helper loaded: url_helper
INFO - 2026-04-30 04:48:01 --> Helper loaded: file_helper
INFO - 2026-04-30 04:48:01 --> Helper loaded: form_helper
INFO - 2026-04-30 04:48:01 --> Helper loaded: security_helper
INFO - 2026-04-30 04:48:01 --> Database Driver Class Initialized
INFO - 2026-04-30 04:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:48:01 --> Upload Class Initialized
INFO - 2026-04-30 04:48:01 --> Form Validation Class Initialized
INFO - 2026-04-30 04:48:01 --> Model "M_product" initialized
INFO - 2026-04-30 04:48:01 --> Model "M_settings" initialized
INFO - 2026-04-30 04:48:01 --> Controller Class Initialized
INFO - 2026-04-30 04:48:01 --> User Agent Class Initialized
INFO - 2026-04-30 04:48:01 --> Database Forge Class Initialized
INFO - 2026-04-30 04:48:01 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 04:48:01 --> File loaded: C:\laragon\www\macha\application\views\guest/shop.php
INFO - 2026-04-30 04:48:01 --> Final output sent to browser
DEBUG - 2026-04-30 04:48:01 --> Total execution time: 0.1069
INFO - 2026-04-30 04:48:02 --> Config Class Initialized
INFO - 2026-04-30 04:48:02 --> Hooks Class Initialized
DEBUG - 2026-04-30 04:48:02 --> UTF-8 Support Enabled
INFO - 2026-04-30 04:48:02 --> Utf8 Class Initialized
INFO - 2026-04-30 04:48:02 --> URI Class Initialized
INFO - 2026-04-30 04:48:02 --> Router Class Initialized
INFO - 2026-04-30 04:48:02 --> Output Class Initialized
INFO - 2026-04-30 04:48:02 --> Security Class Initialized
DEBUG - 2026-04-30 04:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 04:48:02 --> Input Class Initialized
INFO - 2026-04-30 04:48:02 --> Language Class Initialized
INFO - 2026-04-30 04:48:02 --> Loader Class Initialized
INFO - 2026-04-30 04:48:02 --> Helper loaded: url_helper
INFO - 2026-04-30 04:48:02 --> Helper loaded: file_helper
INFO - 2026-04-30 04:48:02 --> Helper loaded: form_helper
INFO - 2026-04-30 04:48:02 --> Helper loaded: security_helper
INFO - 2026-04-30 04:48:02 --> Database Driver Class Initialized
INFO - 2026-04-30 04:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 04:48:02 --> Upload Class Initialized
INFO - 2026-04-30 04:48:02 --> Form Validation Class Initialized
INFO - 2026-04-30 04:48:02 --> Model "M_product" initialized
INFO - 2026-04-30 04:48:02 --> Model "M_settings" initialized
INFO - 2026-04-30 04:48:02 --> Controller Class Initialized
INFO - 2026-04-30 04:48:02 --> User Agent Class Initialized
INFO - 2026-04-30 04:48:02 --> Database Forge Class Initialized
INFO - 2026-04-30 04:48:02 --> File loaded: C:\laragon\www\macha\application\views\layout/navbar.php
INFO - 2026-04-30 04:48:02 --> File loaded: C:\laragon\www\macha\application\views\guest/cart.php
INFO - 2026-04-30 04:48:02 --> Final output sent to browser
DEBUG - 2026-04-30 04:48:02 --> Total execution time: 0.0976
INFO - 2026-04-30 08:12:48 --> Config Class Initialized
INFO - 2026-04-30 08:12:48 --> Hooks Class Initialized
DEBUG - 2026-04-30 08:12:48 --> UTF-8 Support Enabled
INFO - 2026-04-30 08:12:48 --> Utf8 Class Initialized
INFO - 2026-04-30 08:12:48 --> URI Class Initialized
DEBUG - 2026-04-30 08:12:48 --> No URI present. Default controller set.
INFO - 2026-04-30 08:12:48 --> Router Class Initialized
INFO - 2026-04-30 08:12:48 --> Output Class Initialized
INFO - 2026-04-30 08:12:48 --> Security Class Initialized
DEBUG - 2026-04-30 08:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 08:12:48 --> Input Class Initialized
INFO - 2026-04-30 08:12:48 --> Language Class Initialized
INFO - 2026-04-30 08:12:48 --> Loader Class Initialized
INFO - 2026-04-30 08:12:48 --> Helper loaded: url_helper
INFO - 2026-04-30 08:12:48 --> Helper loaded: file_helper
INFO - 2026-04-30 08:12:48 --> Helper loaded: form_helper
INFO - 2026-04-30 08:12:48 --> Helper loaded: security_helper
INFO - 2026-04-30 08:12:48 --> Database Driver Class Initialized
INFO - 2026-04-30 08:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 08:12:48 --> Upload Class Initialized
INFO - 2026-04-30 08:12:48 --> Form Validation Class Initialized
INFO - 2026-04-30 08:12:48 --> Model "M_product" initialized
INFO - 2026-04-30 08:12:48 --> Model "M_settings" initialized
INFO - 2026-04-30 08:12:48 --> Controller Class Initialized
INFO - 2026-04-30 08:12:48 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 08:12:48 --> Final output sent to browser
DEBUG - 2026-04-30 08:12:48 --> Total execution time: 0.5306
INFO - 2026-04-30 08:41:50 --> Config Class Initialized
INFO - 2026-04-30 08:41:50 --> Hooks Class Initialized
DEBUG - 2026-04-30 08:41:50 --> UTF-8 Support Enabled
INFO - 2026-04-30 08:41:50 --> Utf8 Class Initialized
INFO - 2026-04-30 08:41:50 --> URI Class Initialized
DEBUG - 2026-04-30 08:41:50 --> No URI present. Default controller set.
INFO - 2026-04-30 08:41:50 --> Router Class Initialized
INFO - 2026-04-30 08:41:50 --> Output Class Initialized
INFO - 2026-04-30 08:41:50 --> Security Class Initialized
DEBUG - 2026-04-30 08:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 08:41:50 --> Input Class Initialized
INFO - 2026-04-30 08:41:50 --> Language Class Initialized
INFO - 2026-04-30 08:41:50 --> Loader Class Initialized
INFO - 2026-04-30 08:41:50 --> Helper loaded: url_helper
INFO - 2026-04-30 08:41:50 --> Helper loaded: file_helper
INFO - 2026-04-30 08:41:50 --> Helper loaded: form_helper
INFO - 2026-04-30 08:41:50 --> Helper loaded: security_helper
INFO - 2026-04-30 08:41:50 --> Database Driver Class Initialized
INFO - 2026-04-30 08:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 08:41:50 --> Upload Class Initialized
INFO - 2026-04-30 08:41:50 --> Form Validation Class Initialized
INFO - 2026-04-30 08:41:50 --> Model "M_product" initialized
INFO - 2026-04-30 08:41:50 --> Model "M_settings" initialized
INFO - 2026-04-30 08:41:50 --> Controller Class Initialized
INFO - 2026-04-30 08:41:50 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 08:41:50 --> Final output sent to browser
DEBUG - 2026-04-30 08:41:50 --> Total execution time: 0.1095
INFO - 2026-04-30 08:42:31 --> Config Class Initialized
INFO - 2026-04-30 08:42:31 --> Hooks Class Initialized
DEBUG - 2026-04-30 08:42:31 --> UTF-8 Support Enabled
INFO - 2026-04-30 08:42:31 --> Utf8 Class Initialized
INFO - 2026-04-30 08:42:31 --> URI Class Initialized
DEBUG - 2026-04-30 08:42:31 --> No URI present. Default controller set.
INFO - 2026-04-30 08:42:31 --> Router Class Initialized
INFO - 2026-04-30 08:42:31 --> Output Class Initialized
INFO - 2026-04-30 08:42:31 --> Security Class Initialized
DEBUG - 2026-04-30 08:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 08:42:31 --> Input Class Initialized
INFO - 2026-04-30 08:42:31 --> Language Class Initialized
INFO - 2026-04-30 08:42:31 --> Loader Class Initialized
INFO - 2026-04-30 08:42:31 --> Helper loaded: url_helper
INFO - 2026-04-30 08:42:31 --> Helper loaded: file_helper
INFO - 2026-04-30 08:42:31 --> Helper loaded: form_helper
INFO - 2026-04-30 08:42:31 --> Helper loaded: security_helper
INFO - 2026-04-30 08:42:31 --> Database Driver Class Initialized
INFO - 2026-04-30 08:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 08:42:31 --> Upload Class Initialized
INFO - 2026-04-30 08:42:31 --> Form Validation Class Initialized
INFO - 2026-04-30 08:42:31 --> Model "M_product" initialized
INFO - 2026-04-30 08:42:31 --> Model "M_settings" initialized
INFO - 2026-04-30 08:42:31 --> Controller Class Initialized
INFO - 2026-04-30 08:42:31 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 08:42:31 --> Final output sent to browser
DEBUG - 2026-04-30 08:42:31 --> Total execution time: 0.1059
INFO - 2026-04-30 08:42:39 --> Config Class Initialized
INFO - 2026-04-30 08:42:39 --> Hooks Class Initialized
DEBUG - 2026-04-30 08:42:39 --> UTF-8 Support Enabled
INFO - 2026-04-30 08:42:39 --> Utf8 Class Initialized
INFO - 2026-04-30 08:42:39 --> URI Class Initialized
INFO - 2026-04-30 08:42:39 --> Router Class Initialized
INFO - 2026-04-30 08:42:39 --> Output Class Initialized
INFO - 2026-04-30 08:42:39 --> Security Class Initialized
DEBUG - 2026-04-30 08:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 08:42:39 --> Input Class Initialized
INFO - 2026-04-30 08:42:39 --> Language Class Initialized
INFO - 2026-04-30 08:42:39 --> Loader Class Initialized
INFO - 2026-04-30 08:42:39 --> Helper loaded: url_helper
INFO - 2026-04-30 08:42:39 --> Helper loaded: file_helper
INFO - 2026-04-30 08:42:39 --> Helper loaded: form_helper
INFO - 2026-04-30 08:42:39 --> Helper loaded: security_helper
INFO - 2026-04-30 08:42:39 --> Database Driver Class Initialized
INFO - 2026-04-30 08:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 08:42:39 --> Upload Class Initialized
INFO - 2026-04-30 08:42:39 --> Form Validation Class Initialized
INFO - 2026-04-30 08:42:39 --> Model "M_product" initialized
INFO - 2026-04-30 08:42:39 --> Model "M_settings" initialized
INFO - 2026-04-30 08:42:39 --> Controller Class Initialized
DEBUG - 2026-04-30 08:42:39 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-30 08:42:39 --> File loaded: C:\laragon\www\macha\application\views\auth/login.php
INFO - 2026-04-30 08:42:39 --> Final output sent to browser
DEBUG - 2026-04-30 08:42:39 --> Total execution time: 0.1595
INFO - 2026-04-30 08:42:44 --> Config Class Initialized
INFO - 2026-04-30 08:42:44 --> Hooks Class Initialized
DEBUG - 2026-04-30 08:42:44 --> UTF-8 Support Enabled
INFO - 2026-04-30 08:42:44 --> Utf8 Class Initialized
INFO - 2026-04-30 08:42:44 --> URI Class Initialized
INFO - 2026-04-30 08:42:44 --> Router Class Initialized
INFO - 2026-04-30 08:42:44 --> Output Class Initialized
INFO - 2026-04-30 08:42:44 --> Security Class Initialized
DEBUG - 2026-04-30 08:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 08:42:44 --> Input Class Initialized
INFO - 2026-04-30 08:42:44 --> Language Class Initialized
INFO - 2026-04-30 08:42:44 --> Loader Class Initialized
INFO - 2026-04-30 08:42:44 --> Helper loaded: url_helper
INFO - 2026-04-30 08:42:44 --> Helper loaded: file_helper
INFO - 2026-04-30 08:42:44 --> Helper loaded: form_helper
INFO - 2026-04-30 08:42:44 --> Helper loaded: security_helper
INFO - 2026-04-30 08:42:44 --> Database Driver Class Initialized
INFO - 2026-04-30 08:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 08:42:44 --> Upload Class Initialized
INFO - 2026-04-30 08:42:44 --> Form Validation Class Initialized
INFO - 2026-04-30 08:42:44 --> Model "M_product" initialized
INFO - 2026-04-30 08:42:44 --> Model "M_settings" initialized
INFO - 2026-04-30 08:42:44 --> Controller Class Initialized
DEBUG - 2026-04-30 08:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-30 08:42:44 --> Config Class Initialized
INFO - 2026-04-30 08:42:44 --> Hooks Class Initialized
DEBUG - 2026-04-30 08:42:44 --> UTF-8 Support Enabled
INFO - 2026-04-30 08:42:44 --> Utf8 Class Initialized
INFO - 2026-04-30 08:42:44 --> URI Class Initialized
INFO - 2026-04-30 08:42:44 --> Router Class Initialized
INFO - 2026-04-30 08:42:44 --> Output Class Initialized
INFO - 2026-04-30 08:42:44 --> Security Class Initialized
DEBUG - 2026-04-30 08:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 08:42:44 --> Input Class Initialized
INFO - 2026-04-30 08:42:44 --> Language Class Initialized
INFO - 2026-04-30 08:42:44 --> Loader Class Initialized
INFO - 2026-04-30 08:42:44 --> Helper loaded: url_helper
INFO - 2026-04-30 08:42:44 --> Helper loaded: file_helper
INFO - 2026-04-30 08:42:44 --> Helper loaded: form_helper
INFO - 2026-04-30 08:42:44 --> Helper loaded: security_helper
INFO - 2026-04-30 08:42:44 --> Database Driver Class Initialized
INFO - 2026-04-30 08:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 08:42:44 --> Upload Class Initialized
INFO - 2026-04-30 08:42:44 --> Form Validation Class Initialized
INFO - 2026-04-30 08:42:44 --> Model "M_product" initialized
INFO - 2026-04-30 08:42:44 --> Model "M_settings" initialized
INFO - 2026-04-30 08:42:44 --> Controller Class Initialized
INFO - 2026-04-30 08:42:44 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-30 08:42:44 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-30 08:42:44 --> Final output sent to browser
DEBUG - 2026-04-30 08:42:44 --> Total execution time: 0.3930
INFO - 2026-04-30 08:42:47 --> Config Class Initialized
INFO - 2026-04-30 08:42:47 --> Hooks Class Initialized
DEBUG - 2026-04-30 08:42:47 --> UTF-8 Support Enabled
INFO - 2026-04-30 08:42:47 --> Utf8 Class Initialized
INFO - 2026-04-30 08:42:47 --> URI Class Initialized
INFO - 2026-04-30 08:42:47 --> Router Class Initialized
INFO - 2026-04-30 08:42:47 --> Output Class Initialized
INFO - 2026-04-30 08:42:47 --> Security Class Initialized
DEBUG - 2026-04-30 08:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 08:42:47 --> Input Class Initialized
INFO - 2026-04-30 08:42:47 --> Language Class Initialized
INFO - 2026-04-30 08:42:47 --> Loader Class Initialized
INFO - 2026-04-30 08:42:47 --> Helper loaded: url_helper
INFO - 2026-04-30 08:42:47 --> Helper loaded: file_helper
INFO - 2026-04-30 08:42:47 --> Helper loaded: form_helper
INFO - 2026-04-30 08:42:47 --> Helper loaded: security_helper
INFO - 2026-04-30 08:42:47 --> Database Driver Class Initialized
INFO - 2026-04-30 08:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 08:42:47 --> Upload Class Initialized
INFO - 2026-04-30 08:42:47 --> Form Validation Class Initialized
INFO - 2026-04-30 08:42:47 --> Model "M_product" initialized
INFO - 2026-04-30 08:42:47 --> Model "M_settings" initialized
INFO - 2026-04-30 08:42:47 --> Controller Class Initialized
INFO - 2026-04-30 08:42:47 --> Model "M_sales" initialized
INFO - 2026-04-30 08:42:47 --> File loaded: C:\laragon\www\macha\application\views\admin/order_list.php
INFO - 2026-04-30 08:42:47 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-30 08:42:47 --> Final output sent to browser
DEBUG - 2026-04-30 08:42:47 --> Total execution time: 0.3018
INFO - 2026-04-30 08:42:49 --> Config Class Initialized
INFO - 2026-04-30 08:42:49 --> Hooks Class Initialized
DEBUG - 2026-04-30 08:42:49 --> UTF-8 Support Enabled
INFO - 2026-04-30 08:42:49 --> Utf8 Class Initialized
INFO - 2026-04-30 08:42:49 --> URI Class Initialized
INFO - 2026-04-30 08:42:49 --> Router Class Initialized
INFO - 2026-04-30 08:42:49 --> Output Class Initialized
INFO - 2026-04-30 08:42:49 --> Security Class Initialized
DEBUG - 2026-04-30 08:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 08:42:49 --> Input Class Initialized
INFO - 2026-04-30 08:42:49 --> Language Class Initialized
INFO - 2026-04-30 08:42:49 --> Loader Class Initialized
INFO - 2026-04-30 08:42:49 --> Helper loaded: url_helper
INFO - 2026-04-30 08:42:49 --> Helper loaded: file_helper
INFO - 2026-04-30 08:42:49 --> Helper loaded: form_helper
INFO - 2026-04-30 08:42:49 --> Helper loaded: security_helper
INFO - 2026-04-30 08:42:49 --> Database Driver Class Initialized
INFO - 2026-04-30 08:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 08:42:49 --> Upload Class Initialized
INFO - 2026-04-30 08:42:49 --> Form Validation Class Initialized
INFO - 2026-04-30 08:42:49 --> Model "M_product" initialized
INFO - 2026-04-30 08:42:49 --> Model "M_settings" initialized
INFO - 2026-04-30 08:42:49 --> Controller Class Initialized
INFO - 2026-04-30 08:42:49 --> Model "M_sales" initialized
INFO - 2026-04-30 08:42:49 --> File loaded: C:\laragon\www\macha\application\views\admin/order_list.php
INFO - 2026-04-30 08:42:49 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-30 08:42:49 --> Final output sent to browser
DEBUG - 2026-04-30 08:42:49 --> Total execution time: 0.0877
INFO - 2026-04-30 09:02:18 --> Config Class Initialized
INFO - 2026-04-30 09:02:18 --> Hooks Class Initialized
DEBUG - 2026-04-30 09:02:18 --> UTF-8 Support Enabled
INFO - 2026-04-30 09:02:18 --> Utf8 Class Initialized
INFO - 2026-04-30 09:02:18 --> URI Class Initialized
DEBUG - 2026-04-30 09:02:18 --> No URI present. Default controller set.
INFO - 2026-04-30 09:02:18 --> Router Class Initialized
INFO - 2026-04-30 09:02:18 --> Output Class Initialized
INFO - 2026-04-30 09:02:18 --> Security Class Initialized
DEBUG - 2026-04-30 09:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 09:02:18 --> Input Class Initialized
INFO - 2026-04-30 09:02:18 --> Language Class Initialized
INFO - 2026-04-30 09:02:18 --> Loader Class Initialized
INFO - 2026-04-30 09:02:18 --> Helper loaded: url_helper
INFO - 2026-04-30 09:02:18 --> Helper loaded: file_helper
INFO - 2026-04-30 09:02:18 --> Helper loaded: form_helper
INFO - 2026-04-30 09:02:18 --> Helper loaded: security_helper
INFO - 2026-04-30 09:02:18 --> Database Driver Class Initialized
INFO - 2026-04-30 09:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 09:02:18 --> Upload Class Initialized
INFO - 2026-04-30 09:02:18 --> Form Validation Class Initialized
INFO - 2026-04-30 09:02:18 --> Model "M_product" initialized
INFO - 2026-04-30 09:02:18 --> Model "M_settings" initialized
INFO - 2026-04-30 09:02:18 --> Controller Class Initialized
INFO - 2026-04-30 09:02:18 --> File loaded: C:\laragon\www\macha\application\views\guest/home.php
INFO - 2026-04-30 09:02:18 --> Final output sent to browser
DEBUG - 2026-04-30 09:02:18 --> Total execution time: 0.1012
INFO - 2026-04-30 09:02:25 --> Config Class Initialized
INFO - 2026-04-30 09:02:25 --> Hooks Class Initialized
DEBUG - 2026-04-30 09:02:25 --> UTF-8 Support Enabled
INFO - 2026-04-30 09:02:25 --> Utf8 Class Initialized
INFO - 2026-04-30 09:02:25 --> URI Class Initialized
INFO - 2026-04-30 09:02:25 --> Router Class Initialized
INFO - 2026-04-30 09:02:25 --> Output Class Initialized
INFO - 2026-04-30 09:02:25 --> Security Class Initialized
DEBUG - 2026-04-30 09:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 09:02:25 --> Input Class Initialized
INFO - 2026-04-30 09:02:25 --> Language Class Initialized
INFO - 2026-04-30 09:02:25 --> Loader Class Initialized
INFO - 2026-04-30 09:02:25 --> Helper loaded: url_helper
INFO - 2026-04-30 09:02:25 --> Helper loaded: file_helper
INFO - 2026-04-30 09:02:25 --> Helper loaded: form_helper
INFO - 2026-04-30 09:02:25 --> Helper loaded: security_helper
INFO - 2026-04-30 09:02:25 --> Database Driver Class Initialized
INFO - 2026-04-30 09:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 09:02:26 --> Upload Class Initialized
INFO - 2026-04-30 09:02:26 --> Form Validation Class Initialized
INFO - 2026-04-30 09:02:26 --> Model "M_product" initialized
INFO - 2026-04-30 09:02:26 --> Model "M_settings" initialized
INFO - 2026-04-30 09:02:26 --> Controller Class Initialized
INFO - 2026-04-30 09:02:26 --> File loaded: C:\laragon\www\macha\application\views\dashboard.php
INFO - 2026-04-30 09:02:26 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-30 09:02:26 --> Final output sent to browser
DEBUG - 2026-04-30 09:02:26 --> Total execution time: 0.1542
INFO - 2026-04-30 09:02:28 --> Config Class Initialized
INFO - 2026-04-30 09:02:28 --> Hooks Class Initialized
DEBUG - 2026-04-30 09:02:28 --> UTF-8 Support Enabled
INFO - 2026-04-30 09:02:28 --> Utf8 Class Initialized
INFO - 2026-04-30 09:02:28 --> URI Class Initialized
INFO - 2026-04-30 09:02:28 --> Router Class Initialized
INFO - 2026-04-30 09:02:28 --> Output Class Initialized
INFO - 2026-04-30 09:02:28 --> Security Class Initialized
DEBUG - 2026-04-30 09:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 09:02:28 --> Input Class Initialized
INFO - 2026-04-30 09:02:28 --> Language Class Initialized
INFO - 2026-04-30 09:02:28 --> Loader Class Initialized
INFO - 2026-04-30 09:02:28 --> Helper loaded: url_helper
INFO - 2026-04-30 09:02:28 --> Helper loaded: file_helper
INFO - 2026-04-30 09:02:28 --> Helper loaded: form_helper
INFO - 2026-04-30 09:02:28 --> Helper loaded: security_helper
INFO - 2026-04-30 09:02:28 --> Database Driver Class Initialized
INFO - 2026-04-30 09:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 09:02:28 --> Upload Class Initialized
INFO - 2026-04-30 09:02:28 --> Form Validation Class Initialized
INFO - 2026-04-30 09:02:28 --> Model "M_product" initialized
INFO - 2026-04-30 09:02:28 --> Model "M_settings" initialized
INFO - 2026-04-30 09:02:28 --> Controller Class Initialized
INFO - 2026-04-30 09:02:29 --> File loaded: C:\laragon\www\macha\application\views\admin/settings.php
INFO - 2026-04-30 09:02:29 --> File loaded: C:\laragon\www\macha\application\views\layout/wrapper.php
INFO - 2026-04-30 09:02:29 --> Final output sent to browser
DEBUG - 2026-04-30 09:02:29 --> Total execution time: 0.2156
INFO - 2026-04-30 09:02:35 --> Config Class Initialized
INFO - 2026-04-30 09:02:35 --> Hooks Class Initialized
DEBUG - 2026-04-30 09:02:35 --> UTF-8 Support Enabled
INFO - 2026-04-30 09:02:35 --> Utf8 Class Initialized
INFO - 2026-04-30 09:02:35 --> URI Class Initialized
INFO - 2026-04-30 09:02:35 --> Router Class Initialized
INFO - 2026-04-30 09:02:35 --> Output Class Initialized
INFO - 2026-04-30 09:02:35 --> Security Class Initialized
DEBUG - 2026-04-30 09:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 09:02:35 --> Input Class Initialized
INFO - 2026-04-30 09:02:35 --> Language Class Initialized
INFO - 2026-04-30 09:02:35 --> Loader Class Initialized
INFO - 2026-04-30 09:02:35 --> Helper loaded: url_helper
INFO - 2026-04-30 09:02:35 --> Helper loaded: file_helper
INFO - 2026-04-30 09:02:35 --> Helper loaded: form_helper
INFO - 2026-04-30 09:02:35 --> Helper loaded: security_helper
INFO - 2026-04-30 09:02:35 --> Database Driver Class Initialized
INFO - 2026-04-30 09:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 09:02:35 --> Upload Class Initialized
INFO - 2026-04-30 09:02:35 --> Form Validation Class Initialized
INFO - 2026-04-30 09:02:35 --> Model "M_product" initialized
INFO - 2026-04-30 09:02:35 --> Model "M_settings" initialized
INFO - 2026-04-30 09:02:35 --> Controller Class Initialized
DEBUG - 2026-04-30 09:02:35 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-30 09:02:35 --> Config Class Initialized
INFO - 2026-04-30 09:02:35 --> Hooks Class Initialized
DEBUG - 2026-04-30 09:02:35 --> UTF-8 Support Enabled
INFO - 2026-04-30 09:02:35 --> Utf8 Class Initialized
INFO - 2026-04-30 09:02:35 --> URI Class Initialized
INFO - 2026-04-30 09:02:35 --> Router Class Initialized
INFO - 2026-04-30 09:02:35 --> Output Class Initialized
INFO - 2026-04-30 09:02:35 --> Security Class Initialized
DEBUG - 2026-04-30 09:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-04-30 09:02:35 --> Input Class Initialized
INFO - 2026-04-30 09:02:35 --> Language Class Initialized
INFO - 2026-04-30 09:02:35 --> Loader Class Initialized
INFO - 2026-04-30 09:02:35 --> Helper loaded: url_helper
INFO - 2026-04-30 09:02:35 --> Helper loaded: file_helper
INFO - 2026-04-30 09:02:35 --> Helper loaded: form_helper
INFO - 2026-04-30 09:02:35 --> Helper loaded: security_helper
INFO - 2026-04-30 09:02:35 --> Database Driver Class Initialized
INFO - 2026-04-30 09:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-04-30 09:02:35 --> Upload Class Initialized
INFO - 2026-04-30 09:02:35 --> Form Validation Class Initialized
INFO - 2026-04-30 09:02:35 --> Model "M_product" initialized
INFO - 2026-04-30 09:02:35 --> Model "M_settings" initialized
INFO - 2026-04-30 09:02:35 --> Controller Class Initialized
DEBUG - 2026-04-30 09:02:35 --> Session class already loaded. Second attempt ignored.
INFO - 2026-04-30 09:02:35 --> File loaded: C:\laragon\www\macha\application\views\auth/login.php
INFO - 2026-04-30 09:02:35 --> Final output sent to browser
DEBUG - 2026-04-30 09:02:35 --> Total execution time: 0.0822
