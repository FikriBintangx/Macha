<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= site_url('sales/process') ?>" method="post" onsubmit="return confirm('Konfirmasi Simpan?\nData transaksi akan disimpan dan stok akan terpotong secara otomatis.');">
            
            <div class="row mb-4">
                <div class="col-md-3">
                    <label class="small text-muted fw-bold">No. Invoice</label>
                    <input type="text" name="invoice_no" class="form-control bg-light fw-bold" value="<?= $invoice ?>" readonly>
                </div>
                <div class="col-md-3">
                    <label class="small text-muted fw-bold">Nama Pelanggan</label>
                    <input type="text" name="customer" class="form-control" placeholder="Umum" required>
                </div>
                <div class="col-md-3">
                    <label class="small text-muted fw-bold">Metode Bayar</label>
                    <select name="payment_method" id="payMethod" class="form-select" required>
                        <option value="Tunai">💵 Tunai</option>
                        <option value="QRIS">📱 QRIS</option>
                        <option value="Debit">💳 Kartu Debit</option>
                    </select>
                </div>
                <div class="col-md-3 d-none" id="debitInputGroup">
                    <label class="small text-muted fw-bold text-primary">4 Digit Terakhir Kartu</label>
                    <input type="text" name="card_number" id="cardNumber" class="form-control border-primary" maxlength="4" placeholder="Contoh: 1234" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                </div>
            </div>

            <div id="paymentAlerts" class="mb-4">
                <div id="qrisAlert" class="alert alert-primary d-none shadow-sm">
                    <div class="row align-items-center">
                        <div class="col-auto text-center">
                            <img src="<?= base_url('assets/img/qris-macha.jpg') ?>" 
                                 alt="QRIS Macha" 
                                 class="img-thumbnail shadow-sm mb-1" 
                                 style="width: 150px; height: auto; display: block; border: 2px solid #0d6efd;">
                        </div>
                        <div class="col text-dark">
                            <h6 class="fw-bold mb-1 text-primary"><i class="bi bi-qr-code-scan me-2"></i>PEMBAYARAN QRIS MACHA</h6>
                            <p class="mb-2 small">Silahkan tunjukkan barcode di samping kepada pelanggan untuk dipindai melalui aplikasi m-banking atau e-wallet.</p>
                            <span class="badge bg-white text-primary border p-2 shadow-sm">
                                Kode Unik Verifikasi: <strong class="fs-6">#<?= $unique_code ?></strong>
                            </span>
                        </div>
                    </div>
                </div>

                <div id="debitAlert" class="alert alert-info d-none shadow-sm">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-credit-card-2-front fs-2 me-3 text-primary"></i>
                        <div>
                            <h6 class="fw-bold mb-1 text-uppercase">Instruksi Mesin EDC</h6>
                            <p class="mb-0 small text-muted">Silahkan gesek atau masukkan kartu ke mesin EDC. Pastikan status transaksi sudah <b>BERHASIL / APPROVED</b> di mesin sebelum menekan tombol simpan.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead class="table-light">
                        <tr class="text-center">
                            <th>Jenis Produk</th>
                            <th width="150">Harga Satuan</th>
                            <th width="120">Jumlah</th>
                            <th width="180">Total Harga</th>
                            <th width="50">#</th>
                        </tr>
                    </thead>
                    <tbody id="cartItems">
                        <tr>
                            <td>
                                <select name="product_id[]" class="form-select product-item" required>
                                    <option value="">-- Pilih Produk --</option>
                                    <?php foreach($products as $p): ?>
                                        <option value="<?= $p['id'] ?>" 
                                                data-price="<?= $p['price'] ?>" 
                                                data-stock="<?= $p['stock'] ?>">
                                            <?= $p['name'] ?> (Stok: <?= $p['stock'] ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <div class="input-group">
                                    <span class="input-group-text small">Rp</span>
                                    <input type="number" name="price[]" class="form-control price-field text-end bg-light" readonly>
                                </div>
                            </td>
                            <td>
                                <input type="number" name="qty[]" class="form-control qty-field text-center" min="1" value="1" required>
                            </td>
                            <td>
                                <div class="input-group">
                                    <span class="input-group-text small text-success">Rp</span>
                                    <input type="number" name="subtotal[]" class="form-control sub-field fw-bold text-end bg-light" readonly>
                                </div>
                            </td>
                            <td class="text-center">
                                <button type="button" class="btn btn-outline-danger btn-sm remove-item">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <button type="button" id="addItem" class="btn btn-sm btn-outline-primary mb-3">
                <i class="bi bi-plus-circle me-1"></i> Tambah Item Lain
            </button>

            <div class="row justify-content-end">
                <div class="col-md-5 text-end">
                    <div class="bg-light p-4 rounded shadow-sm border">
                        <h5 class="mb-0 text-muted small">Grand Total:</h5>
                        <h1 class="text-success fw-bold mb-0">Rp <span id="displayTotal">0</span></h1>
                        <input type="hidden" name="total_price" id="inputTotal">
                        <hr class="my-3">
                        <button type="submit" class="btn btn-primary w-100 py-3 shadow fw-bold">
                            <i class="bi bi-check2-circle me-2"></i> SELESAIKAN & SIMPAN TRANSAKSI
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    
    // Fungsi Tambah Baris Baru
    $('#addItem').click(function() {
        let row = $('#cartItems tr:first').clone();
        row.find('input').val(''); 
        row.find('.qty-field').val(1).removeAttr('max'); 
        row.find('select').val('');
        $('#cartItems').append(row);
    });

    // Fungsi Hapus Baris
    $(document).on('click', '.remove-item', function() {
        if ($('#cartItems tr').length > 1) {
            $(this).closest('tr').remove();
            calcTotal();
        } else {
            alert('Minimal harus ada satu produk dalam pesanan.');
        }
    });

    // Logika Saat Pilih Produk (Ambil harga & stok)
    $(document).on('change', '.product-item', function() {
        let selected = $(this).find(':selected');
        let price = selected.data('price') || 0;
        let stock = selected.data('stock') || 0;
        let row = $(this).closest('tr');

        row.find('.price-field').val(price);
        row.find('.qty-field').attr('max', stock).val(1);
        
        if(stock <= 0 && selected.val() != '') {
            alert('❌ Stok Habis! Menu ini tidak tersedia untuk saat ini.');
            $(this).val('');
            row.find('.qty-field').val(0);
        }

        updateRow(row);
    });

    // Validasi Qty: Tidak boleh melebihi stok
    $(document).on('input', '.qty-field', function() {
        let row = $(this).closest('tr');
        let qty = parseInt($(this).val()) || 0;
        let maxStock = parseInt($(this).attr('max')) || 0;

        if (qty > maxStock) {
            alert('⚠️ Stok tidak mencukupi! Sisa stok menu ini hanya: ' + maxStock);
            $(this).val(maxStock);
        }
        
        updateRow(row);
    });

    function updateRow(row) {
        let p = row.find('.price-field').val() || 0;
        let q = row.find('.qty-field').val() || 0;
        row.find('.sub-field').val(p * q);
        calcTotal();
    }

    function calcTotal() {
        let grand = 0;
        $('.sub-field').each(function() {
            grand += Number($(this).val());
        });
        $('#displayTotal').text(grand.toLocaleString('id-ID'));
        $('#inputTotal').val(grand);
    }

    // Logika Ganti Metode Pembayaran (Show/Hide Alert & Input)
    $('#payMethod').change(function() {
        let method = $(this).val();
        
        // Sembunyikan semua & reset input opsional
        $('#qrisAlert, #debitAlert, #debitInputGroup').addClass('d-none');
        $('#cardNumber').removeAttr('required').val('');

        if(method == 'QRIS') {
            $('#qrisAlert').removeClass('d-none').hide().fadeIn();
        } 
        else if(method == 'Debit') {
            $('#debitAlert, #debitInputGroup').removeClass('d-none').hide().fadeIn();
            $('#cardNumber').attr('required', true); // Wajib isi jika pilih Debit
        }
    });
});
</script>
